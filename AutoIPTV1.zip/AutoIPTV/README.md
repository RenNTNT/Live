# AutoIPTV · 端上自聚合直播（纯 Java）

把 [akiralereal/iptv](https://github.com/akiralereal/iptv) 那套「自托管 IPTV 直播源管理与分发系统」
的核心链路搬进 **Java 写的 Android App**：**启动自动抓取 → 聚合去重 → 生成频道列表 → 播放页播放**，
不需要 Docker、不需要服务器，**不需要登录**。

## v1.1：修掉「装上一个台都没有」

**根因**：v1.0 只有「咪咕」一个内置抓取模块，而且没有任何兜底。咪咕的分类 / 取流接口一旦
在所在网络被拦（实测本环境 `program-sc.miguvideo.com` 返回网关 403 `policy_default_denied`，
换主域 / HTTP / Referer 都一样），整轮抓取 `channelCount = 0`，按「失败保缓存」语义首次启动
又没有缓存可保 → 列表就是空的。

**这一版改成 3 个在线自动抓取源 + 1 个离线兜底**：

| 源 | 内容 | 失败时 |
|---|---|---|
| 咪咕模块（免登录） | 按已移植的 Java 规则现抓 300+ 台 | 只记状态，不拖垮其它源 |
| 精选频道清单 | 运行时 GET 项目仓库 `IPTV.m3u`（20 台官方 CDN 直连） | 可改成本人可达的镜像地址 |
| 网络分享清单 | 运行时 GET `from-the-web/from-the-web.m3u`（76 台） | 来源待确认，可一键关闭 |
| **离线兜底快照** | 打包进 assets 的精选清单快照（20 台） | **仅在所有在线源都失败时注入，保证列表不空白** |

四个模块都能在「设置 → 源管理」独立开关；大陆网络常连不上 `raw.githubusercontent.com`，
两个清单地址都允许改成自己的镜像 / 自建服务地址。状态行现在会直接写出失败原因
（例如「咪咕分类接口无响应」）和「已启用离线快照」，不再是一片空白却看不出为什么。

> **关于内置地址的取舍**：为了让「装上就有台」成立，这一版把项目仓库公开维护的精选清单
> 做成了离线快照打进 assets。清单里的地址来自第三方 / 官方公开直连 CDN，**可能过期**，
> 且「网络分享」部分来源待确认。工程不内置账号 / Token / Cookie；
> 请只接入你已获授权的来源，可在设置里整体关闭或换成自己的订阅。
> 仓库本身也提醒：公开可访问不代表已获得复制、转播授权。

## 它做了什么

App 一启动就跑这条链路（全部在端上，纯 Java）：

```
各抓取模块（4 个，可独立开关，启动自动抓一轮）
   ↓ 并发抓取频道列表（单个失败只记状态）
聚合编排（同名合成「源1/源2」、同址去重、屏蔽规则、隐藏分组、分组先出现者胜）
   ↓ 全部在线源失败 → 注入离线快照
生成列表：分组横排 + 频道列表 UI，同时落盘缓存（重启秒开）
   ↓
点频道 → 播放页「播放时解析」→ ExoPlayer 起播，失败自动切下一条线路
   ↓（可选）
本机 1905 端口分发 /interface.m3u，局域网里其它播放器直接订阅
```

**和 Docker 版对齐的点：**

| Docker 版 | 本 App |
|---|---|
| 内置抓取模块 + 内置源 + 自定义源，逐卡片开关 | 4 个内置模块 + 任意多个 M3U/TXT 订阅 |
| 运行时从仓库 raw 拉内置源清单 | 两个 `M3uSource` 现抓，地址可改 |
| 全源聚合、去重、编排 | `Aggregator`：同址去重、跨模块同名多线路、分组先出现者胜 |
| 播放器按名聚合「源1 / 源2」 | 同名频道合并成多条 `Line`，M3U 输出多行 `#EXTINF` |
| 🚫 屏蔽规则 / 隐藏分组 / 只保留匹配项 | 同名规则，按名字过滤，源换址照样生效 |
| 播放时解析（deferred ref） | 咪咕写 `http://本机:1905/migu/<pID>`，请求时现取签名地址并 302 |
| 标准版 / 🩹 兼容版 | `/interface.m3u`（302 版）/ `?relay=1`（直出真实地址版） |
| 平台失败保缓存、不覆盖空列表 | `DiskCache`：一份都没有时沿用上一份列表 |
| 整点刷新（默认 6 小时） | 定时刷新，间隔可改，启动即自动抓一轮 |
| 源健康状态可观察 | 状态行 + `/api/status` 返回每个模块的频道数、失败原因、是否用了快照 |
| `catchup="none"`、省略纯缓冲提示的 `#EXTVLCOPT` | 生成 M3U 时同步处理 |

**免登录是硬约束**：没有账号 / Token / Cookie 字段，界面没有登录入口，咪咕固定游客 720p，
自定义源是纯 GET 公开列表。画质上限、VIP 频道、会员解扰等一律不做。

## 编译成 APK

环境：**JDK 17** + **Android SDK（compileSdk 35 / Build Tools 34）**，设好 `ANDROID_HOME`。
工程已带 Gradle 8.9 Wrapper，无需本机预装 Gradle。

```bash
./gradlew assembleDebug      # Windows 用 gradlew.bat
# 产物：app/build/outputs/apk/debug/app-debug.apk
```
Android Studio 也可以直接 `File → Open` 选本目录点 Run。首次会下载 Gradle 发行版与依赖，
慢的话把 `gradle/wrapper/gradle-wrapper.properties` 的 `distributionUrl` 换成可访问的 8.9 镜像。

> ⚠️ **本次沙盒没有产出 `.apk`**：环境只有 JRE 11（AGP 8.7.3 要 JDK 17）、没有 Android SDK。

## 能不能播：诚实说明

本环境的出网是白名单策略，实测结果：

- ✅ `raw.githubusercontent.com` 的清单能拉到（200，清单里的台名因此一定显示得出来）
- ❌ 咪咕 `program-sc.miguvideo.com` / `play.miguvideo.com` 全部 403 `policy_default_denied`
- ❌ 兜底清单里的媒体 CDN（苏州广电、西宁广电、CGTN 等）也全部 403

也就是说**在这里「列表有台」和「能起播」是两件事**：前者已经修好，后者必须装到
你自己的设备上、在你自己的网络里验证。播放页会在取流/播放失败时自动切下一条线路，
全挂会给出明确原因，不再静默空白。

## 已完成的验证（不依赖 Android SDK）

`core` 包零第三方依赖，桌面 JVM 就能跑测试：

```bash
sh tests/run-tests.sh     # 需要 node + javac
# 结果：55 项通过，0 项失败
```

覆盖：MD5 / 两套 sign / 两套 ddCalcu / 完整加密 URL / 咪咕分组整形、JSON 与 M3U 解析、
`#EXTVLCOPT` 请求头转发、同名合成 3 路且同址去重、屏蔽规则、失败源隔离、搜索、
标准版 deferred / 兼容版直出、`catchup="none"`、**真实 socket 起停分发服务**
（`/interface.m3u` 返回 M3U、`/migu/100` 返回 302 + Location、`/api/status`、404 路由），
以及本版新增的**快照解析 20 台 / 全失败注入快照仍有台 / 失败原因仍记录 / 快照生成完整 M3U**。
全部 Java 源码（含 Android 层）也过了语法编译，XML 与 wrapper 完整性已校验。

## 用起来

1. 装好打开 → 自动抓 3 个在线源；**任何情况下都至少有 20 台**（在线全挂时走离线快照）。
2. 点任意频道 → 播放页现取地址起播；多线路按「切线路」/ 菜单键换源，失败自动回落下一路。
3. 「设置 → 源管理」：开关 4 个模块、改两个清单地址（大陆建议换成自己的镜像）、
   加任意多个 M3U/TXT 订阅（每行 `名称,地址`，行首 `#` 停用）、改端口与刷新间隔、
   配屏蔽规则 / 隐藏分组 / 只保留匹配项、开关 H.265 / HDR / 就近取流。
4. 电视上别的播放器也能用：保持「开启本机分发服务」，复制界面上的
   `http://设备IP:1905/interface.m3u` 填进播放器；不跟随 302 的老播放器用 `?relay=1`。

## 已知边界

- **没有移植**：EPG 节目单、回看 / catchup、弹幕、体育赛事抓取、台标托管、网页 Chromium
  取票 / 解扰类模块、全代理版 `?relay=2`、央视频 / 凤凰 / B 站等多平台模块。
  这些要么依赖服务端常驻浏览器，要么需要各自登录态，和「免登录」冲突。
  架构留了 `Source` 接口，加模块就是新增一个实现类。
- 播放内核是 `exoplayer-core + hls + datasource`，**不含 FLV 解封装**；遇到 FLV 自动切下一条。
- 内置分发服务无鉴权，**仅限局域网**，别把端口映射到公网。
- 清单地址带签名 / 时效参数，**可能过期**；过期时状态行会显示「已启用离线快照」，
  到设置换成最新地址即可。

## 目录

```
app/src/main/assets/IPTV.m3u              离线兜底快照（20 台，来源已标注）
app/src/main/java/com/ilatv/migu/core/   纯 Java 内核（55 项 JVM 单测）
  MiguRules / MiguApi                    咪咕规则与播放时解析
  Line / Channel / Group / Source        线路、频道、分组、抓取模块接口
  MiguSource / M3uSource / SnapshotSource  免登录咪咕 / 在线清单 / 离线兜底
  Aggregator / Playlist / LocalServer    聚合编排 / 生成 M3U / 本机分发
app/src/main/java/com/ilatv/migu/       Android 壳
  Engine                                自动抓取调度、缓存、快照注入、分发、状态
  App / MainActivity / PlayerActivity / Prefs / DiskCache
tests/                                  参考实现 + 期望值 + 55 项 JVM 单测
gradle/ · gradlew · gradlew.bat          Gradle 8.9 Wrapper
```

参考项目：akiralereal/iptv（GPL-3.0）。本工程只参考算法与产品思路并用 Java 重新实现，
离线快照来自该仓库公开维护的精选清单；未复制其运行时代码、配置、账号或任何凭据。
