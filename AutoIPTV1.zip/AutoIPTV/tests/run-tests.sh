#!/bin/sh
# 纯 JVM 单测：不需要 Android SDK / Gradle / 网络，只需要 node 与 JDK（javac）。
# 用法：sh tests/run-tests.sh
set -e
cd "$(dirname "$0")/.."

echo "[1/3] 用参考实现生成期望值"
node tests/reference_rules.mjs > /dev/null

echo "[2/3] 编译 core + 单测"
rm -rf tests/build
mkdir -p tests/build
javac -encoding UTF-8 -d tests/build \
    app/src/main/java/com/ilatv/migu/core/*.java \
    tests/CoreTest.java

echo "[3/3] 逐值比对 + 聚合/分发端到端测试"
java -cp tests/build CoreTest tests/expected.txt
