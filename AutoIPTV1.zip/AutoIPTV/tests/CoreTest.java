import com.ilatv.migu.core.*;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 纯 JVM 单测：不需要 Android SDK / Gradle / 网络。
 * 先跑 `node tests/reference_rules.mjs` 生成 expected.txt，再跑本测试逐值比对，
 * 证明 Java 版签名 / ddCalcu / 分组整形与参考项目行为一致。
 */
public class CoreTest {
    private static int passed = 0, failed = 0;
    private static Map<String, String> exp = new LinkedHashMap<>();

    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : "tests/expected.txt";
        for (String line : Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8)) {
            if (line.isEmpty() || line.startsWith("#")) continue;
            int p = line.indexOf('=');
            if (p > 0) exp.put(line.substring(0, p), line.substring(p + 1));
        }

        eq("md5_abc", MiguRules.md5("abc"));
        eq("md5_empty", MiguRules.md5(""));
        eq("sign_account", MiguRules.accountSign(1700000000000L, "641886683"));
        eq("sign_guest", MiguRules.guestSign(1700000000000L, "641886683", "00421325"));

        String ds = "20261127";
        eq("dd_android_A", MiguRules.ddCalcuAndroid("abcdefghij1234567890", "641886683", 3, "", ds));
        eq("dd_android_B", MiguRules.ddCalcuAndroid("X9y8Z7w6", "123456789", 2, "", "20301231"));
        eq("dd_android_C", MiguRules.ddCalcuAndroid("AbCdEfGhIjKlMnOp", "641886773", 4, "12345678", ds));
        eq("dd_android_D", MiguRules.ddCalcuAndroid("AbCdEfGhIjKlMnOp", "641886773", 3, "abc", ds));
        eq("dd_720p_A", MiguRules.ddCalcu720p("abcdefghij1234567890", "641886683", ds));
        eq("dd_720p_B", MiguRules.ddCalcu720p("X9y8Z7w6", "123456789", "20301231"));

        String rawA = "https://x.example/live.m3u8?a=1&puData=abcdefghij1234567890";
        String rawB = "https://x.example/live.m3u8?a=1&puData=X9y8Z7w6";
        eq("enc_android", MiguRules.encryptUrlAndroid(rawA, "641886683", 3, "", ds));
        eq("enc_guest", MiguRules.encryptUrlGuest720p(rawB, "641886683", ds));
        eq("shape", shapeJson(MiguRules.shape(shapeFixture())));

        // ---- 不依赖期望文件的补充断言 ----
        check("puData 抽取", "abcdef".equals(MiguRules.puDataOf("http://x/?a=1&puData=abcdef")));
        check("CCTV5 不下发 appCode",
                !MiguRules.accountHeaders("", "", "641886683", 3).containsKey("appCode"));
        check("普通频道下发 appCode",
                MiguRules.guest720pHeaders("100").containsKey("appCode"));
        check("游客盐值 8 位且以 25 结尾",
                MiguRules.guestSalt(new java.util.Random(7)).matches("^\\d{6}25$"));
        check("账号请求头带 UserId",
                "u1".equals(MiguRules.accountHeaders("u1", "t1", "100", 3).get("UserId")));
        check("标清不带账号",
                !MiguRules.accountHeaders("u1", "t1", "100", 2).containsKey("UserId"));

        // JSON 解析
        Object j = Json.parse("{\"a\":[1,true,null,{\"b\":\"中\\u6587\"}],\"n\":3.5}");
        check("JSON 数组/嵌套", Json.list(Json.at(j, "a")).size() == 4);
        check("JSON unicode", "中文".equals(Json.strAt(Json.list(Json.at(j, "a")).get(3), "b")));
        check("JSON 浮点", Json.intAt(j, -1, "n") == 3);

        // M3U 解析
        String m3u = "#EXTM3U catchup=\"default\" catchup-days=\"7\"\n"
                + "#EXTINF:-1 tvg-id=\"cctv1\" tvg-logo=\"http://l/1.png\" group-title=\"央视\" catchup=\"default\",CCTV1 综合\n"
                + "#EXTVLCOPT:http-referrer=http://example.com\n"
                + "http://cdn/1.m3u8\n"
                + "#EXTINF:-1 tvg-id=\"cctv5\" group-title=\"体育\",CCTV5 体育\n"
                + "http://cdn/5.m3u8\n"
                + "#EXTINF:-1,未分组台\n#EXTGRP:地方\nhttp://cdn/x.m3u8\n";
        M3u.Playlist pl = M3u.parse(m3u);
        check("M3U 头属性", "default".equals(pl.header.get("catchup")));
        check("M3U 频道数", pl.channels.size() == 3);
        check("M3U 分组数", pl.groups.size() == 3);
        check("M3U 台标", "http://l/1.png".equals(pl.channels.get(0).logo));
        check("M3U EXTGRP", "地方".equals(pl.channels.get(2).group));
        check("M3U 地址不被选项行顶掉", "http://cdn/1.m3u8".equals(pl.channels.get(0).url));

        // ---- 聚合编排（同名多线路 / 屏蔽 / 失败源不影响其它源） ----
        Aggregator.FetchResult f1 = new Aggregator.FetchResult("migu", "咪咕");
        f1.channels.add(mk("CCTV1 综合", "央视", Line.miguPid("100")));
        f1.channels.add(mk("CCTV5 体育", "体育", Line.miguPid("200")));
        Aggregator.FetchResult f2 = new Aggregator.FetchResult("sub1", "订阅A");
        f2.channels.add(mk("CCTV1 综合", "央视", Line.url("sub1", "订阅A", "http://a/1.m3u8", "央视")));
        Aggregator.FetchResult f3 = new Aggregator.FetchResult("sub2", "订阅B");
        f3.channels.add(mk("CCTV1综合", "央视", Line.url("sub2", "订阅B", "http://b/1.m3u8", "央视")));
        f3.channels.add(mk("CCTV1综合", "央视", Line.url("sub2", "订阅B", "http://b/1.m3u8", "央视"))); // 同址重复
        Aggregator.FetchResult fb = new Aggregator.FetchResult("bad", "挂掉的源");
        fb.error = "超时";

        Aggregator.Rules rules = new Aggregator.Rules();
        rules.blockKeywords.add("CCTV5");
        Aggregator.Result ag = Aggregator.aggregate(
                java.util.Arrays.asList(f1, f2, f3, fb), rules);
        check("聚合分组数（屏蔽后只剩央视）", ag.groups.size() == 1);
        check("聚合频道数", ag.channelCount == 1);
        check("同名合成 3 路（同址去重）", ag.lineCount == 3 && ag.multiLineChannels == 1,
                "3", String.valueOf(ag.lineCount));
        check("屏蔽规则生效", ag.blocked == 1);
        check("失败源单独记录", ag.failedSources == 1 && ag.warnings.size() == 1);
        check("线路顺序：咪咕在前",
                ag.groups.get(0).channels.get(0).lines.get(0).sourceId.equals("migu"));
        check("名字归一化与搜索", Aggregator.search(ag.groups, "cctv1").get(0).size() == 1);

        // ---- 生成 M3U（标准版 deferred / 兼容版直出） ----
        String std = Playlist.build(ag.groups, "http://192.168.1.5:1905", Playlist.STANDARD, null);
        check("M3U 头", std.startsWith("#EXTM3U\n"));
        check("标准版咪咕走本机 deferred", std.contains("http://192.168.1.5:1905/migu/100"));
        check("直连线路原样输出", std.contains("http://a/1.m3u8"));
        check("直播标 catchup=none", std.contains("catchup=\"none\""));
        check("同名频道输出多行 EXTINF", count(std, "#EXTINF") == 3);
        check("分组写进 group-title", std.contains("group-title=\"央视\""));
        String compat = Playlist.build(ag.groups, "http://x:1", Playlist.COMPAT, l ->
                l.kind == Line.KIND_MIGU_PID ? "http://real/100.m3u8" : l.ref);
        check("兼容版直出真实地址", compat.contains("http://real/100.m3u8")
                && !compat.contains("/migu/100"));

        // ---- 内置分发服务（真实 socket 起停） ----
        final int testPort = 19057;
        LocalServer.Provider provider = new LocalServer.Provider() {
            public String m3u(String base, int relay) {
                return Playlist.build(ag.groups, base, relay, null);
            }
            public String resolveMigu(String pid) { return "http://cdn/" + pid + ".m3u8"; }
            public String statusJson() { return "{\"channels\":1}"; }
            public void refreshAsync() {}
        };
        LocalServer ls = new LocalServer(testPort, provider);
        try {
            ls.start();
            Thread.sleep(120);
            String body = Http.get("http://127.0.0.1:" + testPort + "/interface.m3u", null, 4000);
            check("分发服务返回 M3U", body.contains("#EXTM3U") && body.contains("/migu/100"));
            Http.Response r302 = Http.getFull(
                    "http://127.0.0.1:" + testPort + "/migu/100", null, 4000, false);
            check("播放时解析 302", r302.code == 302
                    && r302.location.equals("http://cdn/100.m3u8"));
            String st = Http.get("http://127.0.0.1:" + testPort + "/api/status", null, 4000);
            check("状态接口", st.contains("\"channels\":1"));
            check("404 路由", Http.getFull(
                    "http://127.0.0.1:" + testPort + "/nope", null, 4000, true).code == 404);
        } catch (Exception e) {
            check("分发服务异常：" + e, false);
        } finally {
            ls.stop();
        }

        // ---- M3U 请求头转发 ----
        String withOpt = "#EXTM3U\n#EXTINF:-1 tvg-id=\"x\" group-title=\"央视\",某台\n"
                + "#EXTVLCOPT:http-referrer=http://ref.example.com\n"
                + "#EXTVLCOPT:http-user-agent=MyPlayer/1.0\n"
                + "http://cdn/x.m3u8\n";
        M3u.Playlist wp = M3u.parse(withOpt);
        java.util.Map<String, String> hs =
                M3uSource.toHeaders(wp.channels.get(0).attrs);
        check("EXTVLCOPT 转 Referer", "http://ref.example.com".equals(hs.get("Referer")));
        check("EXTVLCOPT 转 User-Agent", "MyPlayer/1.0".equals(hs.get("User-Agent")));
        check("选项行不顶掉播放地址", "http://cdn/x.m3u8".equals(wp.channels.get(0).url));

        // ---- 离线兜底快照：保证「一个台都没有」不再发生 ----
        try {
            String snapText = new String(java.nio.file.Files.readAllBytes(
                    java.nio.file.Paths.get("app/src/main/assets/IPTV.m3u")),
                    java.nio.charset.StandardCharsets.UTF_8);
            SnapshotSource snap = new SnapshotSource(snapText);
            List<Channel> snapCh = snap.fetch();
            check("快照解析出 20 台", snapCh.size() == 20, "20", String.valueOf(snapCh.size()));
            boolean allUrl = true, allHttp = true;
            java.util.Set<String> gs = new java.util.HashSet<>();
            for (Channel c : snapCh) {
                gs.add(c.group);
                for (Line l : c.lines) {
                    if (l.kind != Line.KIND_URL) allUrl = false;
                    if (!l.ref.startsWith("http")) allHttp = false;
                }
            }
            check("快照线路全是直连地址", allUrl && allHttp);
            check("快照含多个分组", gs.size() >= 5, ">=5", String.valueOf(gs.size()));

            // 模拟「在线源全挂 + 注入快照」：聚合后必须仍有台（修复前的表现是 0 台）
            Aggregator.FetchResult badMigu = new Aggregator.FetchResult("migu", "咪咕");
            badMigu.error = "咪咕分类接口无响应（liveList 为空）";
            Aggregator.FetchResult badRepo = new Aggregator.FetchResult("repo", "精选频道");
            badRepo.error = "网络超时或不可达";
            Aggregator.FetchResult snapFr =
                    new Aggregator.FetchResult(snap.id(), snap.name());
            snapFr.channels.addAll(snapCh);
            Aggregator.Result recovered = Aggregator.aggregate(
                    java.util.Arrays.asList(badMigu, badRepo, snapFr), new Aggregator.Rules());
            check("全失败后注入快照仍有台", recovered.channelCount == 20,
                    "20", String.valueOf(recovered.channelCount));
            check("失败原因仍被记录", recovered.failedSources == 2
                    && recovered.warnings.size() == 2);
            String recoveredM3u = Playlist.build(recovered.groups,
                    "http://127.0.0.1:1905", Playlist.STANDARD, null);
            check("快照能生成完整 M3U", count(recoveredM3u, "#EXTINF") == 20);
        } catch (Exception e) {
            check("快照测试异常：" + e, false);
        }

        System.out.println("\n通过 " + passed + " 项，失败 " + failed + " 项");
        if (failed > 0) System.exit(1);
    }

    private static Channel mk(String name, String group, Line l) {
        Channel c = new Channel(name, group);
        c.tvgId = name;
        c.addLine(l);
        return c;
    }

    private static int count(String s, String sub) {
        int n = 0, i = 0;
        while ((i = s.indexOf(sub, i)) >= 0) { n++; i += sub.length(); }
        return n;
    }

    private static List<Group> shapeFixture() {
        List<Group> gs = new ArrayList<>();
        Group a = new Group("体育");
        a.channels.add(ch("CCTV5体育", "641886683"));
        a.channels.add(ch("CCTV1综合", "100"));
        gs.add(a);
        Group b = new Group("央视");
        b.channels.add(ch("CCTV5体育", "641886683"));
        b.channels.add(ch("CCTV1综合", "100"));
        b.channels.add(ch("CCTV5+体育赛事", "641886773"));
        gs.add(b);
        Group c = new Group("地方");
        c.channels.add(ch("财富天下", "200"));
        c.channels.add(ch("上海新闻综合", "201"));
        c.channels.add(ch("中国天气", "202"));
        c.channels.add(ch("无关频道", "203"));
        gs.add(c);
        Group d = new Group("综艺"); d.channels.add(ch("跳过A", "300")); gs.add(d);
        Group e = new Group("熊猫"); e.channels.add(ch("跳过B", "301")); gs.add(e);
        Group f = new Group("卫视");
        f.channels.add(ch("某卫视", "400"));
        f.channels.add(ch("某卫视", "400"));
        gs.add(f);
        return gs;
    }

    private static Channel ch(String name, String pid) {
        Channel c = new Channel(name, "x");
        c.pid = pid;
        c.source = Channel.SRC_DIRECT;
        return c;
    }

    private static String shapeJson(List<Group> groups) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < groups.size(); i++) {
            Group g = groups.get(i);
            if (i > 0) b.append(',');
            b.append("[\"").append(g.name).append("\",[");
            for (int k = 0; k < g.channels.size(); k++) {
                Channel c = g.channels.get(k);
                if (k > 0) b.append(',');
                b.append('"').append(c.name).append('#').append(c.pid).append('"');
            }
            b.append("]]");
        }
        return b.append(']').toString();
    }

    private static void eq(String key, String actual) {
        String want = exp.get(key);
        check(key + (want == null ? "（缺期望值）" : ""), want != null && want.equals(actual),
                want, actual);
    }

    private static void check(String name, boolean ok) { check(name, ok, "", ""); }

    private static void check(String name, boolean ok, String want, String actual) {
        if (ok) { passed++; System.out.println("  PASS  " + name); }
        else {
            failed++;
            System.out.println("  FAIL  " + name);
            if (!want.isEmpty() || !actual.isEmpty()) {
                System.out.println("        期望: " + want);
                System.out.println("        实际: " + actual);
            }
        }
    }
}
