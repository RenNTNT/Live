/**
 * 从 akiralereal/iptv（GPL-3.0）的 migu 模块逐行摘出的纯算法参考实现。
 * 用途：生成 expected.txt，给 Java 版 CoreTest 做逐值比对，证明规则移植没有走偏。
 * 不依赖本工程任何代码，也不发网络请求。
 */
import crypto from 'node:crypto';
import fs from 'node:fs';

const md5 = s => crypto.createHash('md5').update(s).digest('hex').toLowerCase();
const KEYS = 'cdabyzwxkl';
const SUFFIX_ACCOUNT = '3ce941cc3cbc40528bfd1c64f9fdf6c0migu0123';
const SUFFIX_GUEST = '2cac4f2c6c3346a5b34e085725ef7e33migu';

// ---- androidURL.js ----
function accountSign(ts, pid) { return md5(md5(ts + pid + '26000370') + SUFFIX_ACCOUNT); }
function guestSign(ts, pid, salt) {
  const suffix = SUFFIX_GUEST + salt.substring(0, 4);
  return md5(md5(ts + pid + '26000346') + suffix);
}

// ---- ddCalcuURL.js ----
function ddCalcuAndroid(puData, programId, rateType, userId, ds) {
  const words = ['v', 'a', '0', 'a'];
  const id = userId || '';
  if (id) {
    const w = KEYS[id[7]];          // 长度 < 8 时是 undefined，等同 Java 的空字符
    words[0] = w === undefined ? '' : w;
  }
  if (rateType == 2) words[0] = 'v';            // 原代码是松散相等 ==
  if (id.length > 3 && id.length <= 8) words[0] = 'e';
  const out = [];
  for (let i = 0; i < puData.length / 2; i++) {
    out.push(puData[puData.length - i - 1]);
    out.push(puData[i]);
    switch (i) {
      case 1: out.push(words[0]); break;
      case 2: out.push(KEYS[parseInt(ds[0])]); break;
      case 3: out.push(KEYS[programId[6]]); break;
      case 4: out.push(words[3]); break;
    }
  }
  return out.join('');
}
function ddCalcu720p(puData, programId, ds) {
  const out = [];
  for (let i = 0; i < puData.length / 2; i++) {
    out.push(puData[puData.length - i - 1]);
    out.push(puData[i]);
    switch (i) {
      case 1: out.push('v'); break;
      case 2: out.push(KEYS[parseInt(ds[2])]); break;
      case 3: out.push(KEYS[programId[6]]); break;
      case 4: out.push('a'); break;
    }
  }
  return out.join('');
}
function puDataOf(u) { return u.split('&puData=')[1] || ''; }
function encAndroid(u, pid, rateType, userId, ds) {
  return u + '&ddCalcu=' + ddCalcuAndroid(puDataOf(u), pid, rateType, userId, ds) + '&sv=10004&ct=android';
}
function encGuest(u, pid, ds) {
  return u + '&ddCalcu=' + ddCalcu720p(puDataOf(u), pid, ds) + '&sv=10004&ct=android';
}

// ---- index.js + fetchList.js 的分组整形 ----
const EXCLUSIONS = new Set(['中国天气','公共新闻频道','新动力量创一流','梨园频道',
  '海南广播电视总台社会与法频道','海南广播电视总台文旅频道','淮安新闻综合','宿迁新闻综合',
  '徐州新闻综合','盐城新闻综合','江阴新闻综合','南通新闻综合','宜兴新闻综合','溧水新闻综合',
  '镇江新闻综合','海南广播电视总台新闻频道','陕西银龄频道','陕西都市青春频道','陕西秦腔频道','陕西新闻资讯频道']);
const REASSIGN = { '财富天下': '江苏' };
const SUPPLEMENT = {
  '上海新闻综合': { group: '上海', officialEpg: true },
  '上海第一财经': { group: '上海', name: '第一财经', officialEpg: true },
  '上视东方影视': { group: '上海' },
};
function uniqueInGroup(g) {
  const seen = new Set(); g.channels = g.channels.filter(c => !seen.has(c.name) && seen.add(c.name));
}
function redistributeLocal(groups) {
  const out = [];
  const append = (name, chans) => {
    if (!chans.length) return;
    let g = out.find(x => x.name === name);
    if (!g) { g = { name, channels: [] }; out.push(g); }
    g.channels.push(...chans);
  };
  for (const g of groups) {
    if (g.name === '综艺' || g.name === '熊猫') continue;
    const kept = g.channels.filter(c => !EXCLUSIONS.has(c.name));
    if (g.name !== '地方') { append(g.name, kept); continue; }
    for (const c of kept) {
      const target = REASSIGN[c.name];
      if (target) append(target, [{ ...c, group: target }]);
      const sup = SUPPLEMENT[c.name];
      if (sup) append(sup.group, [{ ...c, ...(sup.name ? { name: sup.name } : {}), group: sup.group }]);
    }
  }
  return out;
}
function dedupeAcrossGroups(groups) {
  const seen = new Set(), seenEx = new Set(), out = [];
  for (const g of groups) {
    const allowBoth = g.name === '体育' || g.name === '央视';
    const kept = g.channels.filter(c => {
      const k = c.pid;
      const both = allowBoth && (c.name === 'CCTV5体育' || c.name === 'CCTV5+体育赛事');
      if (both) {
        const key = k + '::' + g.name;
        if (seenEx.has(key)) return false;
        seenEx.add(key); seen.add(k); return true;
      }
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
    if (kept.length) out.push({ name: g.name, channels: kept });
  }
  return out;
}
function shape(groups) {
  groups.forEach(uniqueInGroup);
  return dedupeAcrossGroups(redistributeLocal(groups));
}

// ---- 生成期望值 ----
const ds = '20261127';
const lines = [];
const put = (k, v) => lines.push(k + '=' + v);

put('md5_abc', md5('abc'));
put('md5_empty', md5(''));
put('sign_account', accountSign(1700000000000, '641886683'));
put('sign_guest', guestSign(1700000000000, '641886683', '00421325'));
put('dd_android_A', ddCalcuAndroid('abcdefghij1234567890', '641886683', 3, '', ds));
put('dd_android_B', ddCalcuAndroid('X9y8Z7w6', '123456789', 2, '', '20301231'));
put('dd_android_C', ddCalcuAndroid('AbCdEfGhIjKlMnOp', '641886773', 4, '12345678', ds));
put('dd_android_D', ddCalcuAndroid('AbCdEfGhIjKlMnOp', '641886773', 3, 'abc', ds));
put('dd_720p_A', ddCalcu720p('abcdefghij1234567890', '641886683', ds));
put('dd_720p_B', ddCalcu720p('X9y8Z7w6', '123456789', '20301231'));
const rawA = 'https://x.example/live.m3u8?a=1&puData=abcdefghij1234567890';
const rawB = 'https://x.example/live.m3u8?a=1&puData=X9y8Z7w6';
put('enc_android', encAndroid(rawA, '641886683', 3, '', ds));
put('enc_guest', encGuest(rawB, '641886683', ds));

const ch = (name, pid) => ({ name, pid });
const fixture = [
  { name: '体育', channels: [ch('CCTV5体育','641886683'), ch('CCTV1综合','100')] },
  { name: '央视', channels: [ch('CCTV5体育','641886683'), ch('CCTV1综合','100'), ch('CCTV5+体育赛事','641886773')] },
  { name: '地方', channels: [ch('财富天下','200'), ch('上海新闻综合','201'), ch('中国天气','202'), ch('无关频道','203')] },
  { name: '综艺', channels: [ch('跳过A','300')] },
  { name: '熊猫', channels: [ch('跳过B','301')] },
  { name: '卫视', channels: [ch('某卫视','400'), ch('某卫视','400')] },
];
put('shape', JSON.stringify(shape(fixture).map(g => [g.name, g.channels.map(c => c.name + '#' + c.pid)])));

fs.writeFileSync(new URL('./expected.txt', import.meta.url), lines.join('\n') + '\n', 'utf8');
console.log(lines.join('\n'));
