# release 默认 minifyEnabled false，以下供日后开启 R8 时使用。
# core 层全部由 Java 代码直接调用，无反射 / JNI / WebView 桥接。
-keep class com.ilatv.migu.core.** { *; }
-keep class com.google.android.exoplayer2.** { *; }
