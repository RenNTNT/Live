package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.List;

/** 一个频道。同名频道的多条线路聚合在这里，对应 Docker 版播放列表里的「源1 / 源2」。 */
public class Channel {
    /** 直连：咪咕 pID（裸数字）；订阅：播放地址本身。 */
    public static final int SRC_DIRECT = 0;
    public static final int SRC_SUBSCRIPTION = 1;

    public String name;
    public String group = "其他";
    public String pid = "";
    public String url = "";
    public String logo = "";
    public String tvgId = "";
    public String epgId = "";
    public int source = SRC_DIRECT;

    /** 聚合后的全部播放线路；先加入的是默认线路。旧字段仍保留给单测与咪咕分组整形使用。 */
    public final List<Line> lines = new ArrayList<>();
    /** 源条目上的原始属性（tvg-* / catchup / #EXTVLCOPT 等），供请求头转发。 */
    public final java.util.LinkedHashMap<String, String> attrs = new java.util.LinkedHashMap<>();

    public Channel() {}

    public Channel(String name, String group) {
        this.name = name == null ? "" : name.trim();
        this.group = group == null || group.trim().isEmpty() ? "其他" : group.trim();
    }

    /** 去重 / 缓存用的主键。参考项目用裸 pID 当频道 ID，这里保持一致。 */
    public String key() {
        return source == SRC_DIRECT ? pid : url;
    }

    public boolean valid() {
        return name != null && !name.isEmpty() && !key().isEmpty();
    }

    /** 聚合后是否可播：至少有一条线路。 */
    public boolean playable() {
        return name != null && !name.isEmpty() && !lines.isEmpty();
    }

    public void addLine(Line l) { if (l != null) lines.add(l); }

    public Line line(int index) {
        return lines.isEmpty() ? null : lines.get(Math.max(0, Math.min(index, lines.size() - 1)));
    }

    @Override public String toString() { return name + " [" + group + "] " + lines.size() + " 路"; }
}
