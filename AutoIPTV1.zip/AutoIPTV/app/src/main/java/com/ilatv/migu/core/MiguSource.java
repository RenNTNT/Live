package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.List;

/**
 * 咪咕免登录模块：固定走游客 720p 取流路径，不读取、不需要任何账号或 Token。
 * 频道列表与播放地址都按已验证的 Java 规则移植（见 MiguRules / MiguApi）。
 */
public class MiguSource implements Source {
    private final MiguConfig cfg;
    private final MiguApi api;
    private boolean enabled = true;
    private int lastCount = 0;
    private String lastError = "";

    public MiguSource() {
        // 游客固定档位：账号留空 → resolve 自动走 getAndroidURL720p
        cfg = new MiguConfig();
        cfg.userId = "";
        cfg.token = "";
        cfg.rateType = 3;
        cfg.enableH265 = true;
        cfg.enableHdr = true;
        cfg.enableClientDispatch = false;
        api = new MiguApi(cfg);
    }

    @Override public String id() { return "migu"; }
    @Override public String name() { return "咪咕视频（免登录）"; }
    @Override public boolean enabled() { return enabled; }
    @Override public void setEnabled(boolean on) { enabled = on; }
    @Override public int lastCount() { return lastCount; }
    @Override public String lastError() { return lastError; }

    public void setH265(boolean on) { cfg.enableH265 = on; api.clearResolveCache(); }
    public void setHdr(boolean on) { cfg.enableHdr = on; api.clearResolveCache(); }
    public void setClientDispatch(boolean on) { cfg.enableClientDispatch = on; api.clearResolveCache(); }
    public boolean h265() { return cfg.enableH265; }
    public boolean hdr() { return cfg.enableHdr; }
    public boolean clientDispatch() { return cfg.enableClientDispatch; }
    public void setTimeout(int ms) { cfg.timeoutMs = ms; }
    public void clearResolveCache() { api.clearResolveCache(); }

    @Override public List<Channel> fetch() throws Exception {
        lastError = "";
        List<Group> groups = api.fetchGroups();
        List<Channel> out = new ArrayList<>();
        int n = 0;
        for (Group g : groups) {
            for (Channel old : g.channels) {
                Channel c = new Channel(old.name, g.name);
                c.logo = old.logo;
                c.tvgId = old.tvgId;
                c.epgId = old.tvgId;
                Line l = Line.miguPid(old.pid);
                l.group = g.name;
                c.addLine(l);
                if (c.playable()) { out.add(c); n++; }
            }
        }
        lastCount = n;
        if (n == 0) throw new MiguException("咪咕本轮返回 0 个频道");
        return out;
    }

    @Override public String resolve(Line line) throws Exception {
        if (line == null || line.kind != Line.KIND_MIGU_PID) {
            throw new MiguException("线路不是咪咕 pID");
        }
        Channel tmp = new Channel("咪咕", "其他");
        tmp.source = Channel.SRC_DIRECT;
        tmp.pid = line.ref;
        return api.resolve(tmp);
    }
}
