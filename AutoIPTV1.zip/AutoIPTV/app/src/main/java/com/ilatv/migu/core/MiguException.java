package com.ilatv.migu.core;

public class MiguException extends Exception {
    public MiguException(String message) { super(message); }
    public MiguException(String message, Throwable cause) { super(message, cause); }
}
