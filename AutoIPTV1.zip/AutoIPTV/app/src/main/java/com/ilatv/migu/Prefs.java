package com.ilatv.migu;

import android.content.Context;
import android.content.SharedPreferences;

import com.ilatv.migu.core.Aggregator;
import com.ilatv.migu.core.Json;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 配置只落本机 SharedPreferences。
 * 这一版**完全没有账号 / Token / Cookie 字段**：所有模块默认免登录，App 不提供登录入口。
 */
public class Prefs {
    private static final String P = "autoiptv";
    private final SharedPreferences sp;

    public static class Sub {
        public String id, name, url;
        public boolean enabled = true;
        public Sub(String id, String name, String url, boolean on) {
            this.id = id; this.name = name; this.url = url; this.enabled = on;
        }
    }

    public Prefs(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(P, Context.MODE_PRIVATE);
    }

    public boolean noticeShown() { return sp.getBoolean("noticeShown", false); }
    public void setNoticeShown() { sp.edit().putBoolean("noticeShown", true).apply(); }

    public int port() { return sp.getInt("port", 1905); }
    public void setPort(int p) { sp.edit().putInt("port", p).apply(); }

    public boolean serverOn() { return sp.getBoolean("serverOn", true); }
    public void setServerOn(boolean on) { sp.edit().putBoolean("serverOn", on).apply(); }

    public int refreshMinutes() { return sp.getInt("refreshMinutes", 360); }
    public void setRefreshMinutes(int m) { sp.edit().putInt("refreshMinutes", m).apply(); }

    public boolean miguOn() { return sp.getBoolean("miguOn", true); }
    public void setMiguOn(boolean on) { sp.edit().putBoolean("miguOn", on).apply(); }

    /** 仓库公开精选清单（Docker 版的「内置源 / 精选频道」）。大陆网络不通时可改成自己的镜像地址。 */
    public static final String REPO_DEFAULT =
            "https://raw.githubusercontent.com/akiralereal/iptv/main/IPTV.m3u";
    public static final String WEB_DEFAULT =
            "https://raw.githubusercontent.com/akiralereal/iptv/main/from-the-web/from-the-web.m3u";

    public boolean repoOn() { return sp.getBoolean("repoOn", true); }
    public void setRepoOn(boolean on) { sp.edit().putBoolean("repoOn", on).apply(); }
    public boolean webOn() { return sp.getBoolean("webOn", true); }
    public void setWebOn(boolean on) { sp.edit().putBoolean("webOn", on).apply(); }
    public boolean snapshotOn() { return sp.getBoolean("snapshotOn", true); }
    public void setSnapshotOn(boolean on) { sp.edit().putBoolean("snapshotOn", on).apply(); }

    public String repoUrl() { return sp.getString("repoUrl", REPO_DEFAULT); }
    public void setRepoUrl(String s) { sp.edit().putString("repoUrl", s == null ? "" : s.trim()).apply(); }
    public String webUrl() { return sp.getString("webUrl", WEB_DEFAULT); }
    public void setWebUrl(String s) { sp.edit().putString("webUrl", s == null ? "" : s.trim()).apply(); }

    public boolean h265() { return sp.getBoolean("h265", true); }
    public void setH265(boolean on) { sp.edit().putBoolean("h265", on).apply(); }
    public boolean hdr() { return sp.getBoolean("hdr", true); }
    public void setHdr(boolean on) { sp.edit().putBoolean("hdr", on).apply(); }
    public boolean clientDispatch() { return sp.getBoolean("clientDispatch", false); }
    public void setClientDispatch(boolean on) { sp.edit().putBoolean("clientDispatch", on).apply(); }

    public String blockKeywords() { return sp.getString("blockKeywords", ""); }
    public void setBlockKeywords(String s) { sp.edit().putString("blockKeywords", s).apply(); }
    public String hiddenGroups() { return sp.getString("hiddenGroups", ""); }
    public void setHiddenGroups(String s) { sp.edit().putString("hiddenGroups", s).apply(); }
    public String keepKeywords() { return sp.getString("keepKeywords", ""); }
    public void setKeepKeywords(String s) { sp.edit().putString("keepKeywords", s).apply(); }

    /** 自定义订阅源以 JSON 数组保存，工程不内置任何默认地址。 */
    public List<Sub> subs() {
        List<Sub> out = new ArrayList<>();
        try {
            Object root = Json.parse(sp.getString("subs", "[]"));
            List<Object> arr = Json.list(root);
            if (arr == null) return out;
            for (Object o : arr) {
                Sub s = new Sub(Json.strAt(o, "id"), Json.strAt(o, "name"),
                        Json.strAt(o, "url"), !"false".equals(Json.strAt(o, "enabled")));
                if (s.id != null && !s.id.isEmpty()) out.add(s);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public void setSubs(List<Sub> list) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            Sub s = list.get(i);
            if (i > 0) b.append(',');
            b.append("{\"id\":").append(q(s.id))
             .append(",\"name\":").append(q(s.name))
             .append(",\"url\":").append(q(s.url))
             .append(",\"enabled\":").append(s.enabled).append('}');
        }
        sp.edit().putString("subs", b.append(']').toString()).apply();
    }

    public Aggregator.Rules rules() {
        Aggregator.Rules r = new Aggregator.Rules();
        for (String s : split(blockKeywords())) r.blockKeywords.add(s);
        for (String s : split(hiddenGroups())) r.hiddenGroups.add(s);
        for (String s : split(keepKeywords())) r.keepKeywords.add(s);
        return r;
    }

    public static List<String> split(String s) {
        List<String> out = new ArrayList<>();
        if (s == null) return out;
        for (String p : s.split("[,，\\n]")) {
            String t = p.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private static String q(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n") + "\"";
    }
}
