package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 聚合编排层：把各模块抓回的频道合成一份干净列表。
 * 对齐 Docker 版的行为：
 *   · 同名频道不删，合成「源1 / 源2」多条线路（播放器按名聚合）；
 *   · 同一模块内按地址去重、跨模块不去重（那是真冗余，要留作备用）；
 *   · 分组按模块返回顺序，先出现者胜；
 *   · 屏蔽规则只看名字，源换址 / 每天重建都照样生效；
 *   · 任一模块失败不影响其它模块，全部失败时由 Engine 保留上一份缓存。
 */
public final class Aggregator {
    private Aggregator() {}

    public static class FetchResult {
        public final String sourceId;
        public final String sourceName;
        public final List<Channel> channels = new ArrayList<>();
        public String error = "";
        public FetchResult(String sourceId, String sourceName) {
            this.sourceId = sourceId; this.sourceName = sourceName;
        }
        public boolean ok() { return error.isEmpty(); }
    }

    public static class Rules {
        /** 名字含任一关键字就整台不出现（对应「屏蔽规则」）。 */
        public final Set<String> blockKeywords = new LinkedHashSet<>();
        /** 整组不出现在播放列表。 */
        public final Set<String> hiddenGroups = new LinkedHashSet<>();
        /** 非空时只保留名字命中的频道（对应「只保留匹配项」）。 */
        public final Set<String> keepKeywords = new LinkedHashSet<>();
        /** 单个模块最多收多少频道，防止异常源刷屏。 */
        public int maxPerSource = 5000;
    }

    public static class Result {
        public final List<Group> groups = new ArrayList<>();
        public int channelCount = 0;
        public int lineCount = 0;
        public int multiLineChannels = 0;
        public int blocked = 0;
        public int failedSources = 0;
        public final List<String> warnings = new ArrayList<>();
    }

    /** 频道名归一化：去空白、全角括号/冒号转半角、忽略大小写。 */
    public static String normalize(String name) {
        if (name == null) return "";
        StringBuilder b = new StringBuilder();
        for (char c : name.toCharArray()) {
            if (Character.isWhitespace(c)) continue;
            if (c == '（') c = '(';
            else if (c == '）') c = ')';
            else if (c == '：') c = ':';
            else if (c == '－' || c == '—') c = '-';
            b.append(c);
        }
        return b.toString().toLowerCase(Locale.ROOT);
    }

    public static Result aggregate(List<FetchResult> results, Rules rules) {
        Rules r = rules == null ? new Rules() : rules;
        Result out = new Result();
        Map<String, Channel> byName = new LinkedHashMap<>();
        List<Group> ordered = new ArrayList<>();
        Map<String, Group> groupByName = new LinkedHashMap<>();

        for (FetchResult fr : results == null ? new ArrayList<FetchResult>() : results) {
            if (!fr.ok()) { out.failedSources++; out.warnings.add(fr.sourceName + "：" + fr.error); continue; }
            int taken = 0;
            for (Channel src : fr.channels) {
                if (taken++ >= r.maxPerSource) break;
                if (src == null || !src.playable()) continue;
                if (blocked(src.name, r)) { out.blocked++; continue; }
                String key = normalize(src.name);
                if (key.isEmpty()) continue;
                String gname = src.group == null || src.group.isEmpty() ? "其他" : src.group;
                if (r.hiddenGroups.contains(gname)) { out.blocked++; continue; }

                Channel target = byName.get(key);
                if (target == null) {
                    target = new Channel(src.name, gname);
                    target.logo = src.logo;
                    target.tvgId = src.tvgId;
                    target.epgId = src.epgId;
                    target.attrs.putAll(src.attrs);
                    byName.put(key, target);
                    Group g = groupByName.get(gname);
                    if (g == null) { g = new Group(gname); groupByName.put(gname, g); ordered.add(g); }
                    g.channels.add(target);
                } else {
                    if (target.logo.isEmpty() && !src.logo.isEmpty()) target.logo = src.logo;
                    if (target.tvgId.isEmpty() && !src.tvgId.isEmpty()) target.tvgId = src.tvgId;
                }
                // 按 sourceId + ref 去重，跨模块同名同址也不重复
                for (Line l : src.lines) {
                    if (l == null || !l.valid()) continue;
                    if (hasLine(target, l)) continue;
                    Line copy = copyLine(l);
                    if (copy.group == null || copy.group.isEmpty()) copy.group = gname;
                    target.addLine(copy);
                }
            }
        }

        // 「只保留匹配项」放在合并之后，只按名字过滤
        if (!r.keepKeywords.isEmpty()) {
            java.util.Iterator<Map.Entry<String, Channel>> it = byName.entrySet().iterator();
            while (it.hasNext()) {
                Channel c = it.next().getValue();
                boolean hit = false;
                for (String k : r.keepKeywords) if (k != null && c.name.contains(k)) { hit = true; break; }
                if (!hit) { it.remove(); out.blocked++; }
            }
            for (Group g : ordered) {
                java.util.Iterator<Channel> ci = g.channels.iterator();
                while (ci.hasNext()) if (!byName.containsKey(normalize(ci.next().name))) ci.remove();
            }
        }

        for (Group g : ordered) {
            if (!g.channels.isEmpty()) {
                out.groups.add(g);
                out.channelCount += g.channels.size();
                for (Channel c : g.channels) {
                    if (!c.playable()) continue;
                    out.lineCount += c.lines.size();
                    if (c.lines.size() > 1) out.multiLineChannels++;
                }
            }
        }
        return out;
    }

    private static boolean blocked(String name, Rules r) {
        if (name == null) return false;
        for (String k : r.blockKeywords) {
            if (k != null && !k.isEmpty() && name.contains(k)) return true;
        }
        return false;
    }

    private static boolean hasLine(Channel c, Line l) {
        for (Line x : c.lines) {
            if (x.sourceId.equals(l.sourceId) && x.kind == l.kind && x.ref.equals(l.ref)) return true;
        }
        return false;
    }

    private static Line copyLine(Line l) {
        Line n = new Line();
        n.sourceId = l.sourceId; n.sourceName = l.sourceName;
        n.kind = l.kind; n.ref = l.ref; n.group = l.group;
        n.headers.putAll(l.headers);
        return n;
    }

    /** 名字 / 分组模糊搜索，返回新的浅拷贝分组列表。 */
    public static List<Group> search(List<Group> groups, String keyword) {
        List<Group> out = new ArrayList<>();
        String q = keyword == null ? "" : keyword.trim();
        if (q.isEmpty()) return groups == null ? out : groups;
        String nq = normalize(q);
        if (groups == null) return out;
        for (Group g : groups) {
            Group ng = new Group(g.name);
            for (Channel c : g.channels) {
                if (normalize(c.name).contains(nq) || normalize(g.name).contains(nq)) ng.channels.add(c);
            }
            if (!ng.channels.isEmpty()) out.add(ng);
        }
        return out;
    }
}
