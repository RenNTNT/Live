package com.ilatv.migu.core;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 咪咕视频「规则」的 Java 移植，参考 akiralereal/iptv 的 extractors/migu 模块（GPL-3.0）。
 *
 * 这里只放纯数据 / 纯算法，不发网络请求、不依赖 Android，桌面 JVM 可直接编译单测。
 * 对应参考项目的：
 *   utils/EncryUtils.js        getStringMD5
 *   utils/time.js              getDateString（YYYYMMDD）
 *   extractors/migu/androidURL.js  getSaltAndSign / 游客 720p 的 salt+sign
 *   extractors/migu/ddCalcuURL.js  getddCalcu / getddCalcuURL / getddCalcu720p
 *   utils/fetchList.js         uniqueData（分类内按名字去重）
 *   extractors/migu/index.js   redistributeMiguLocalChannels / dedupeAcrossGroups
 *
 * 合规：本文件不内置任何账号、Token、频道地址或播放地址；是否可用取决于你本人
 * 是否拥有相应内容的合法授权，以及上游接口的可用性。
 */
public final class MiguRules {
    private MiguRules() {}

    // ---- 接口地址（参考项目 utils/fetchList.js / androidURL.js） ----
    public static final String CATE_LIST_URL =
            "https://program-sc.miguvideo.com/live/v2/tv-data/1ff892f2b5ab4a79be6e25b69d2f5d05";
    public static final String CATE_BASE =
            "https://program-sc.miguvideo.com/live/v2/tv-data/";
    public static final String PLAY_URL =
            "https://play.miguvideo.com/playurl/v1/play/playurl";

    // ---- 签名常量（androidURL.js） ----
    private static final String APP_VERSION = "26000370";
    private static final String APP_VERSION_GUEST = "2600034600";
    private static final String APP_VERSION_GUEST_8 = "2600034600".substring(0, 8); // 26000346
    private static final String SUFFIX_ACCOUNT = "3ce941cc3cbc40528bfd1c64f9fdf6c0migu0123";
    private static final String SUFFIX_GUEST = "2cac4f2c6c3346a5b34e085725ef7e33migu";
    private static final int SALT_ACCOUNT = 1230024;

    // CCTV5 / CCTV5+ 开 flv 后不能回放，参考项目对这两个 pID 不下发 appCode
    private static final Set<String> NO_APPCODE_PIDS = new HashSet<>();
    static {
        NO_APPCODE_PIDS.add("641886683");
        NO_APPCODE_PIDS.add("641886773");
    }

    // ---- ddCalcu 常量（ddCalcuURL.js） ----
    private static final String KEYS = "cdabyzwxkl";
    private static final String SUFFIX_ANDROID = "&sv=10004&ct=android";

    // ---- 分组整形常量（extractors/migu/index.js） ----
    private static final Set<String> EXCLUSIONS = new HashSet<>();
    private static final Map<String, String> REASSIGNMENTS = new LinkedHashMap<>();
    private static final Map<String, String[]> SUPPLEMENTS = new LinkedHashMap<>();
    static {
        String[] ex = {
            "中国天气", "公共新闻频道", "新动力量创一流", "梨园频道",
            "海南广播电视总台社会与法频道", "海南广播电视总台文旅频道",
            "淮安新闻综合", "宿迁新闻综合", "徐州新闻综合", "盐城新闻综合",
            "江阴新闻综合", "南通新闻综合", "宜兴新闻综合", "溧水新闻综合",
            "镇江新闻综合", "海南广播电视总台新闻频道",
            "陕西银龄频道", "陕西都市青春频道", "陕西秦腔频道", "陕西新闻资讯频道"
        };
        for (String s : ex) EXCLUSIONS.add(s);
        REASSIGNMENTS.put("财富天下", "江苏");
        // value = {目标分组, 改名(空串表示不改), 是否用官方节目单}
        SUPPLEMENTS.put("上海新闻综合", new String[]{"上海", "", "1"});
        SUPPLEMENTS.put("上海第一财经", new String[]{"上海", "第一财经", "1"});
        SUPPLEMENTS.put("上视东方影视", new String[]{"上海", "", "0"});
    }

    // ==================== 加密 / 签名 ====================

    /** 与原项目 crypto.createHash('md5').update(str).digest('hex') 完全一致（UTF-8 小写）。 */
    public static String md5(String input) {
        try {
            MessageDigest d = MessageDigest.getInstance("MD5");
            byte[] b = d.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(b.length * 2);
            for (byte x : b) {
                sb.append(Character.forDigit((x >>> 4) & 0xF, 16));
                sb.append(Character.forDigit(x & 0xF, 16));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String accountSign(long timestamp, String pid) {
        return md5(md5(timestamp + pid + APP_VERSION) + SUFFIX_ACCOUNT);
    }

    public static int accountSalt() { return SALT_ACCOUNT; }

    /** 随机 6 位补零 + "25"，对应 JS 的 padStart(6,'0') + '25'。 */
    public static String guestSalt(java.util.Random rnd) {
        return String.format(Locale.US, "%06d", rnd.nextInt(1000000)) + "25";
    }

    public static String guestSign(long timestamp, String pid, String salt) {
        String suffix = SUFFIX_GUEST + salt.substring(0, 4);
        return md5(md5(timestamp + pid + APP_VERSION_GUEST_8) + suffix);
    }

    /** 取当天 YYYYMMDD（本地时区），对应 getDateString(new Date())。 */
    public static String dateString(Date d) {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(d == null ? new Date() : d);
    }

    private static char keyAt(String dateStr, int charIndex) {
        int idx = Character.digit(dateStr.charAt(charIndex), 10);
        return (idx >= 0 && idx < KEYS.length()) ? KEYS.charAt(idx) : '\0';
    }

    private static char keyByPid(String pid, int charIndex) {
        if (pid == null || pid.length() <= charIndex) return '\0';
        int idx = Character.digit(pid.charAt(charIndex), 10);
        return (idx >= 0 && idx < KEYS.length()) ? KEYS.charAt(idx) : '\0';
    }

    private static void push(StringBuilder b, char c) {
        if (c != '\0') b.append(c); // JS 里 undefined 进 join 会变成空串
    }

    /**
     * ddCalcuURL.js 的 getddCalcu（android）。dateStr 可注入以便单测。
     * rateType 用 int：原代码是松散相等 rateType == "2"，数值 2 会命中。
     */
    public static String ddCalcuAndroid(String puData, String programId,
                                        int rateType, String userId, String dateStr) {
        if (puData == null || programId == null) return "";
        String id = userId == null ? "" : userId;
        char[] words = {'v', 'a', '0', 'a'};
        if (!id.isEmpty()) {
            // JS 的 keys[id[7]] 在 id 不足 8 位时是 undefined，join 时变成空串
            if (id.length() > 7) {
                int k = Character.digit(id.charAt(7), 10);
                words[0] = (k >= 0 && k < KEYS.length()) ? KEYS.charAt(k) : '\0';
            } else {
                words[0] = '\0';
            }
        }
        if (rateType == 2) words[0] = 'v';
        if (id.length() > 3 && id.length() <= 8) words[0] = 'e';

        int len = puData.length();
        StringBuilder b = new StringBuilder(len * 2 + 8);
        // JS: for (i = 0; i < puDataLength / 2; i++)，等价于 i*2 < len
        for (int i = 0; i * 2 < len; i++) {
            b.append(puData.charAt(len - i - 1));
            b.append(puData.charAt(i));
            switch (i) {
                case 1: push(b, words[0]); break;
                case 2: push(b, keyAt(dateStr, 0)); break;
                case 3: push(b, keyByPid(programId, 6)); break;
                case 4: push(b, words[3]); break;
                default: break;
            }
        }
        return b.toString();
    }

    /** ddCalcuURL.js 的 getddCalcu720p（游客 720p 路径专用）。 */
    public static String ddCalcu720p(String puData, String programId, String dateStr) {
        if (puData == null || programId == null) return "";
        int len = puData.length();
        StringBuilder b = new StringBuilder(len * 2 + 8);
        for (int i = 0; i * 2 < len; i++) {
            b.append(puData.charAt(len - i - 1));
            b.append(puData.charAt(i));
            switch (i) {
                case 1: b.append('v'); break;
                case 2: push(b, keyAt(dateStr, 2)); break;
                case 3: push(b, keyByPid(programId, 6)); break;
                case 4: b.append('a'); break;
                default: break;
            }
        }
        return b.toString();
    }

    /** 抽出 playurl 返回的 &puData= 之后的内容（原样照搬 split 行为）。 */
    public static String puDataOf(String url) {
        if (url == null) return "";
        int p = url.indexOf("&puData=");
        if (p < 0) return "";
        return url.substring(p + "&puData=".length());
    }

    /** getddCalcuURL(url, pid, "android", rateType, userId)。 */
    public static String encryptUrlAndroid(String rawUrl, String pid, int rateType,
                                            String userId, String dateStr) {
        String puData = puDataOf(rawUrl);
        if (puData.isEmpty() || pid == null || pid.isEmpty()) return "";
        return rawUrl + "&ddCalcu=" + ddCalcuAndroid(puData, pid, rateType, userId, dateStr)
                + SUFFIX_ANDROID;
    }

    /** getddCalcuURL720p(url, pid)。 */
    public static String encryptUrlGuest720p(String rawUrl, String pid, String dateStr) {
        String puData = puDataOf(rawUrl);
        if (puData.isEmpty() || pid == null || pid.isEmpty()) return "";
        return rawUrl + "&ddCalcu=" + ddCalcu720p(puData, pid, dateStr) + SUFFIX_ANDROID;
    }

    /** 账号路径的请求头（androidURL.js getAndroidURL）。 */
    public static Map<String, String> accountHeaders(String userId, String token,
                                                      String pid, int rateType) {
        LinkedHashMap<String, String> h = new LinkedHashMap<>();
        h.put("AppVersion", "2600037000");
        h.put("TerminalId", "android");
        h.put("X-UP-CLIENT-CHANNEL-ID", "2600037000-99000-200300220100002");
        if (!NO_APPCODE_PIDS.contains(pid)) h.put("appCode", "miguvideo_default_android");
        if (sendsAccount(userId, token, rateType)) {
            h.put("UserId", userId);
            h.put("UserToken", token);
        }
        return h;
    }

    public static Map<String, String> guest720pHeaders(String pid) {
        LinkedHashMap<String, String> h = new LinkedHashMap<>();
        h.put("AppVersion", APP_VERSION_GUEST);
        h.put("TerminalId", "android");
        h.put("X-UP-CLIENT-CHANNEL-ID", APP_VERSION_GUEST + "-99000-201600010010028");
        if (!NO_APPCODE_PIDS.contains(pid)) h.put("appCode", "miguvideo_default_android");
        return h;
    }

    public static boolean sendsAccount(String userId, String token, int rateType) {
        return rateType != 2 && userId != null && !userId.isEmpty()
                && token != null && !token.isEmpty();
    }

    /** 账号/画质参数拼接（androidURL.js requestPlayurl）。 */
    public static String playParams(String sign, int rateType, String pid, long timestamp,
                                    String salt, boolean enableH265, boolean enableHdr,
                                    String extra) {
        StringBuilder s = new StringBuilder();
        s.append("?sign=").append(sign)
         .append("&rateType=").append(rateType)
         .append("&contId=").append(pid)
         .append("&timestamp=").append(timestamp)
         .append("&salt=").append(salt)
         .append("&flvEnable=true&super4k=true");
        if (enableH265) s.append("&h265N=true");
        if (enableHdr) s.append("&4kvivid=true&2Kvivid=true&vivid=2");
        if (extra != null) s.append(extra);
        return s.toString();
    }

    // ==================== 频道列表整形 ====================

    /** 分类内按频道名去重（fetchList.js uniqueData）。 */
    public static void uniqueInGroup(Group g) {
        Set<String> seen = new HashSet<>();
        List<Channel> out = new ArrayList<>();
        for (Channel c : g.channels) if (seen.add(c.name)) out.add(c);
        g.channels.clear();
        g.channels.addAll(out);
    }

    /** 咪咕「地方」分组重分配 + 全局排除 + 整组跳过（index.js redistributeMiguLocalChannels）。 */
    public static List<Group> redistributeLocal(List<Group> groups) {
        List<Group> out = new ArrayList<>();
        for (Group g : groups) {
            if ("综艺".equals(g.name) || "熊猫".equals(g.name)) continue;
            List<Channel> kept = new ArrayList<>();
            for (Channel c : g.channels) {
                if (!EXCLUSIONS.contains(c.name)) kept.add(c);
            }
            if (!"地方".equals(g.name)) {
                appendGroup(out, g.name, kept);
                continue;
            }
            for (Channel c : kept) {
                String target = REASSIGNMENTS.get(c.name);
                if (target != null) {
                    Channel copy = copy(c);
                    copy.group = target;
                    appendGroup(out, target, java.util.Collections.singletonList(copy));
                }
                String[] sup = SUPPLEMENTS.get(c.name);
                if (sup != null) {
                    Channel copy = copy(c);
                    copy.group = sup[0];
                    if (!sup[1].isEmpty()) copy.name = sup[1];
                    appendGroup(out, sup[0], java.util.Collections.singletonList(copy));
                }
            }
        }
        return out;
    }

    private static void appendGroup(List<Group> out, String name, List<Channel> add) {
        if (add.isEmpty()) return;
        Group existing = null;
        for (Group g : out) if (g.name.equals(name)) { existing = g; break; }
        if (existing == null) { existing = new Group(name); out.add(existing); }
        existing.channels.addAll(add);
    }

    private static Channel copy(Channel c) {
        Channel n = new Channel(c.name, c.group);
        n.pid = c.pid; n.url = c.url; n.logo = c.logo; n.tvgId = c.tvgId; n.source = c.source;
        return n;
    }

    /**
     * 跨分组按 pID 去重，先出现者胜；CCTV5 / CCTV5+ 在「体育」「央视」各保留一份。
     * （index.js dedupeAcrossGroups）
     */
    public static List<Group> dedupeAcrossGroups(List<Group> groups) {
        Set<String> seen = new HashSet<>();
        Set<String> seenExceptions = new HashSet<>();
        List<Group> out = new ArrayList<>();
        for (Group g : groups) {
            boolean allowBoth = "体育".equals(g.name) || "央视".equals(g.name);
            Group ng = new Group(g.name);
            for (Channel c : g.channels) {
                String key = c.pid;
                boolean isCctv5 = "CCTV5体育".equals(c.name) || "CCTV5+体育赛事".equals(c.name);
                if (allowBoth && isCctv5) {
                    if (!seenExceptions.add(key + "::" + g.name)) continue;
                    seen.add(key);
                    ng.channels.add(c);
                } else if (seen.add(key)) {
                    ng.channels.add(c);
                }
            }
            if (!ng.channels.isEmpty()) out.add(ng);
        }
        return out;
    }

    /** 一次跑完整条整形链：分类内去重 → 地方重分配 → 跨组去重。 */
    public static List<Group> shape(List<Group> raw) {
        for (Group g : raw) uniqueInGroup(g);
        return dedupeAcrossGroups(redistributeLocal(raw));
    }
}
