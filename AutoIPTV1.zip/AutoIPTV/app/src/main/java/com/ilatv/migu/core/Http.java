package com.ilatv.migu.core;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** 只依赖 HttpURLConnection 的轻量 GET；core 层零第三方依赖，便于 JVM 单测。 */
public final class Http {
    private Http() {}

    public static class Response {
        public int code;
        public String body = "";
        public String location = "";
    }

    public static String get(String url, Map<String, String> headers, int timeoutMs) throws Exception {
        return getFull(url, headers, timeoutMs, true).body;
    }

    /** follow=false 时手动读 302 Location（对应参考项目 get302URL 的 redirect:'manual'）。 */
    public static Response getFull(String url, Map<String, String> headers,
                                   int timeoutMs, boolean follow) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(timeoutMs);
        c.setReadTimeout(timeoutMs);
        c.setInstanceFollowRedirects(follow);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) iLaTV-Migu/1.0");
        if (headers != null) {
            for (Map.Entry<String, String> e : headers.entrySet()) {
                c.setRequestProperty(e.getKey(), e.getValue());
            }
        }
        Response r = new Response();
        try {
            r.code = c.getResponseCode();
            r.location = nullToEmpty(c.getHeaderField("Location"));
            InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) r.body = readAll(in);
        } finally {
            c.disconnect();
        }
        return r;
    }

    /** 取调度地址的 Location；最多 attempts 次，跳过 http://bofang 开头的回环。 */
    public static String resolve302(String url, int attempts, int timeoutMs) {
        for (int i = 1; i <= attempts; i++) {
            try {
                Response r = getFull(url, null, timeoutMs, false);
                String loc = r.location;
                if (!loc.isEmpty() && !loc.startsWith("http://bofang")) return loc;
            } catch (Exception ignored) {
                // 参考项目同样是吞错后重试
            }
            try { Thread.sleep(150); } catch (InterruptedException ignored) {}
        }
        return "";
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    private static String nullToEmpty(String s) { return s == null ? "" : s; }
}
