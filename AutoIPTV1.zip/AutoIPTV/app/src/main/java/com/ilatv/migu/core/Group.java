package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.List;

public class Group {
    public String name;
    public final List<Channel> channels = new ArrayList<>();

    public Group() {}
    public Group(String name) { this.name = name == null ? "其他" : name.trim(); }

    public int size() { return channels.size(); }
}
