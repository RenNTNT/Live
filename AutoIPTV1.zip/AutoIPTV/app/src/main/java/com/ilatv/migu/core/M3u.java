package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用 M3U / M3U8 播放列表解析：用于「订阅模式」——把你自己部署的
 * akiralereal/iptv（或任意合法 M3U/XMLTV 源）的 interface.m3u 接进 App。
 *
 * 支持：
 *   #EXTM3U 头属性（catchup / catchup-days / x-tvg-url 等，存进 header 供后续用）
 *   #EXTINF:-1 tvg-id="" tvg-logo="" group-title="" catchup="",显示名
 *   #EXTGRP:分组名（部分源用它代替 group-title）
 *   #EXTVLCOPT: / #KODIPROP: 等选项行跳过，不影响取下一行地址
 *   Kodi 风格 catchup-type / tvg-rec / timeshift 原样收进 attrs
 */
public final class M3u {
    private M3u() {}

    public static class Playlist {
        public final Map<String, String> header = new LinkedHashMap<>();
        public final List<Channel> channels = new ArrayList<>();
        public final List<Group> groups = new ArrayList<>();
    }

    public static Playlist parse(String text) {
        Playlist p = new Playlist();
        if (text == null || text.isEmpty()) return p;
        String[] lines = text.replace("\r\n", "\n").replace('\r', '\n').split("\n");
        Map<String, String> pending = null;
        String pendingName = "";
        String extGrp = "";
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTM3U")) {
                // #EXTM3U 后面直接跟属性，没有冒号（#EXTINF 才有）
                p.header.putAll(attrs(line.substring("#EXTM3U".length())));
                continue;
            }
            if (line.startsWith("#EXTINF")) {
                int c = line.indexOf(':');
                pending = attrs(c >= 0 ? line.substring(c + 1) : "");
                int comma = line.lastIndexOf(',');
                pendingName = comma >= 0 ? line.substring(comma + 1).trim() : "";
                extGrp = "";
                continue;
            }
            if (line.startsWith("#EXTGRP")) {
                extGrp = afterColon(line).trim();
                continue;
            }
            if (line.startsWith("#EXTVLCOPT:") || line.startsWith("#KODIPROP:")) {
                // 播放所需请求头，收进当前条目的属性里（缓冲提示类选项省略不写回订阅）
                if (pending != null) {
                    String opt = afterColon(line);
                    int eq = opt.indexOf('=');
                    if (eq > 0) pending.put(opt.substring(0, eq).trim(), opt.substring(eq + 1).trim());
                }
                continue;
            }
            if (line.startsWith("#")) continue; // 其它选项行 / 注释
            if (pending == null) continue;      // 地址前面没有 EXTINF，忽略

            Channel ch = new Channel();
            ch.source = Channel.SRC_SUBSCRIPTION;
            ch.url = line;
            ch.name = pendingName.isEmpty() ? pending.getOrDefault("tvg-name", line) : pendingName;
            ch.group = firstNonEmpty(pending.get("group-title"), extGrp, "其他");
            ch.logo = pending.getOrDefault("tvg-logo", "");
            ch.tvgId = pending.getOrDefault("tvg-id", "");
            ch.attrs.putAll(pending);
            if (ch.valid()) p.channels.add(ch);
            pending = null; pendingName = ""; extGrp = "";
        }
        // 按出现顺序聚合分组
        Map<String, Group> byName = new LinkedHashMap<>();
        for (Channel c : p.channels) {
            Group g = byName.get(c.group);
            if (g == null) { g = new Group(c.group); byName.put(c.group, g); }
            g.channels.add(c);
        }
        p.groups.addAll(byName.values());
        return p;
    }

    private static String afterColon(String line) {
        int c = line.indexOf(':');
        return c >= 0 ? line.substring(c + 1) : "";
    }

    private static String firstNonEmpty(String... vals) {
        for (String v : vals) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "";
    }

    /** 解析 key="value" 属性串；EXTINF 的时长部分（-1 ...）会被自然跳过。 */
    public static Map<String, String> attrs(String s) {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        int i = 0, n = s.length();
        while (i < n) {
            while (i < n && Character.isWhitespace(s.charAt(i))) i++;
            int start = i;
            while (i < n && s.charAt(i) != '=' && !Character.isWhitespace(s.charAt(i))) i++;
            if (i >= n || s.charAt(i) != '=') { i++; continue; }
            String key = s.substring(start, i).trim();
            i++; // '='
            if (i >= n) break;
            char q = s.charAt(i);
            String val;
            if (q == '"' || q == '\'') {
                i++;
                int vs = i;
                while (i < n && s.charAt(i) != q) i++;
                val = s.substring(vs, i);
                if (i < n) i++;
            } else {
                int vs = i;
                while (i < n && !Character.isWhitespace(s.charAt(i))) i++;
                val = s.substring(vs, i);
            }
            if (!key.isEmpty() && !key.startsWith("-")) m.put(key, val);
        }
        return m;
    }
}
