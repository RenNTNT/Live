package com.ilatv.migu;

import com.ilatv.migu.core.Channel;
import com.ilatv.migu.core.Group;
import com.ilatv.migu.core.Json;
import com.ilatv.migu.core.Line;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 聚合结果落盘：对齐 Docker 版「咪咕失败宁可保留上一份播放列表也不要覆盖」的语义。
 * 用 JSON 保存全部线路（含 deferred pID，不存有时效的签名地址），重启 App 立即可用。
 */
public class DiskCache {
    private final File file;

    public DiskCache(File dir) { file = new File(dir, "playlist-cache.json"); }

    public void save(List<Group> groups) {
        try {
            StringBuilder b = new StringBuilder("{\"groups\":[");
            for (int i = 0; i < groups.size(); i++) {
                Group g = groups.get(i);
                if (i > 0) b.append(',');
                b.append("{\"name\":").append(q(g.name)).append(",\"channels\":[");
                for (int k = 0; k < g.channels.size(); k++) {
                    Channel c = g.channels.get(k);
                    if (k > 0) b.append(',');
                    b.append("{\"name\":").append(q(c.name))
                     .append(",\"group\":").append(q(c.group))
                     .append(",\"logo\":").append(q(c.logo))
                     .append(",\"tvgId\":").append(q(c.tvgId))
                     .append(",\"lines\":[");
                    for (int j = 0; j < c.lines.size(); j++) {
                        Line l = c.lines.get(j);
                        if (j > 0) b.append(',');
                        b.append("{\"sourceId\":").append(q(l.sourceId))
                         .append(",\"sourceName\":").append(q(l.sourceName))
                         .append(",\"kind\":").append(l.kind)
                         .append(",\"ref\":").append(q(l.ref))
                         .append(",\"group\":").append(q(l.group))
                         .append(",\"headers\":{");
                        int hi = 0;
                        for (Map.Entry<String, String> e : l.headers.entrySet()) {
                            if (hi++ > 0) b.append(',');
                            b.append(q(e.getKey())).append(':').append(q(e.getValue()));
                        }
                        b.append("}}");
                    }
                    b.append("]}");
                }
                b.append("]}");
            }
            b.append("]}");
            byte[] data = b.toString().getBytes(StandardCharsets.UTF_8);
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(data); }
        } catch (Exception ignored) {}
    }

    public List<Group> load() {
        List<Group> out = new ArrayList<>();
        if (!file.exists()) return out;
        try {
            byte[] data = new byte[(int) file.length()];
            try (FileInputStream in = new FileInputStream(file)) {
                int n = in.read(data);
                if (n <= 0) return out;
            }
            Object root = Json.parse(new String(data, 0, data.length, StandardCharsets.UTF_8));
            List<Object> gs = Json.list(Json.at(root, "groups"));
            if (gs == null) return out;
            for (Object go : gs) {
                Group g = new Group(Json.strAt(go, "name"));
                List<Object> cs = Json.list(Json.at(go, "channels"));
                if (cs == null) continue;
                for (Object co : cs) {
                    Channel c = new Channel(Json.strAt(co, "name"), Json.strAt(co, "group"));
                    c.logo = Json.strAt(co, "logo");
                    c.tvgId = Json.strAt(co, "tvgId");
                    List<Object> ls = Json.list(Json.at(co, "lines"));
                    if (ls != null) for (Object lo : ls) {
                        Line l = new Line();
                        l.sourceId = Json.strAt(lo, "sourceId");
                        l.sourceName = Json.strAt(lo, "sourceName");
                        l.kind = Json.intAt(lo, 0, "kind");
                        l.ref = Json.strAt(lo, "ref");
                        l.group = Json.strAt(lo, "group");
                        Map<String, Object> hm = Json.map(Json.at(lo, "headers"));
                        if (hm != null) for (Map.Entry<String, Object> e : hm.entrySet()) {
                            l.headers.put(e.getKey(), Json.str(e.getValue()));
                        }
                        if (l.valid()) c.addLine(l);
                    }
                    if (c.playable()) g.channels.add(c);
                }
                if (!g.channels.isEmpty()) out.add(g);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static String q(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "") + "\"";
    }
}
