package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 极简 JSON 解析器：只依赖 JDK，Android 与桌面 JVM 都能直接编译。
 * 参考项目的咪咕模块用 Node 的 resp.body.xxx，这里用同一套取值助手替代，
 * 避免把 org.json（Android 内置、桌面 JVM 没有）带进 core 层，方便离线跑单测。
 *
 * 解析结果类型：LinkedHashMap / ArrayList / String / Long / Double / Boolean / null
 */
public final class Json {
    private Json() {}

    public static Object parse(String text) {
        if (text == null) throw new IllegalArgumentException("json is null");
        return new Parser(text).parseValue();
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> list(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    /** 按 key 逐层下钻，任一层缺失返回 null。 */
    public static Object at(Object root, String... keys) {
        Object cur = root;
        for (String k : keys) {
            Map<String, Object> m = map(cur);
            if (m == null) return null;
            cur = m.get(k);
        }
        return cur;
    }

    public static String str(Object o) {
        if (o == null) return "";
        if (o instanceof String) return (String) o;
        if (o instanceof Number || o instanceof Boolean) return String.valueOf(o);
        return "";
    }

    public static String strAt(Object root, String... keys) {
        return str(at(root, keys));
    }

    public static int intAt(Object root, int fallback, String... keys) {
        Object v = at(root, keys);
        if (v instanceof Number) return ((Number) v).intValue();
        if (v instanceof String) {
            try { return Integer.parseInt(((String) v).trim()); } catch (Exception ignored) {}
        }
        return fallback;
    }

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) { this.s = s; }

        Object parseValue() {
            skipWs();
            if (i >= s.length()) throw err("unexpected end");
            char c = s.charAt(i);
            switch (c) {
                case '{': return parseObject();
                case '[': return parseArray();
                case '"': return parseString();
                case 't': expect("true"); return Boolean.TRUE;
                case 'f': expect("false"); return Boolean.FALSE;
                case 'n': expect("null"); return null;
                default: return parseNumber();
            }
        }

        private Map<String, Object> parseObject() {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            i++; // {
            skipWs();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                skipWs();
                if (i >= s.length() || s.charAt(i) != '"') throw err("expected key");
                String key = parseString();
                skipWs();
                if (i >= s.length() || s.charAt(i) != ':') throw err("expected ':'");
                i++;
                m.put(key, parseValue());
                skipWs();
                if (i >= s.length()) throw err("unclosed object");
                char c = s.charAt(i++);
                if (c == '}') return m;
                if (c != ',') throw err("expected ',' or '}'");
            }
        }

        private List<Object> parseArray() {
            ArrayList<Object> a = new ArrayList<>();
            i++; // [
            skipWs();
            if (i < s.length() && s.charAt(i) == ']') { i++; return a; }
            while (true) {
                a.add(parseValue());
                skipWs();
                if (i >= s.length()) throw err("unclosed array");
                char c = s.charAt(i++);
                if (c == ']') return a;
                if (c != ',') throw err("expected ',' or ']'");
            }
        }

        private String parseString() {
            i++; // opening quote
            StringBuilder b = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    if (i >= s.length()) throw err("bad escape");
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"': b.append('"'); break;
                        case '\\': b.append('\\'); break;
                        case '/': b.append('/'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'n': b.append('\n'); break;
                        case 'r': b.append('\r'); break;
                        case 't': b.append('\t'); break;
                        case 'u':
                            if (i + 4 > s.length()) throw err("bad \\u escape");
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                            break;
                        default: throw err("bad escape \\" + e);
                    }
                } else {
                    b.append(c);
                }
            }
            throw err("unclosed string");
        }

        private Object parseNumber() {
            int start = i;
            while (i < s.length() && "-+.eE0123456789".indexOf(s.charAt(i)) >= 0) i++;
            String n = s.substring(start, i);
            if (n.isEmpty()) throw err("expected value at " + start);
            if (n.indexOf('.') < 0 && n.indexOf('e') < 0 && n.indexOf('E') < 0) {
                try { return Long.parseLong(n); } catch (Exception ignored) {}
            }
            return Double.parseDouble(n);
        }

        private void expect(String word) {
            if (!s.regionMatches(i, word, 0, word.length())) throw err("expected " + word);
            i += word.length();
        }

        private void skipWs() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\t' || c == '\r' || c == '\n') i++;
                else break;
            }
        }

        private IllegalArgumentException err(String msg) {
            return new IllegalArgumentException("JSON at " + i + ": " + msg);
        }
    }
}
