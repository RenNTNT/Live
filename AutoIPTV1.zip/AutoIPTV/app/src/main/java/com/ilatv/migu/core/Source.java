package com.ilatv.migu.core;

import java.util.List;

/**
 * 一个「内置抓取模块」——对应 Docker 版源管理里可独立开关的卡片。
 * 每个模块自己负责抓频道列表与播放时解析，聚合层不关心来源细节。
 */
public interface Source {
    String id();
    String name();
    boolean enabled();
    void setEnabled(boolean on);

    /** 抓本模块的频道列表；失败抛异常，由 Engine 记状态并保留上一份缓存。 */
    List<Channel> fetch() throws Exception;

    /** 播放时把线路解析成真实可播地址。 */
    String resolve(Line line) throws Exception;

    /** 本轮抓到多少频道、失败原因，供「源健康状态」展示。 */
    int lastCount();
    String lastError();
}
