package com.ilatv.migu.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 一条播放线路。对齐 Docker 版「播放时解析」的 deferred ref 设计：
 * M3U 里写本机 /migu/<pID>，播放器真正请求时才现取带签名的地址并 302 过去。
 */
public class Line {
    /** 直接给出播放地址（自定义 M3U / TXT 源）。 */
    public static final int KIND_URL = 0;
    /** 延迟解析：咪咕 pID，播放时走 MiguApi.resolve。 */
    public static final int KIND_MIGU_PID = 1;

    public String sourceId = "";
    public String sourceName = "";
    public int kind = KIND_URL;
    /** KIND_URL 时是播放地址；KIND_MIGU_PID 时是裸 pID。 */
    public String ref = "";
    public String group = "";
    public final Map<String, String> headers = new LinkedHashMap<>();

    public Line() {}

    public static Line url(String sourceId, String sourceName, String url, String group) {
        Line l = new Line();
        l.sourceId = sourceId; l.sourceName = sourceName;
        l.kind = KIND_URL; l.ref = url == null ? "" : url;
        l.group = group == null ? "其他" : group;
        return l;
    }

    public static Line miguPid(String pid) {
        Line l = new Line();
        l.sourceId = "migu"; l.sourceName = "咪咕 · 游客";
        l.kind = KIND_MIGU_PID; l.ref = pid == null ? "" : pid;
        return l;
    }

    public boolean valid() { return ref != null && !ref.isEmpty(); }

    public String label() {
        return sourceName.isEmpty() ? sourceId : sourceName;
    }
}
