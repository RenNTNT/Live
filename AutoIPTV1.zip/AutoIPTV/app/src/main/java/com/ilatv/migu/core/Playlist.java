package com.ilatv.migu.core;

import java.util.List;

/**
 * 生成 M3U 播放列表，等价于 Docker 版的 /interface.m3u 输出。
 *
 * 标准版：咪咕线路写成本机 /migu/<pID>，播放器请求时由内置服务现取签名地址并 302，
 *         M3U 里不含任何有时效的第三方签名，列表可以缓存很久。
 * 兼容版：每条线路现在就解析成真实地址直出，给不跟随 302 的老播放器用。
 *
 * 同名频道输出多条 #EXTINF（播放器按名聚合成「源1 / 源2」），与 Docker 版一致。
 * 本工程不提供回看，所以每条都标 catchup="none"。
 */
public final class Playlist {
    private Playlist() {}

    public interface Resolver {
        String resolve(Line line) throws Exception;
    }

    public static final int STANDARD = 0;
    public static final int COMPAT = 1;

    public static String build(List<Group> groups, String baseUrl, int relay, Resolver resolver) {
        StringBuilder b = new StringBuilder();
        b.append("#EXTM3U\n");
        String base = baseUrl == null ? "" : trimSlash(baseUrl);
        if (groups == null) return b.toString();
        for (Group g : groups) {
            for (Channel c : g.channels) {
                if (!c.playable()) continue;
                for (Line l : c.lines) {
                    String addr = address(l, base, relay, resolver);
                    if (addr.isEmpty()) continue;
                    b.append("#EXTINF:-1");
                    attr(b, "tvg-id", c.tvgId.isEmpty() ? c.name : c.tvgId);
                    attr(b, "tvg-name", c.name);
                    attr(b, "tvg-logo", c.logo);
                    attr(b, "group-title", c.group);
                    b.append(" catchup=\"none\"");
                    b.append(',').append(c.name);
                    if (c.lines.size() > 1) b.append(" · ").append(l.label());
                    b.append('\n');
                    b.append(addr).append('\n');
                }
            }
        }
        return b.toString();
    }

    private static String address(Line l, String base, int relay, Resolver resolver) {
        if (l == null || !l.valid()) return "";
        if (l.kind == Line.KIND_URL) return l.ref;
        // 咪咕 deferred
        if (relay == COMPAT && resolver != null) {
            try {
                String real = resolver.resolve(l);
                if (real != null && !real.isEmpty()) return real;
            } catch (Exception ignored) {
                // 解析失败回落 deferred，不让整个列表生成中断
            }
        }
        if (base.isEmpty()) return "";
        return base + "/migu/" + l.ref;
    }

    private static void attr(StringBuilder b, String key, String value) {
        if (value == null || value.isEmpty()) return;
        b.append(' ').append(key).append("=\"").append(value.replace("\"", "'")).append('"');
    }

    private static String trimSlash(String s) {
        String t = s.trim();
        while (t.endsWith("/")) t = t.substring(0, t.length() - 1);
        return t;
    }
}
