package com.ilatv.migu.core;

/** 直连模式的可选参数，与参考项目 configSchema 对齐；默认全部游客 / 720p / H.264 友好。 */
public class MiguConfig {
    public static final int MODE_SUBSCRIPTION = 0; // 默认：接自己部署的 iPTV 订阅
    public static final int MODE_DIRECT = 1;       // 规则移植：直连咪咕接口

    public int mode = MODE_SUBSCRIPTION;
    public String subscriptionUrl = "";
    public String userId = "";
    public String token = "";
    public int rateType = 3;              // 2 标清 / 3 高清 / 4 蓝光 / 7 原画 / 9 4K
    public boolean enableH265 = true;
    public boolean enableHdr = true;
    public boolean enableClientDispatch = false;
    public int timeoutMs = 12000;

    public boolean hasAccount() {
        return userId != null && !userId.trim().isEmpty()
                && token != null && !token.trim().isEmpty();
    }
}
