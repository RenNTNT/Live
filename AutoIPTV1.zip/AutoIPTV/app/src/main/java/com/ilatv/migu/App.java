package com.ilatv.migu;

import android.app.Application;

/** 全局一份引擎：抓取缓存、分发服务、聚合结果在列表页与播放页之间共享。 */
public class App extends Application {
    private Prefs prefs;
    private Engine engine;

    @Override public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        engine = new Engine(this, prefs);
        engine.init();
    }

    public Prefs prefs() { return prefs; }
    public Engine engine() { return engine; }

    @Override public void onTerminate() {
        if (engine != null) engine.shutdown();
        super.onTerminate();
    }
}
