package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 咪咕「播放时解析」的 Java 实现，逐条对照参考项目：
 *   utils/fetchList.js                 cateList / dataList / uniqueData
 *   extractors/migu/index.js           fetch + shouldFailRound + 分组整形
 *   extractors/migu/resolve.js         pID → 签名地址 + 3 小时缓存
 *   extractors/migu/androidURL.js      getAndroidURL / getAndroidURL720p / get302URL
 *
 * 只做游客与「本人账号」两条取流路径；不实现共享账号注入、试看绕过或地域限制绕过。
 * 账号信息只由使用本人在本机填写，不随工程分发。
 */
public final class MiguApi {
    private final MiguConfig cfg;
    private final Map<String, CacheEntry> cache = new HashMap<>();
    private final Random rnd = new Random();

    private static final class CacheEntry {
        final String url;
        final long expireAt;
        CacheEntry(String url, long ttl) {
            this.url = url;
            this.expireAt = System.currentTimeMillis() + ttl;
        }
        boolean live() { return System.currentTimeMillis() < expireAt; }
    }

    public MiguApi(MiguConfig cfg) { this.cfg = cfg == null ? new MiguConfig() : cfg; }

    public void clearResolveCache() { cache.clear(); }

    // ---------------- 频道列表 ----------------

    /** 抓全部分组并完成去重 / 重分配，失败时抛异常让调用方保留上一份列表。 */
    public List<Group> fetchGroups() throws MiguException {
        String body;
        try {
            body = Http.get(MiguRules.CATE_LIST_URL, null, cfg.timeoutMs);
        } catch (Exception e) {
            throw new MiguException("咪咕分类接口不可达：" + e.getMessage(), e);
        }
        Object root;
        try { root = Json.parse(body); }
        catch (Exception e) { throw new MiguException("咪咕分类接口返回不是合法 JSON", e); }

        List<Object> liveList = Json.list(Json.at(root, "liveList"));
        if (liveList == null || liveList.isEmpty()) {
            throw new MiguException("咪咕分类接口无响应（liveList 为空）");
        }

        List<Group> groups = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        for (Object cate : liveList) {
            String name = Json.strAt(cate, "name");
            if ("热门".equals(name)) continue; // 热门内容是重复项
            String vomsId = Json.strAt(cate, "vomsID");
            if (name.isEmpty() || vomsId.isEmpty()) continue;
            try {
                String b = Http.get(MiguRules.CATE_BASE + vomsId, null, cfg.timeoutMs);
                List<Object> items = Json.list(Json.at(Json.parse(b), "dataList"));
                Group g = new Group(name);
                if (items != null) {
                    for (Object item : items) {
                        Channel c = new Channel(Json.strAt(item, "name"), name);
                        c.source = Channel.SRC_DIRECT;
                        c.pid = Json.strAt(item, "pID");
                        c.tvgId = c.pid;
                        c.logo = pickPic(Json.at(item, "pics"));
                        if (c.valid()) g.channels.add(c);
                    }
                }
                if (!g.channels.isEmpty()) groups.add(g);
            } catch (Exception e) {
                failed.add(name); // 单个分类失败不连累其余分类
            }
        }

        int count = 0;
        for (Group g : groups) count += g.size();
        if (count == 0 && !failed.isEmpty()) {
            throw new MiguException("咪咕分类数据本轮全部抓取失败（" + failed.size()
                    + " 个分类）：网络不可达或接口异常");
        }
        return MiguRules.shape(groups);
    }

    private static String pickPic(Object pics) {
        if (pics == null) return "";
        if (pics instanceof String) return (String) pics;
        if (pics instanceof List) {
            for (Object o : (List<?>) pics) {
                String s = pickPic(o);
                if (!s.isEmpty()) return s;
            }
            return "";
        }
        if (pics instanceof Map) {
            for (String k : new String[]{"url", "pic", "src", "href", "logo"}) {
                String s = Json.strAt(pics, k);
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    // ---------------- 播放地址 ----------------

    /**
     * 频道 → 可播地址。订阅模式直接返回列表里的地址；直连模式按参考项目规则现取。
     * 缓存键是裸 pID，成功 3 小时、失败 1 分钟（与 resolve.js 一致）。
     */
    public String resolve(Channel ch) throws MiguException {
        if (ch == null || !ch.valid()) throw new MiguException("频道数据为空");
        if (ch.source == Channel.SRC_SUBSCRIPTION) return ch.url;

        String pid = ch.pid;
        CacheEntry hit = cache.get(pid);
        if (hit != null && hit.live()) {
            if (hit.url.isEmpty()) throw new MiguException("该频道暂不可用（缓存中），稍后自动重试");
            return hit.url;
        }

        String url;
        try {
            url = resolveDirect(pid);
        } catch (MiguException e) {
            cache.put(pid, new CacheEntry("", 60_000L));
            throw e;
        }

        // 客户端就近取流：跳过服务端 302 解析，直接把调度地址交给播放器
        if (!cfg.enableClientDispatch) {
            String loc = Http.resolve302(url, 6, Math.min(cfg.timeoutMs, 6000));
            if (!loc.isEmpty()) url = loc;
        }
        cache.put(pid, new CacheEntry(url, 3 * 60 * 60 * 1000L));
        return url;
    }

    private String resolveDirect(String pid) throws MiguException {
        long ts = System.currentTimeMillis();
        boolean guestPath = cfg.rateType >= 3 && !cfg.hasAccount();
        return guestPath ? resolveGuest720p(pid, ts) : resolveAccount(pid, ts);
    }

    /** 游客 720p 路径（androidURL.js getAndroidURL720p + resolve.js 默认分支）。 */
    private String resolveGuest720p(String pid, long ts) throws MiguException {
        String salt = MiguRules.guestSalt(rnd);
        String sign = MiguRules.guestSign(ts, pid, salt);
        String params = MiguRules.playParams(sign, 3, pid, ts, salt,
                cfg.enableH265, cfg.enableHdr, "");
        Object resp = requestPlayurl(params, MiguRules.guest720pHeaders(pid));
        String raw = Json.strAt(resp, "body", "urlInfo", "url");
        if (raw.isEmpty()) throw refuseReason(pid, resp);
        String realPid = Json.strAt(resp, "body", "content", "contId");
        if (realPid.isEmpty()) realPid = pid;
        String url = MiguRules.encryptUrlGuest720p(raw, realPid,
                MiguRules.dateString(new Date(ts)));
        if (url.isEmpty()) throw new MiguException(pid + " 播放地址缺少 puData 参数，无法完成校验");
        return url;
    }

    /** 账号 / 指定画质路径（androidURL.js getAndroidURL）。 */
    private String resolveAccount(String pid, long ts) throws MiguException {
        String sign = MiguRules.accountSign(ts, pid);
        String salt = String.valueOf(MiguRules.accountSalt());
        Map<String, String> headers = MiguRules.accountHeaders(
                cfg.userId, cfg.token, pid, cfg.rateType);

        Object resp = requestPlayurl(
                MiguRules.playParams(sign, cfg.rateType, pid, ts, salt,
                        cfg.enableH265, cfg.enableHdr, ""), headers);

        // TIPS_NEED_MEMBER：按咪咕愿意给的档位降一档，仍被拒再兜底高清
        if ("TIPS_NEED_MEMBER".equals(Json.strAt(resp, "rid"))) {
            int offered = Json.intAt(resp, 0, "body", "urlInfo", "rateType");
            int fallback = offered >= 4 ? 4 : 3;
            resp = requestPlayurl(
                    MiguRules.playParams(sign, fallback, pid, ts, salt,
                            cfg.enableH265, cfg.enableHdr, ""), headers);
            if ("TIPS_NEED_MEMBER".equals(Json.strAt(resp, "rid")) && fallback != 3) {
                resp = requestPlayurl(
                        MiguRules.playParams(sign, 3, pid, ts, salt,
                                cfg.enableH265, cfg.enableHdr, ""), headers);
            }
        }

        String raw = Json.strAt(resp, "body", "urlInfo", "url");
        if (raw.isEmpty()) throw refuseReason(pid, resp);
        String realPid = Json.strAt(resp, "body", "content", "contId");
        if (realPid.isEmpty()) realPid = pid;
        String url = MiguRules.encryptUrlAndroid(raw, realPid, cfg.rateType,
                cfg.userId, MiguRules.dateString(new Date(ts)));
        if (url.isEmpty()) throw new MiguException(pid + " 播放地址缺少 puData 参数，无法完成校验");
        return url;
    }

    private Object requestPlayurl(String params, Map<String, String> headers)
            throws MiguException {
        try {
            String body = Http.get(MiguRules.PLAY_URL + params, headers, cfg.timeoutMs);
            return Json.parse(body);
        } catch (Exception e) {
            throw new MiguException("咪咕接口请求失败：网络超时或不可达，请检查到 miguvideo.com 的网络", e);
        }
    }

    /** 把上游拒绝原因翻译成看得懂的话（对应 resolve.js failDesc / RID_HINTS / loginHint）。 */
    private static MiguException refuseReason(String pid, Object resp) {
        String rid = Json.strAt(resp, "rid");
        String msg = Json.strAt(resp, "message");
        if (msg.isEmpty()) msg = Json.strAt(resp, "desc");
        if (msg.isEmpty()) msg = "节目调整，暂不提供服务";
        if ("COPYRIGHT_SHIELD_INVALID".equals(rid)) {
            msg += "（咪咕版权屏蔽：当前节目无版权，通常节目结束后自动恢复）";
        } else if ("TIPS_NEED_LOGIN".equals(rid)) {
            msg += "（游客看不了这个频道，请填入本人咪咕账号；VIP 频道需会员权益）";
        }
        return new MiguException(pid + " " + msg);
    }
}
