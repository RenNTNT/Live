package com.ilatv.migu.core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * 端上分发服务：让 App 自己就是那台「Docker 服务器」。
 * 电视机 / 同一局域网里其它播放器直接订阅 http://设备IP:1905/interface.m3u。
 *
 * 纯 JDK ServerSocket，零第三方依赖，core 层可直接 JVM 单测。
 * 只监听本机 / 局域网，不做任何鉴权之外的对外暴露；请勿把端口映射到公网。
 */
public class LocalServer {
    public interface Provider {
        /** 生成 M3U；base 形如 http://192.168.1.5:1905，relay 见 Playlist.STANDARD / COMPAT。 */
        String m3u(String base, int relay);
        /** 咪咕 pID → 真实地址，失败返回空串。 */
        String resolveMigu(String pid);
        String statusJson();
        void refreshAsync();
    }

    private final int port;
    private final Provider provider;
    private volatile ServerSocket server;
    private volatile Thread acceptThread;
    private volatile boolean running;

    public LocalServer(int port, Provider provider) {
        this.port = port;
        this.provider = provider;
    }

    public boolean isRunning() { return running && server != null; }
    public int port() { return port; }

    public synchronized void start() throws Exception {
        if (running) return;
        server = new ServerSocket(port, 32, InetAddress.getByName("0.0.0.0"));
        running = true;
        acceptThread = new Thread(this::acceptLoop, "autoiptv-http");
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public synchronized void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        server = null;
        if (acceptThread != null) acceptThread.interrupt();
        acceptThread = null;
    }

    private void acceptLoop() {
        while (running && server != null) {
            try {
                Socket s = server.accept();
                s.setSoTimeout(8000);
                Thread t = new Thread(() -> handle(s), "autoiptv-req");
                t.setDaemon(true);
                t.start();
            } catch (Exception e) {
                if (running) continue;
                return;
            }
        }
    }

    private void handle(Socket s) {
        try (Socket sock = s) {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(sock.getInputStream(), StandardCharsets.UTF_8));
            String line = in.readLine();
            if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String path = parts[1];
            String host = "http://" + localHost() + ":" + port;
            // 优先用请求里的 Host，反代 / 域名访问时也能给出正确地址
            String h;
            while ((h = in.readLine()) != null && !h.isEmpty()) {
                if (h.toLowerCase().startsWith("host:")) {
                    String hv = h.substring(5).trim();
                    if (!hv.isEmpty()) host = "http://" + hv;
                    break;
                }
            }
            route(path, host, sock);
        } catch (Exception ignored) {
            // 单个请求异常不影响服务
        }
    }

    private void route(String rawPath, String host, Socket sock) throws Exception {
        String path = rawPath;
        int q = path.indexOf('?');
        String query = q >= 0 ? path.substring(q + 1) : "";
        if (q >= 0) path = path.substring(0, q);

        if ("/".equals(path) || "/index.html".equals(path)) {
            String html = "<!doctype html><meta charset='utf-8'><title>AutoIPTV</title>"
                    + "<h2>AutoIPTV 本机分发服务</h2>"
                    + "<p>标准版：<a href='/interface.m3u'>/interface.m3u</a></p>"
                    + "<p>兼容版：<a href='/interface.m3u?relay=1'>/interface.m3u?relay=1</a></p>"
                    + "<p>状态：<a href='/api/status'>/api/status</a></p>"
                    + "<p>请把完整订阅地址填进播放器：" + esc(host) + "/interface.m3u</p>";
            write(sock, 200, "text/html; charset=utf-8", html);
            return;
        }
        if ("/interface.m3u".equals(path) || "/m3u".equals(path)) {
            int relay = query.contains("relay=1") ? Playlist.COMPAT : Playlist.STANDARD;
            write(sock, 200, "application/vnd.apple.mpegurl; charset=utf-8",
                    provider.m3u(host, relay));
            return;
        }
        if (path.startsWith("/migu/")) {
            String pid = path.substring("/migu/".length());
            String url = provider.resolveMigu(pid);
            if (url == null || url.isEmpty()) {
                write(sock, 502, "text/plain; charset=utf-8", "咪咕取流失败：" + pid);
            } else {
                write(sock, 302, "text/plain", "", "Location: " + url + "\r\n");
            }
            return;
        }
        if ("/api/status".equals(path)) {
            write(sock, 200, "application/json; charset=utf-8", provider.statusJson());
            return;
        }
        if ("/api/refresh".equals(path)) {
            provider.refreshAsync();
            write(sock, 200, "application/json; charset=utf-8", "{\"ok\":true}");
            return;
        }
        if ("/health".equals(path)) { write(sock, 200, "text/plain", "ok"); return; }
        write(sock, 404, "text/plain; charset=utf-8", "not found");
    }

    private static void write(Socket s, int code, String type, String body) throws Exception {
        write(s, code, type, body, "");
    }

    private static void write(Socket s, int code, String type, String body, String extra)
            throws Exception {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String reason = code == 200 ? "OK" : code == 302 ? "Found"
                : code == 404 ? "Not Found" : "Bad Gateway";
        OutputStream out = s.getOutputStream();
        out.write(("HTTP/1.1 " + code + " " + reason + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + b.length + "\r\n"
                + extra
                + "Connection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(b);
        out.flush();
    }

    private String localHost() {
        try {
            InetAddress a = InetAddress.getLocalHost();
            return a.getHostAddress();
        } catch (Exception e) {
            return "127.0.0.1";
        }
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;");
    }
}
