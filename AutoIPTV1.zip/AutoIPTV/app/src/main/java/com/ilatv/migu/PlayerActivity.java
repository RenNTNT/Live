package com.ilatv.migu;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.ilatv.migu.core.Channel;
import com.ilatv.migu.core.Line;

/** 播放页：把聚合后的某条线路解析成真实地址再交给 ExoPlayer；失败自动切下一路。 */
public class PlayerActivity extends Activity {

    private App app;
    private SurfaceView surface;
    private TextView status, osd;
    private ExoPlayer player;
    private Channel channel;
    private int lineIndex = 0;
    private boolean resolving = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = (App) getApplication();
        buildUi();
        channel = app.engine().findChannel(getIntent().getStringExtra("name"));
        if (channel == null || !channel.playable()) {
            status.setText("找不到这个频道或没有可用线路，返回列表刷新后再试");
            return;
        }
        playCurrent();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        surface = new SurfaceView(this);
        root.addView(surface, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Color.parseColor("#660a0e16"));
        TextView title = new TextView(this);
        title.setText(nullToEmpty(getIntent().getStringExtra("name")));
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setPadding(dp(18), dp(10), dp(18), dp(10));
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button next = new Button(this);
        next.setText("切线路");
        next.setTextSize(13);
        next.setTextColor(Color.WHITE);
        next.setBackgroundColor(Color.parseColor("#2d7dff"));
        next.setOnClickListener(v -> nextLine());
        top.addView(next);
        root.addView(top, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        osd = new TextView(this);
        osd.setTextColor(Color.parseColor("#cfd8e6"));
        osd.setTextSize(14);
        osd.setPadding(dp(18), dp(8), dp(18), dp(12));
        root.addView(osd, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#cfd8e6"));
        status.setTextSize(17);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.addView(status, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setContentView(root);
    }

    private void playCurrent() {
        if (channel == null || isFinishing() || resolving) return;
        Line l = channel.line(lineIndex);
        if (l == null) { status.setText("没有可用线路"); return; }
        resolving = true;
        status.setText("正在取流…");
        osd.setText("源 " + (lineIndex + 1) + "/" + channel.lines.size() + " · " + l.label());
        new Thread(() -> {
            String url = "";
            String err = "";
            try { url = app.engine().resolveLine(l); }
            catch (Exception e) { err = e.getMessage() == null ? "取流失败" : e.getMessage(); }
            final String u = url, em = err;
            runOnUiThread(() -> {
                resolving = false;
                if (u.isEmpty()) {
                    status.setText("取流失败：" + em + "\n正在尝试下一条线路…");
                    nextLine();
                } else {
                    startPlayer(u, l);
                }
            });
        }, "autoiptv-resolve").start();
    }

    private void startPlayer(String url, Line l) {
        if (url.toLowerCase().contains(".flv")) {
            status.setText("这条线路是 FLV，内置内核未带 FLV 解封装。\n正在尝试下一条线路…");
            nextLine();
            return;
        }
        status.setText("");
        releasePlayer();
        DefaultHttpDataSource.Factory ds = new DefaultHttpDataSource.Factory()
                .setConnectTimeoutMs(12000)
                .setReadTimeoutMs(12000)
                .setAllowCrossProtocolRedirects(true);
        if (!l.headers.isEmpty()) ds.setDefaultRequestProperties(l.headers);
        player = new ExoPlayer.Builder(this).build();
        player.setVideoSurfaceView(surface);
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException e) {
                status.setText("播放失败：" + e.getErrorCodeName() + "\n正在尝试下一条线路…");
                nextLine();
            }
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) status.setText("");
                else if (state == Player.STATE_BUFFERING) status.setText("缓冲中…");
            }
        });
        player.setMediaSource(new DefaultMediaSourceFactory(ds)
                .createMediaSource(MediaItem.fromUri(url)));
        player.prepare();
        player.setPlayWhenReady(true);
        osd.setText("源 " + (lineIndex + 1) + "/" + channel.lines.size() + " · " + l.label()
                + "\n菜单键 / 「切线路」换源 · 返回键退出");
    }

    private void nextLine() {
        if (channel == null || channel.lines.isEmpty()) return;
        int next = (lineIndex + 1) % channel.lines.size();
        if (next == lineIndex) {
            status.setText("所有线路都取流失败，请回列表刷新或检查网络 / 来源授权");
            return;
        }
        lineIndex = next;
        playCurrent();
    }

    private void releasePlayer() {
        if (player != null) { player.release(); player = null; }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) { finish(); return true; }
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
            nextLine(); return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onStop() { super.onStop(); releasePlayer(); }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String nullToEmpty(String s) { return s == null ? "" : s; }
}
