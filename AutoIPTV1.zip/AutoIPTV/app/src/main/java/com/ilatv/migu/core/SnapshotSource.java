package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.List;

/**
 * 离线兜底源：从打包进 APK 的 assets/IPTV.m3u 快照生成频道。
 *
 * 存在的理由很直接：在线源（咪咕接口、仓库清单）都可能因地区网络 / DNS / 网关策略
 * 全部不可达，上一版就会「一个台都没有」。这个源不联网、永不失败，只在其它源
 * 全部失败时由 Engine 注入，保证列表至少不空白、播放链路可验证。
 *
 * 快照来自 akiralereal/iptv 仓库公开的精选直连清单，可能过期；是否可用请自行确认
 * 授权与地址有效性，可在设置里整体关闭。
 */
public class SnapshotSource implements Source {
    private final String m3uText;
    private boolean enabled = true;
    private int lastCount = 0;
    private String lastError = "";

    public SnapshotSource(String m3uText) {
        this.m3uText = m3uText == null ? "" : m3uText;
    }

    @Override public String id() { return "snapshot"; }
    @Override public String name() { return "离线兜底快照（20 台）"; }
    @Override public boolean enabled() { return enabled; }
    @Override public void setEnabled(boolean on) { enabled = on; }
    @Override public int lastCount() { return lastCount; }
    @Override public String lastError() { return lastError; }

    @Override public List<Channel> fetch() throws Exception {
        lastError = "";
        M3u.Playlist p = M3u.parse(m3uText);
        List<Channel> out = new ArrayList<>();
        for (Channel raw : p.channels) {
            Channel c = new Channel(raw.name, raw.group);
            c.logo = raw.logo;
            c.tvgId = raw.tvgId;
            c.epgId = raw.tvgId;
            c.attrs.putAll(raw.attrs);
            Line l = Line.url("snapshot", "离线快照", raw.url, raw.group);
            l.headers.putAll(M3uSource.toHeaders(raw.attrs));
            c.addLine(l);
            if (c.playable()) out.add(c);
        }
        lastCount = out.size();
        if (out.isEmpty()) throw new MiguException("离线快照为空");
        return out;
    }

    @Override public String resolve(Line line) throws Exception {
        if (line == null || line.kind != Line.KIND_URL) throw new MiguException("线路不是直连地址");
        return line.ref;
    }
}
