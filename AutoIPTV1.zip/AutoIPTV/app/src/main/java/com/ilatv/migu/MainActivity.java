package com.ilatv.migu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.ilatv.migu.core.Aggregator;
import com.ilatv.migu.core.Channel;
import com.ilatv.migu.core.Group;

import java.util.ArrayList;
import java.util.List;

/** 启动即自动抓列表、生成分组；点频道进播放页。纯 Java 动态构建，遥控器与触屏都能用。 */
public class MainActivity extends Activity implements Engine.Listener {

    private App app;
    private TextView status, subLine;
    private LinearLayout groupBar;
    private ListView list;
    private ChannelAdapter adapter;
    private final List<Group> shown = new ArrayList<>();
    private int currentGroup = 0;
    private String query = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = (App) getApplication();
        buildUi();
        app.engine().setListener(this);
        if (!app.prefs().noticeShown()) showNotice();
        updateUi();
    }

    @Override protected void onDestroy() {
        app.engine().setListener(null);
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0b0d12"));
        root.setPadding(dp(16), dp(12), dp(16), dp(8));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("聚合直播");
        title.setTextColor(Color.parseColor("#ff6b4a"));
        title.setTextSize(24);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        EditText search = new EditText(this);
        search.setHint("搜台 / 分组");
        search.setHintTextColor(Color.parseColor("#6b7688"));
        search.setTextColor(Color.WHITE);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setBackgroundColor(Color.parseColor("#161b26"));
        search.setPadding(dp(10), dp(6), dp(10), dp(6));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { query = s.toString(); updateUi(); }
        });
        top.addView(search, new LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT));
        top.addView(smallBtn("刷新", v -> app.engine().requestRefresh()));
        top.addView(smallBtn("设置", v -> showSettings()));
        root.addView(top);

        status = lineText("");
        root.addView(status);

        subLine = lineText("");
        subLine.setTextColor(Color.parseColor("#7fb2ff"));
        root.addView(subLine);
        LinearLayout subBtns = new LinearLayout(this);
        subBtns.setOrientation(LinearLayout.HORIZONTAL);
        subBtns.addView(smallBtn("复制订阅地址", v -> copySubscription()));
        subBtns.addView(smallBtn("导出 M3U", v -> exportM3u()));
        root.addView(subBtns);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        groupBar = new LinearLayout(this);
        groupBar.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(groupBar);
        root.addView(hs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        list = new ListView(this);
        list.setDividerHeight(dp(1));
        list.setCacheColorHint(Color.TRANSPARENT);
        adapter = new ChannelAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            Channel c = (Channel) adapter.getItem(pos);
            if (c != null) openChannel(c.name);
        });
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        TextView tip = lineText("自动抓取 · 自动聚合 · 免登录 · 同名频道多线路可在播放页切换");
        root.addView(tip);
        setContentView(root);
    }

    // ---------------- 数据展示 ----------------

    @Override public void onChanged() { runOnUiThread(this::updateUi); }

    private void updateUi() {
        Engine e = app.engine();
        List<Group> base = e.groups();
        shown.clear();
        shown.addAll(query.trim().isEmpty() ? base : Aggregator.search(base, query));
        if (currentGroup >= shown.size()) currentGroup = 0;

        Aggregator.Result r = e.lastResult();
        StringBuilder st = new StringBuilder();
        if (e.isRefreshing()) st.append("正在抓取…  ");
        st.append(shown.size()).append(" 组 · ");
        int ch = 0, ln = 0;
        for (Group g : shown) { ch += g.size(); for (Channel c : g.channels) ln += c.lines.size(); }
        st.append(ch).append(" 台 · ").append(ln).append(" 路");
        if (!query.trim().isEmpty()) st.append("（搜索中）");
        st.append(" · ").append(e.lastUpdate());
        if (r.failedSources > 0) {
            st.append(" · ").append(r.failedSources).append(" 个源失败");
            String w = e.firstWarning();
            if (!w.isEmpty()) st.append("（").append(w).append("）");
        }
        if (e.usedSnapshot()) st.append(" · 已启用离线快照（地址可能过期）");
        if (base.isEmpty() && !e.isRefreshing()) {
            st.append(" · 在线源全不可达：到「设置」改清单地址，或确认网络能否访问上游");
        }
        status.setText(st.toString());

        String url = e.subscriptionUrl();
        subLine.setText((e.serverRunning() ? "分发中  " : "分发未开启  ") + url
                + "   （其余播放器订阅这个地址）");
        buildGroupBar();
        adapter.notifyDataSetChanged();
    }

    private void buildGroupBar() {
        groupBar.removeAllViews();
        for (int i = 0; i < shown.size(); i++) {
            final int idx = i;
            Button b = new Button(this);
            b.setText(shown.get(i).name + " (" + shown.get(i).size() + ")");
            b.setTextSize(14);
            b.setTextColor(i == currentGroup ? Color.WHITE : Color.parseColor("#9aa6b8"));
            b.setBackgroundColor(i == currentGroup
                    ? Color.parseColor("#2d7dff") : Color.parseColor("#1a2130"));
            b.setPadding(dp(12), dp(4), dp(12), dp(4));
            b.setOnClickListener(v -> { currentGroup = idx; buildGroupBar(); adapter.notifyDataSetChanged(); });
            groupBar.addView(b);
        }
    }

    private void openChannel(String name) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("name", name);
        startActivity(it);
    }

    private void copySubscription() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("m3u", app.engine().subscriptionUrl()));
        toast("已复制订阅地址");
    }

    private void exportM3u() {
        String path = app.engine().exportM3u();
        toast(path.isEmpty() ? "导出失败" : "已导出：" + path);
    }

    // ---------------- 设置 / 源管理 ----------------

    private void showSettings() {
        Prefs p = app.prefs();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(10));

        final CheckBox migu = check("自动抓取：咪咕视频（免登录，可能被地区网络拦）", p.miguOn());
        final CheckBox repo = check("自动抓取：精选频道清单（20 台）", p.repoOn());
        final CheckBox web = check("自动抓取：网络分享清单（76 台，来源待确认）", p.webOn());
        final CheckBox snap = check("离线兜底快照（在线源全挂时保证不空白）", p.snapshotOn());
        final CheckBox h265 = check("启用 H.265（有声无画时关掉）", p.h265());
        final CheckBox hdr = check("启用 HDR 参数", p.hdr());
        final CheckBox dispatch = check("客户端就近取流（跨运营商）", p.clientDispatch());
        final CheckBox srv = check("开启本机分发服务（/interface.m3u）", p.serverOn());
        box.addView(migu); box.addView(repo); box.addView(web); box.addView(snap);
        box.addView(h265); box.addView(hdr);
        box.addView(dispatch); box.addView(srv);

        // 大陆网络常连不上 raw.githubusercontent.com，这里允许改成本人可达的镜像 / 自建地址
        final EditText repoUrl = input(p.repoUrl(), "精选清单地址", false);
        final EditText webUrl = input(p.webUrl(), "网络分享清单地址", false);
        box.addView(label("精选清单地址（可换成自己的镜像）")); box.addView(repoUrl);
        box.addView(label("网络分享清单地址")); box.addView(webUrl);

        final EditText port = input(String.valueOf(p.port()), "分发端口，默认 1905", false);
        port.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(label("分发端口")); box.addView(port);
        final EditText mins = input(String.valueOf(p.refreshMinutes()), "自动刷新间隔（分钟），默认 360", false);
        mins.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(label("自动刷新间隔（分钟）")); box.addView(mins);

        box.addView(label("自定义 M3U / TXT 订阅源（每行：名称,地址；行首 # 表示停用）"));
        final EditText subs = input("", "", false);
        subs.setSingleLine(false);
        subs.setMinLines(3);
        subs.setMaxLines(6);
        subs.setGravity(Gravity.TOP);
        subs.setText(subsToText(p.subs()));
        box.addView(subs);

        final EditText block = input(p.blockKeywords(), "按台名屏蔽，逗号分隔", false);
        final EditText hide = input(p.hiddenGroups(), "隐藏分组，逗号分隔", false);
        final EditText keep = input(p.keepKeywords(), "只保留这些台名（留空不启用），逗号分隔", false);
        box.addView(label("屏蔽规则（按名字，源换址也生效）")); box.addView(block);
        box.addView(label("隐藏分组")); box.addView(hide);
        box.addView(label("只保留匹配项")); box.addView(keep);

        TextView note = lineText("全部模块免登录，工程不内置账号 / Token / 频道地址。"
                + "请只接入你已获授权的来源；分发服务仅限局域网，别把端口映射到公网。");
        note.setTextColor(Color.parseColor("#ff8a6a"));
        box.addView(note);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle("源管理 · 聚合设置")
                .setView(sv)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存并重新抓取", (d, w) -> {
                    p.setMiguOn(migu.isChecked());
                    p.setRepoOn(repo.isChecked());
                    p.setWebOn(web.isChecked());
                    p.setSnapshotOn(snap.isChecked());
                    p.setRepoUrl(repoUrl.getText().toString());
                    p.setWebUrl(webUrl.getText().toString());
                    p.setH265(h265.isChecked());
                    p.setHdr(hdr.isChecked());
                    p.setClientDispatch(dispatch.isChecked());
                    p.setServerOn(srv.isChecked());
                    p.setPort(parseInt(port.getText().toString(), 1905));
                    p.setRefreshMinutes(Math.max(5, parseInt(mins.getText().toString(), 360)));
                    p.setSubs(parseSubs(subs.getText().toString()));
                    p.setBlockKeywords(block.getText().toString());
                    p.setHiddenGroups(hide.getText().toString());
                    p.setKeepKeywords(keep.getText().toString());
                    app.engine().reloadConfig();
                    toast("已保存，正在重新抓取");
                })
                .show();
    }

    private String subsToText(List<Prefs.Sub> list) {
        StringBuilder b = new StringBuilder();
        for (Prefs.Sub s : list) {
            if (!s.enabled) b.append('#');
            b.append(s.name).append(',').append(s.url).append('\n');
        }
        return b.toString();
    }

    private List<Prefs.Sub> parseSubs(String text) {
        List<Prefs.Sub> out = new ArrayList<>();
        int i = 0;
        for (String raw : text.split("\n")) {
            String s = raw.trim();
            if (s.isEmpty()) continue;
            boolean on = true;
            if (s.startsWith("#")) { on = false; s = s.substring(1).trim(); }
            int comma = s.indexOf(',');
            if (comma <= 0) continue;
            String name = s.substring(0, comma).trim();
            String url = s.substring(comma + 1).trim();
            if (!url.startsWith("http")) continue;
            out.add(new Prefs.Sub("sub" + (++i), name.isEmpty() ? "订阅" + i : name, url, on));
        }
        return out;
    }

    private void showNotice() {
        new AlertDialog.Builder(this)
                .setTitle("使用须知")
                .setMessage("App 启动会自动抓取 3 个源（咪咕免登录模块 + 两份公开频道清单）、"
                        + "聚合去重、生成分组列表，并可选在 1905 端口分发 /interface.m3u。\n\n"
                        + "在线源全不可达时自动启用离线快照，保证列表不空白；快照里的地址可能过期，"
                        + "可在「设置」里改清单地址或关掉任一模块。\n\n"
                        + "全部模块免登录，不含账号 / Token / Cookie。清单来自公开仓库，其中「网络分享」"
                        + "部分来源待确认，请自行确认合法授权后再使用。")
                .setPositiveButton("我知道了", (d, w) -> app.prefs().setNoticeShown())
                .setCancelable(false)
                .show();
    }

    // ---------------- 小工具 ----------------

    private Button smallBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#1e2533"));
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        b.setOnClickListener(l);
        return b;
    }

    private TextView lineText(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.parseColor("#8b96a9"));
        t.setTextSize(12);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView label(String s) {
        TextView t = lineText(s);
        t.setTextSize(13);
        t.setPadding(0, dp(10), 0, dp(2));
        return t;
    }

    private EditText input(String value, String hint, boolean password) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.parseColor("#6b7688"));
        e.setTextSize(14);
        e.setSingleLine(true);
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    private CheckBox check(String text, boolean value) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextColor(Color.parseColor("#c9d3e2"));
        c.setTextSize(13);
        c.setChecked(value);
        return c;
    }

    private static int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private class ChannelAdapter extends BaseAdapter {
        private List<Channel> cur() {
            if (shown.isEmpty() || currentGroup >= shown.size()) return new ArrayList<>();
            return shown.get(currentGroup).channels;
        }
        @Override public int getCount() { return cur().size(); }
        @Override public Object getItem(int p) { return cur().get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public View getView(int p, View v, ViewGroup parent) {
            TextView t = v instanceof TextView ? (TextView) v : new TextView(MainActivity.this);
            Channel c = cur().get(p);
            StringBuilder s = new StringBuilder((p + 1) + ".  " + c.name);
            s.append("\n").append(c.lines.size()).append(" 路");
            for (int i = 0; i < c.lines.size() && i < 3; i++) {
                s.append(" · ").append(c.lines.get(i).label());
            }
            t.setText(s.toString());
            t.setTextColor(Color.parseColor("#dfe6f2"));
            t.setTextSize(16);
            t.setPadding(dp(12), dp(9), dp(12), dp(9));
            t.setBackgroundColor(Color.parseColor("#141a25"));
            t.setMinHeight(dp(58));
            return t;
        }
    }
}
