package com.ilatv.migu.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 自定义 M3U / TXT 订阅模块（对应 Docker 版「自定义源」卡片）。
 * 可添加多个，每个独立开关；地址由使用者自己填写，工程不内置任何第三方频道地址。
 * 免登录：纯 GET 公开列表，不需要任何凭据。
 */
public class M3uSource implements Source {
    private final String id;
    private final String name;
    private final String url;
    private boolean enabled = true;
    private int lastCount = 0;
    private String lastError = "";
    private int timeoutMs = 12000;

    public M3uSource(String id, String name, String url) {
        this.id = id;
        this.name = name == null || name.trim().isEmpty() ? id : name.trim();
        this.url = url == null ? "" : url.trim();
    }

    @Override public String id() { return id; }
    @Override public String name() { return name; }
    @Override public boolean enabled() { return enabled; }
    @Override public void setEnabled(boolean on) { enabled = on; }
    @Override public int lastCount() { return lastCount; }
    @Override public String lastError() { return lastError; }
    public String url() { return url; }
    public void setTimeout(int ms) { timeoutMs = ms; }

    @Override public List<Channel> fetch() throws Exception {
        lastError = "";
        if (url.isEmpty()) throw new MiguException("订阅地址为空");
        String body = Http.get(url, null, timeoutMs);
        M3u.Playlist p = M3u.parse(body);
        List<Channel> out = new ArrayList<>();
        for (Channel raw : p.channels) {
            Channel c = new Channel(raw.name, raw.group);
            c.logo = raw.logo;
            c.tvgId = raw.tvgId;
            c.epgId = raw.tvgId;
            c.attrs.putAll(raw.attrs);
            Line l = Line.url(id, name, raw.url, raw.group);
            l.headers.clear();
            l.headers.putAll(toHeaders(raw.attrs));
            c.addLine(l);
            if (c.playable()) out.add(c);
        }
        // 纯 TXT 兜底：每行「名称,地址」或「名称 地址」
        if (out.isEmpty()) out.addAll(parseTxt(body));
        lastCount = out.size();
        if (out.isEmpty()) throw new MiguException("订阅内容为空或格式不识别");
        return out;
    }

    private List<Channel> parseTxt(String body) {
        List<Channel> out = new ArrayList<>();
        if (body == null) return out;
        for (String raw : body.replace("\r\n", "\n").split("\n")) {
            String s = raw.trim();
            if (s.isEmpty() || s.startsWith("#")) continue;
            String nm = "", addr = "";
            int comma = s.indexOf(',');
            if (comma > 0) { nm = s.substring(0, comma).trim(); addr = s.substring(comma + 1).trim(); }
            else if (s.startsWith("http")) { addr = s; nm = s.substring(s.lastIndexOf('/') + 1); }
            if (!addr.startsWith("http")) continue;
            Channel c = new Channel(nm.isEmpty() ? addr : nm, "自定义");
            c.addLine(Line.url(id, name, addr, "自定义"));
            out.add(c);
        }
        return out;
    }

    /** 只转发播放真正需要的请求头，忽略缓冲提示类选项。 */
    public static Map<String, String> toHeaders(Map<String, String> attrs) {
        java.util.LinkedHashMap<String, String> h = new java.util.LinkedHashMap<>();
        put(h, attrs, "http-referrer", "Referer");
        put(h, attrs, "http-user-agent", "User-Agent");
        put(h, attrs, "user-agent", "User-Agent");
        put(h, attrs, "http-origin", "Origin");
        String extra = attrs.get("http-header");
        if (extra != null && extra.contains(":")) {
            int p = extra.indexOf(':');
            h.put(extra.substring(0, p).trim(), extra.substring(p + 1).trim());
        }
        return h;
    }

    private static void put(Map<String, String> h, Map<String, String> a, String k, String target) {
        String v = a.get(k);
        if (v != null && !v.isEmpty()) h.put(target, v);
    }

    @Override public String resolve(Line line) throws Exception {
        if (line == null || line.kind != Line.KIND_URL) throw new MiguException("线路不是直连地址");
        return line.ref;
    }
}
