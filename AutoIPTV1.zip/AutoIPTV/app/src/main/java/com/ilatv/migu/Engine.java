package com.ilatv.migu;

import android.content.Context;

import com.ilatv.migu.core.Aggregator;
import com.ilatv.migu.core.Channel;
import com.ilatv.migu.core.Group;
import com.ilatv.migu.core.Line;
import com.ilatv.migu.core.LocalServer;
import com.ilatv.migu.core.M3uSource;
import com.ilatv.migu.core.MiguSource;
import com.ilatv.migu.core.Playlist;
import com.ilatv.migu.core.SnapshotSource;
import com.ilatv.migu.core.Source;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 编排引擎：App 启动即自动抓取 → 聚合编排 → 生成列表 → 分发 / 播放。
 * 把 Docker 版那套「源管理 + 聚合 + /interface.m3u 分发」搬进端上，全部免登录。
 */
public class Engine implements LocalServer.Provider {
    private final Context ctx;
    private final Prefs prefs;
    private final DiskCache cache;
    private volatile List<Source> sources = new ArrayList<>();
    private volatile SnapshotSource snapshot;
    private volatile List<Group> groups = new ArrayList<>();
    private volatile Aggregator.Result last = new Aggregator.Result();
    private volatile String lastUpdate = "尚未抓取";
    private volatile boolean refreshing = false;
    private volatile boolean usedSnapshot = false;
    private volatile Listener listener;
    private LocalServer server;
    private ScheduledExecutorService timer;

    public interface Listener { void onChanged(); }

    public Engine(Context ctx, Prefs prefs) {
        this.ctx = ctx.getApplicationContext();
        this.prefs = prefs;
        this.cache = new DiskCache(this.ctx.getFilesDir());
    }

    public void setListener(Listener l) { listener = l; }

    /** App 启动调用：先恢复缓存（秒开列表），再异步抓一轮，再定时刷新。 */
    public void init() {
        rebuildSources();
        List<Group> cached = cache.load();
        if (!cached.isEmpty()) { groups = cached; fire(); }
        requestRefresh();
        scheduleRefresh();
        restartServer();
    }

    public void reloadConfig() {
        rebuildSources();
        scheduleRefresh();
        restartServer();
        requestRefresh();
    }

    private void rebuildSources() {
        MiguSource migu = new MiguSource();
        migu.setEnabled(prefs.miguOn());
        migu.setH265(prefs.h265());
        migu.setHdr(prefs.hdr());
        migu.setClientDispatch(prefs.clientDispatch());
        List<Source> list = new ArrayList<>();
        list.add(migu);
        // Docker 版「内置源」的机制：运行时从公开清单地址现抓，不把频道地址写死在代码里
        M3uSource repo = new M3uSource("repo", "精选频道（自动抓取）", prefs.repoUrl());
        repo.setEnabled(prefs.repoOn());
        list.add(repo);
        M3uSource web = new M3uSource("web", "网络分享（自动抓取）", prefs.webUrl());
        web.setEnabled(prefs.webOn());
        list.add(web);
        for (Prefs.Sub s : prefs.subs()) {
            M3uSource m = new M3uSource(s.id, s.name, s.url);
            m.setEnabled(s.enabled);
            list.add(m);
        }
        sources = list;
        if (snapshot == null) snapshot = new SnapshotSource(readSnapshot());
        snapshot.setEnabled(prefs.snapshotOn());
    }

    /** 从 assets 读离线兜底快照；读不到时返回空串，不影响其它源。 */
    private String readSnapshot() {
        try (InputStream in = ctx.getAssets().open("IPTV.m3u")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void scheduleRefresh() {
        if (timer != null) timer.shutdownNow();
        timer = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "autoiptv-timer"); t.setDaemon(true); return t;
        });
        int minutes = Math.max(5, prefs.refreshMinutes());
        timer.scheduleAtFixedRate(this::requestRefresh, minutes, minutes, TimeUnit.MINUTES);
    }

    public boolean isRefreshing() { return refreshing; }
    public List<Group> groups() { return groups; }
    public Aggregator.Result lastResult() { return last; }
    public String lastUpdate() { return lastUpdate; }
    public boolean usedSnapshot() { return usedSnapshot; }
    /** 本轮失败源的可读原因，给状态行显示，避免「一个台都没有」却看不出为什么。 */
    public String firstWarning() {
        return last.warnings.isEmpty() ? "" : last.warnings.get(0);
    }

    public void requestRefresh() {
        if (refreshing) return;
        refreshing = true;
        fire();
        Thread t = new Thread(() -> {
            try { refreshNow(); }
            finally { refreshing = false; fire(); }
        }, "autoiptv-fetch");
        t.setDaemon(true);
        t.start();
    }

    /** 抓一轮并返回是否至少有一个模块成功。 */
    public boolean refreshNow() {
        List<Aggregator.FetchResult> results = new ArrayList<>();
        for (Source s : sources) {
            if (!s.enabled()) continue;
            Aggregator.FetchResult fr = new Aggregator.FetchResult(s.id(), s.name());
            try {
                List<Channel> got = s.fetch();
                fr.channels.addAll(got);
            } catch (Exception e) {
                fr.error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            }
            results.add(fr);
        }
        // 关键修复：在线源一个台都没拿到时，注入离线快照，避免「装上一个台都没有」。
        // 上一版只有咪咕一个内置源，遇到接口 403 / 地区网络不通就整份列表空白。
        usedSnapshot = false;
        if (noOnlineChannels(results) && snapshot != null && snapshot.enabled()) {
            Aggregator.FetchResult snap = new Aggregator.FetchResult(snapshot.id(), snapshot.name());
            try {
                snap.channels.addAll(snapshot.fetch());
            } catch (Exception e) {
                snap.error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            }
            results.add(snap);
            usedSnapshot = snap.ok();
        }

        Aggregator.Result r = Aggregator.aggregate(results, prefs.rules());
        last = r;
        lastUpdate = new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.CHINA)
                .format(new java.util.Date());
        // 只要有台就更新；一份都没有时保留上一份缓存（对齐 Docker 的 critical 语义）
        if (r.channelCount > 0) {
            groups = r.groups;
            cache.save(groups);
            return true;
        }
        return false;
    }

    private static boolean noOnlineChannels(List<Aggregator.FetchResult> results) {
        for (Aggregator.FetchResult fr : results) {
            if (fr.ok() && !fr.channels.isEmpty()) return false;
        }
        return true;
    }

    public String resolveLine(Line l) throws Exception {
        if (l == null || !l.valid()) throw new Exception("线路为空");
        for (Source s : sources) {
            if (s.id().equals(l.sourceId)) return s.resolve(l);
        }
        // 源被删掉后缓存里的线路仍能按 kind 兜底
        if (l.kind == Line.KIND_URL) return l.ref;
        MiguSource m = new MiguSource();
        m.setH265(prefs.h265()); m.setHdr(prefs.hdr());
        return m.resolve(l);
    }

    /** 按频道名找回聚合后的频道（播放页只传名字，避免序列化整份列表）。 */
    public Channel findChannel(String name) {
        String key = Aggregator.normalize(name);
        for (Group g : groups) {
            for (Channel c : g.channels) {
                if (Aggregator.normalize(c.name).equals(key)) return c;
            }
        }
        return null;
    }

    public String subscriptionUrl() {
        return "http://" + lanIp() + ":" + prefs.port() + "/interface.m3u";
    }

    // ---------------- 分发服务 ----------------

    public void restartServer() {
        if (server != null) server.stop();
        if (!prefs.serverOn()) { server = null; return; }
        LocalServer s = new LocalServer(prefs.port(), this);
        try { s.start(); server = s; }
        catch (Exception e) { server = null; }
    }

    public boolean serverRunning() { return server != null && server.isRunning(); }

    @Override public String m3u(String base, int relay) {
        return Playlist.build(groups, base, relay, relay == Playlist.COMPAT
                ? this::resolveLine : null);
    }

    @Override public String resolveMigu(String pid) {
        try {
            Line l = Line.miguPid(pid);
            return resolveLine(l);
        } catch (Exception e) {
            return "";
        }
    }

    @Override public String statusJson() {
        StringBuilder b = new StringBuilder();
        b.append("{\"version\":\"1.0\",\"port\":").append(prefs.port())
         .append(",\"serverOn\":").append(serverRunning())
         .append(",\"subscription\":").append(q(subscriptionUrl()))
         .append(",\"lastUpdate\":").append(q(lastUpdate))
         .append(",\"refreshing\":").append(refreshing)
         .append(",\"channels\":").append(last.channelCount)
         .append(",\"lines\":").append(last.lineCount)
         .append(",\"multiLine\":").append(last.multiLineChannels)
         .append(",\"failedSources\":").append(last.failedSources)
         .append(",\"snapshotUsed\":").append(usedSnapshot)
         .append(",\"sources\":[");
        List<Source> all = new ArrayList<>(sources);
        if (snapshot != null) all.add(snapshot);
        for (int i = 0; i < all.size(); i++) {
            Source s = all.get(i);
            if (i > 0) b.append(',');
            b.append("{\"id\":").append(q(s.id()))
             .append(",\"name\":").append(q(s.name()))
             .append(",\"enabled\":").append(s.enabled())
             .append(",\"count\":").append(s.lastCount())
             .append(",\"error\":").append(q(s.lastError())).append('}');
        }
        b.append("],\"warnings\":[");
        for (int i = 0; i < last.warnings.size(); i++) {
            if (i > 0) b.append(',');
            b.append(q(last.warnings.get(i)));
        }
        b.append("]}");
        return b.toString();
    }

    @Override public void refreshAsync() { requestRefresh(); }

    /** 导出一份兼容版 M3U 到 App 私有目录，无需存储权限。 */
    public String exportM3u() {
        String text = Playlist.build(groups, "", Playlist.COMPAT, this::resolveLine);
        try {
            File f = new File(ctx.getExternalFilesDir(null), "interface.m3u");
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return "";
        }
    }

    public void shutdown() {
        if (timer != null) timer.shutdownNow();
        if (server != null) server.stop();
    }

    private void fire() {
        Listener l = listener;
        if (l != null) l.onChanged();
    }

    private String lanIp() {
        try {
            java.util.Enumeration<java.net.NetworkInterface> nis =
                    java.net.NetworkInterface.getNetworkInterfaces();
            while (nis.hasMoreElements()) {
                java.net.NetworkInterface ni = nis.nextElement();
                java.util.Enumeration<java.net.InetAddress> as = ni.getInetAddresses();
                while (as.hasMoreElements()) {
                    java.net.InetAddress a = as.nextElement();
                    if (!a.isLoopbackAddress() && a instanceof java.net.Inet4Address) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    private static String q(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
