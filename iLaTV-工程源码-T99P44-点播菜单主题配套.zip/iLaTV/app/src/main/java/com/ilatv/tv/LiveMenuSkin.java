package com.ilatv.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 播放页弹窗统一皮肤（v97 直播功能菜单 / v98 收窄卡片 / v99 点播播放菜单共用）。
 *
 * <p>点播播放页的「播放菜单 / 画面比例 / 解码方式」v99 也接入同一套，
 * 与直播功能菜单、选台抽屉、节目表弹窗不再各用一套配色。
 *
 * <p>v96 已经把选台抽屉、菜单键节目表弹窗、OSD 统一到 {@link LiveTheme}，
 * 但功能菜单仍用系统 {@link AlertDialog} 的默认容器：各家 ROM 渲染成一块灰色大底 +
 * 系统蓝字按钮，和深蓝灰圆角卡片拼在一起像两代皮肤（真机截图里最明显）。
 * 这里把「壳」也换成 LiveTheme：CARD 圆角描边卡片、主题色「关闭 ×」、
 * 底部主题色动作按钮、三级文字、5 套主题联动、跟着「字体大小」缩放。
 *
 * <p>刻意只换容器，不换内部逻辑：仍然返回 {@link AlertDialog}，
 * {@code LivePicker.trackDialog()} 的模态计数、遥控器焦点、返回键关闭、
 * 点条目 dismiss 全部原样保留，字幕/输入框/ListView 的交互一行未动。
 * 纯代码建 UI，不依赖 res/layout 与各家 ROM 的 AlertDialog 主题。
 */
public final class LiveMenuSkin {

    private LiveMenuSkin() {}

    /** 一次套皮的结果：root 交给 AlertDialog.setView，close 由 show() 绑定 dismiss。 */
    public static final class Shell {
        public final LinearLayout root;
        public final Button close;
        Shell(LinearLayout root, Button close) {
            this.root = root;
            this.close = close;
        }
    }

    // ------------------------------------------------------------------ 外壳

    /**
     * 建一张 LiveTheme 卡片：标题栏（标题 + 副标题 + 关闭×）→ 内容 → 可选动作栏 → 脚注。
     * content 由调用方给（一般是已经按 dialogListHeight() 限好高的 ScrollView 列表）。
     */
    public static Shell shell(Activity act, String title, String sub,
                              View content, View footer) {
        final int accent = LiveTheme.accent(act);
        final float k = fontScale(act);

        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = LiveTheme.stroke(act, LiveTheme.CARD,
                LiveTheme.R_CARD, 1, LiveTheme.LINE);
        root.setBackground(cardBg);
        int pad = Ui.dp(act, 20);
        root.setPadding(pad, Ui.dp(act, 18), pad, Ui.dp(act, 14));
        root.setClickable(true);   // 吃掉卡片内点击，别穿透到遮罩

        // 顶部：标题 + 副标题 + 右上角「关闭 ×」（与 EpgPanel 同构）
        LinearLayout head = new LinearLayout(act);
        head.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout headLeft = new LinearLayout(act);
        headLeft.setOrientation(LinearLayout.VERTICAL);
        TextView tv = text(act, title, 20 * k, LiveTheme.TEXT, true);
        headLeft.addView(tv);
        if (sub != null && !sub.isEmpty()) {
            TextView sv = text(act, sub, 12 * k, LiveTheme.SUB, false);
            sv.setPadding(0, Ui.dp(act, 5), 0, 0);
            headLeft.addView(sv);
        }
        head.addView(headLeft, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button close = new Button(act);
        close.setText("关闭 ×");
        close.setAllCaps(false);
        close.setTextColor(Color.WHITE);
        close.setTextSize(14 * k);
        close.setPadding(Ui.dp(act, 16), Ui.dp(act, 6), Ui.dp(act, 16), Ui.dp(act, 6));
        close.setFocusable(true);
        close.setFocusableInTouchMode(false);
        close.setBackground(buttonBg(act, accent, true, false));
        close.setOnFocusChangeListener((v, has) ->
                v.setBackground(buttonBg(act, accent, true, has)));
        head.addView(close, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(head);

        // 标题下一根主题色短线，和首页页脚 / 节目表当前态呼应
        View rule = new View(act);
        GradientDrawable ruleBg = new GradientDrawable();
        ruleBg.setColor(accent);
        ruleBg.setCornerRadius(Ui.dp(act, 2));
        rule.setBackground(ruleBg);
        LinearLayout.LayoutParams ruleLp = new LinearLayout.LayoutParams(
                Ui.dp(act, 34), Ui.dp(act, 3));
        ruleLp.topMargin = Ui.dp(act, 12);
        ruleLp.bottomMargin = Ui.dp(act, 10);
        root.addView(rule, ruleLp);

        if (content != null) {
            root.addView(content, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        if (footer != null) {
            footer.setPadding(0, Ui.dp(act, 12), 0, 0);
            root.addView(footer, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        TextView foot = text(act, "↑↓ 选择 · OK 确认 · 返回键 / 点卡片外关闭",
                11 * k, LiveTheme.FOOT, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(act, 12), 0, 0);
        root.addView(foot);

        return new Shell(root, close);
    }

    /** 底部一排可聚焦动作按钮：主操作主题色实心，次操作描边胶囊。 */
    public static View actions(Activity act, final AlertDialog[] ref,
                               String[] labels, boolean[] primary, Runnable[] acts) {
        final int accent = LiveTheme.accent(act);
        final float k = fontScale(act);
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            Button b = new Button(act);
            b.setText(labels[i]);
            b.setAllCaps(false);
            b.setTextSize(14 * k);
            b.setTextColor(primary[i] ? Color.WHITE : LiveTheme.TEXT);
            b.setPadding(0, Ui.dp(act, 9), 0, Ui.dp(act, 9));
            b.setFocusable(true);
            b.setFocusableInTouchMode(false);
            b.setBackground(buttonBg(act, accent, primary[i], false));
            b.setOnFocusChangeListener((v, has) ->
                    v.setBackground(buttonBg(act, accent, primary[idx], has)));
            b.setOnClickListener(v -> {
                if (ref != null && ref[0] != null) ref[0].dismiss();
                if (acts != null && idx < acts.length && acts[idx] != null) acts[idx].run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = Ui.dp(act, 8);
            row.addView(b, lp);
        }
        return row;
    }

    /** 一行说明文字（替代系统 setMessage，避免 ROM 把长提示渲染成灰字块）。 */
    public static View tip(Activity act, String s) {
        TextView t = text(act, s, 13 * fontScale(act), LiveTheme.SUB, false);
        t.setPadding(Ui.dp(act, 2), 0, Ui.dp(act, 2), Ui.dp(act, 10));
        return t;
    }

    /** 与卡片同色板的输入框，替代 Ui.input（后者用的是点播那套 CARD 色）。 */
    public static android.widget.EditText input(Activity act, String hint) {
        android.widget.EditText e = new android.widget.EditText(act);
        e.setHint(hint);
        e.setHintTextColor(LiveTheme.FOOT);
        e.setTextColor(LiveTheme.TEXT);
        e.setSingleLine(true);
        e.setTextSize(15 * fontScale(act));
        e.setBackground(LiveTheme.stroke(act, LiveTheme.ROW,
                LiveTheme.R_ROW, 1, LiveTheme.LINE));
        e.setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 12), Ui.dp(act, 10));
        return e;
    }

    /**
     * 创建并 show 一个已套皮的 AlertDialog：去掉系统标题栏 / 按钮栏 / 灰底，
     * 窗口背景透明、遮罩浓度对齐 EpgPanel、宽度按屏幕自适应（电视 60% / 手机 88%）。
     * 返回已显示的 dialog，调用方继续 trackDialog() 与请求焦点即可。
     */
    public static AlertDialog show(Activity act, String title, String sub,
                                   View content, View footer) {
        final AlertDialog[] ref = new AlertDialog[1];
        Shell s = shell(act, title, sub, content, footer);
        AlertDialog d = new AlertDialog.Builder(act).create();
        ref[0] = d;
        d.setView(s.root, 0, 0, 0, 0);
        s.close.setOnClickListener(v -> d.dismiss());
        d.setCanceledOnTouchOutside(true);
        d.show();

        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setDimAmount(0.72f);
            // v98：上一版 60% / 88% 在横屏与电视上拉成一条大宽卡片，收窄约 1/4。
            // 只用屏宽比例，不按 dp 设上限——电视 density 差异大，dp 上限会把卡片压得过窄。
            int sw = act.getResources().getDisplayMetrics().widthPixels;
            float wr = sw >= 1600 ? 0.44f : (sw >= 1200 ? 0.48f : 0.82f);
            w.setLayout(Math.round(sw * wr), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        return d;
    }

    // ------------------------------------------------------------------ 零件

    /** 网页后台 config.json 里 5 套主题的中文名，只用于弹窗副标题显示。 */
    public static String themeLabel(Activity act) {
        String th = "ember";
        try {
            java.io.File f = new java.io.File(act.getFilesDir(), "config.json");
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            in.close();
            if (n > 0) th = new org.json.JSONObject(new String(buf, 0, n, "UTF-8"))
                    .optString("theme", "ember");
        } catch (Exception ignored) {
        }
        if ("mint".equals(th)) return "薄荷绿";
        if ("ocean".equals(th)) return "海蓝";
        if ("violet".equals(th)) return "紫罗兰";
        if ("rose".equals(th)) return "玫瑰红";
        return "暖橙";
    }

    /** 与选台抽屉 / 节目表行一致的三档态，供订阅列表行复用 */
    public static StateListDrawable rowBg(Activity act) {
        int accent = LiveTheme.accent(act);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{ android.R.attr.state_focused },
                LiveTheme.rowBg(act, accent, true, true));
        bg.addState(new int[]{ android.R.attr.state_selected },
                LiveTheme.rowBg(act, accent, true, false));
        bg.addState(new int[]{}, LiveTheme.rowBg(act, accent, false, false));
        return bg;
    }

    private static GradientDrawable buttonBg(Activity act, int accent,
                                             boolean primary, boolean focused) {
        if (primary) {
            GradientDrawable g = LiveTheme.card(act, accent, LiveTheme.R_PILL);
            if (focused) g.setStroke(Math.max(1, Ui.dp(act, 2)), 0xFFFFFFFF);
            return g;
        }
        GradientDrawable g = LiveTheme.stroke(act, LiveTheme.ROW,
                LiveTheme.R_PILL, 1,
                LiveTheme.blend(LiveTheme.LINE, accent, 0.55f));
        if (focused) g.setStroke(Math.max(1, Ui.dp(act, 2)), accent);
        return g;
    }

    private static TextView text(Activity act, String s, float sp,
                                 int color, boolean bold) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static float fontScale(Activity act) {
        float s = Store.epgFontScale(act) / 100f;
        return Math.max(0.5f, Math.min(2f, s));
    }
}
