package com.ilatv.tv;

/**
 * 点播选集格子的集数标签（v109），纯计算、不依赖 Android，便于 JVM 单测。
 *
 * v108 及之前：手机版 EpAdapter 自己拼补零集数标签，量词用的是另一种叫法，
 * 而电视版、顶栏、网页端点播详情页一直都是「集」——同一个 App 里两种叫法。
 * v109：统一只用「集」。按总集数补零的规则原样保留
 * （1 集 → 第1集；23 集 → 第01集 … 第23集；100 集 → 第001集 … 第100集）。
 *
 * 收口到这一个纯函数后，以后要改标签文案只改这里，
 * 不会再出现「某一端漏改又冒出另一种叫法」。
 */
public final class EpLabel {

    private EpLabel() {}

    /**
     * @param position 集序号，从 0 开始
     * @param total    总集数（ episodes.length ）
     * @return 「第N集」，N 按总集数位数补零
     */
    public static String grid(int position, int total) {
        int t = Math.max(1, total);
        int digits = Integer.toString(t).length();
        String num = Integer.toString(Math.max(0, position) + 1);
        StringBuilder sb = new StringBuilder("第");
        for (int k = num.length(); k < digits; k++) sb.append('0');
        // 统一口径：集。历史版本的「话」不再使用。
        sb.append(num).append('集');
        return sb.toString();
    }
}
