package com.ilatv.tv;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

/**
 * 洛雪自定义音源宿主（v111）。
 *
 * <p>一个<b>不挂到界面上</b>的隐藏 WebView 承载第三方脚本：注入 lx-bridge.js 提供
 * globalThis.lx，脚本注册 request 处理器，宿主发 musicUrl 取链，结果回传给网页音乐面板。
 * 不新建 Activity → 不叠返回栈、不打断主页，也不碰点播 / 直播两套 Exo 内核。
 *
 * <p>隔离措施：禁导航 / 禁弹窗 / 禁文件与 content 访问 / 关 DOM storage /
 * <b>setBlockNetworkLoads(true)</b> 让 WebView 自己发不出任何请求，脚本的所有网络
 * 必须经 LxNative.fetch 走 Java（LxHttp 还会挡掉回环地址）。
 *
 * <p>一次只挂一个源；换源或删除后重建。取链 15 秒超时，脚本死循环不会拖住界面。
 */
public final class LxSourceHost {

    public interface Sink {
        void onInited(String id, String sourcesJson);
        void onFailed(String id, String message);
        void onResult(String reqId, String json);
    }

    private static final int TIMEOUT_MS = 15000;
    private static final String BASE = "https://lx.invalid/";

    private final Context ctx;
    private final Sink sink;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Set<String> awaiting = new HashSet<>();
    private final String bridgeJs;

    private WebView sandbox;
    private String loadedId = "";
    private boolean ready = false;
    private String sourcesJson = "{}";
    private String pendingReqId = null;
    private String pendingPayload = null;

    public LxSourceHost(Context c, Sink s) {
        ctx = c.getApplicationContext();
        sink = s;
        bridgeJs = readAsset("lx-bridge.js");
    }

    // ---------------------------------------------------------------- 对外

    /** 预热 / 切换音源；调用方不必关心线程。 */
    public void prepare(final String id) {
        ui.post(new Runnable() {
            @Override public void run() { doPrepare(id); }
        });
    }

    /** 取播放链接：{action:'musicUrl', source, info:{type, musicInfo}}。 */
    public void musicUrl(final String id, final String reqId, final String payloadJson) {
        ui.post(new Runnable() {
            @Override public void run() {
                if (ready && id.equals(loadedId)) {
                    dispatch(reqId, payloadJson);
                } else {
                    // 沙箱还没起来：先记下这次请求，inited 后自动补发，不丢点播动作
                    pendingReqId = reqId;
                    pendingPayload = payloadJson;
                    doPrepare(id);
                }
            }
        });
    }

    public String sourcesInfo() { return sourcesJson; }
    public boolean isReady() { return ready; }
    public String loadedId() { return loadedId; }

    public void destroy() {
        ui.post(new Runnable() {
            @Override public void run() { destroySandbox(); }
        });
    }

    // ---------------------------------------------------------------- 沙箱

    private void doPrepare(String id) {
        if (id == null || id.isEmpty()) { fail("", "音源 id 为空"); return; }
        if (ready && id.equals(loadedId)) {
            sink.onInited(id, sourcesJson);
            flushPending();
            return;
        }
        destroySandbox();
        loadedId = id;
        ready = false;
        sourcesJson = "{}";
        final String script = LxStore.script(ctx, id);
        if (script == null || script.isEmpty()) { fail(id, "音源不存在或已被删除"); return; }

        try {
            WebView w = new WebView(ctx);
            configure(w);
            w.addJavascriptInterface(new Native(), "LxNative");
            sandbox = w;
            LxMeta.Info info = LxMeta.parse(script);
            JSONObject meta = new JSONObject();
            meta.put("name", info.name).put("description", info.description)
                    .put("version", info.version).put("author", info.author)
                    .put("homepage", info.homepage);
            String metaJson = jsSafe(meta.toString());
            final String html = "<!doctype html><html><head><meta charset='utf-8'>"
                    + "<script>window.__LX_META__=" + metaJson + ";</script>"
                    + "<script>" + jsSafe(bridgeJs) + "</script>"
                    + "</head><body></body></html>";
            w.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return true;                       // 一律拦掉导航
                }
                @Override public void onPageFinished(WebView view, String url) {
                    // 用 evaluateJavascript 直接执行脚本正文，避免把第三方脚本
                    // 拼进 HTML 时的 </script> 转义问题
                    view.evaluateJavascript(script, new ValueCallback<String>() {
                        @Override public void onReceiveValue(String value) {
                            // 有些源在 setTimeout 里注册 handler，稍等一拍再判定就绪
                            ui.postDelayed(new Runnable() {
                                @Override public void run() {
                                    if (sandbox == null) return;
                                    ready = true;
                                    sink.onInited(loadedId, sourcesJson);
                                    flushPending();
                                }
                            }, 260);
                        }
                    });
                }
            });
            w.loadDataWithBaseURL(BASE, html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            destroySandbox();
            fail(id, "音源沙箱启动失败：" + e.getMessage());
        }
    }

    private void configure(WebView w) {
        w.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setDomStorageEnabled(false);
        s.setDatabaseEnabled(false);
        s.setGeolocationEnabled(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        // 关键：WebView 自身不发任何网络请求，第三方脚本只能走 LxNative.fetch
        s.setBlockNetworkLoads(true);
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String u, String m,
                                               android.webkit.JsResult r) {
                r.cancel(); return true;
            }
            @Override public boolean onJsConfirm(WebView v, String u, String m,
                                                 android.webkit.JsResult r) {
                r.cancel(); return true;
            }
            @Override public boolean onJsPrompt(WebView v, String u, String m, String d,
                                                android.webkit.JsPromptResult r) {
                r.cancel(); return true;
            }
        });
    }

    private void dispatch(final String reqId, final String payloadJson) {
        if (sandbox == null || !ready) {
            sink.onResult(reqId, "{\"ok\":false,\"error\":\"音源沙箱未就绪\"}");
            return;
        }
        synchronized (awaiting) { awaiting.add(reqId); }
        sandbox.evaluateJavascript(
                "window.__lxDispatch(" + JSONObject.quote(reqId) + ","
                        + JSONObject.quote(payloadJson) + ")", null);
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                boolean left;
                synchronized (awaiting) { left = awaiting.remove(reqId); }
                if (left) sink.onResult(reqId, "{\"ok\":false,\"error\":\"音源响应超时（15 秒）\"}");
            }
        }, TIMEOUT_MS);
    }

    private void flushPending() {
        if (pendingReqId == null || !ready) return;
        String id = pendingReqId, p = pendingPayload;
        pendingReqId = null;
        pendingPayload = null;
        dispatch(id, p);
    }

    private void deliverResult(String reqId, String json) {
        boolean left;
        synchronized (awaiting) { left = awaiting.remove(reqId); }
        // 超时已回收的请求不再重复回调
        if (left) sink.onResult(reqId, json);
    }

    private void fail(String id, String msg) {
        ready = false;
        pendingReqId = null;
        pendingPayload = null;
        sink.onFailed(id, msg);
    }

    private void destroySandbox() {
        if (sandbox != null) {
            try { sandbox.stopLoading(); } catch (Exception ignored) {}
            try { sandbox.destroy(); } catch (Exception ignored) {}
        }
        sandbox = null;
        ready = false;
        loadedId = "";
        sourcesJson = "{}";
        synchronized (awaiting) { awaiting.clear(); }
    }

    // ---------------------------------------------------------------- JS 接口

    private final class Native {
        @JavascriptInterface
        public void onInited(final String json) {
            ui.post(new Runnable() {
                @Override public void run() { sourcesJson = json == null ? "{}" : json; }
            });
        }

        @JavascriptInterface
        public void onResult(final String reqId, final String json) {
            ui.post(new Runnable() {
                @Override public void run() { deliverResult(reqId, json); }
            });
        }

        /** 脚本发起 HTTP：后台线程代发，结果回到沙箱的 __lxHttp。 */
        @JavascriptInterface
        public void fetch(final String url, final String optionsJson, final String cbId) {
            new Thread(new Runnable() {
                @Override public void run() {
                    String method = "GET", headers = "{}", body = "";
                    try {
                        JSONObject o = new JSONObject(optionsJson == null ? "{}" : optionsJson);
                        method = o.optString("method", "GET");
                        Object h = o.opt("headers");
                        if (h instanceof JSONObject) headers = h.toString();
                        body = o.optString("body", "");
                    } catch (Exception ignored) {}
                    final JSONObject r = LxHttp.request(url, method, headers, body);
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (sandbox == null) return;
                            sandbox.evaluateJavascript(
                                    "window.__lxHttp(" + JSONObject.quote(cbId) + ","
                                            + JSONObject.quote(r.toString()) + ")", null);
                        }
                    });
                }
            }, "lx-fetch").start();
        }

        /** 同步摘要：md5 / sha1 / sha256，返回 {ok,hex,b64} 的 JSON 字符串。 */
        @JavascriptInterface
        public String crypto(String algo, String dataB64) {
            return LxHttp.crypto(algo, dataB64);
        }

        @JavascriptInterface
        public void onLog(String json) {
            // 第三方源的 updateAlert 只记不用：不弹窗、不写配置、不触发界面
        }
    }

    // ---------------------------------------------------------------- 工具

    /** 内联进 <script> 前转义 </script，防止第三方元数据提前闭合脚本块。 */
    private static String jsSafe(String s) {
        return s == null ? "" : s.replace("</", "<\\/");
    }

    private String readAsset(String name) {
        InputStream is = null;
        try {
            is = ctx.getAssets().open(name);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        } finally {
            if (is != null) try { is.close(); } catch (Exception ignored) {}
        }
    }
}
