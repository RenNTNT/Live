package com.ilatv.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * 「直播订阅」管理对话框（v98）：直播播放页功能菜单使用，全屏选台页已移除。
 *
 * 以前播放页的「订阅管理」会先启动全屏选台页再在它上面弹框，于是背景里
 * 多出一整屏分组/频道列表，还会把正在播放的直播页压到后台。
 * 现在直接在播放页弹这个对话框：直播继续播，背后不再出现整屏列表。
 *
 * v97：容器换成 LiveMenuSkin（LiveTheme 卡片），与直播功能菜单 / 选台抽屉 /
 * 节目表弹窗同一套视觉；条目点击、长按删除、启停、输入框逻辑一行未动。
 *
 * onChanged：订阅增删改后回调（选台页重载列表 / 播放页重新拉频道）。
 * tracker：播放页需要把每个弹出的对话框登记给选台抽屉，模态期间把
 *          方向键/确定键交还系统，否则遥控器没法操作列表和输入框。
 */
public final class LiveSubsDialog {

    public interface Tracker {
        void track(AlertDialog d);
    }

    private LiveSubsDialog() {}

    public static void show(final Activity act, final Runnable onChanged,
                            final Tracker tracker) {
        final List<Model.LiveSub> subs = Store.liveSubs(act);
        LinearLayout box = Ui.column(act);
        box.setPadding(0, Ui.dp(act, 2), 0, 0);
        box.addView(LiveMenuSkin.tip(act,
                "点击条目编辑 / 启停，长按删除；停用的订阅不再拉取。\n"
                        + "M3U 与 TXT 按内容自动识别：TXT 支持 #genre# 分组、名称,地址、多线路，GBK 自动识别。"));

        List<String> rows = new ArrayList<>();
        for (Model.LiveSub s : subs) {
            rows.add(s.name + (s.enabled ? "" : "  [已停用]") + "\n" + s.url);
        }
        if (rows.isEmpty()) rows.add("还没有订阅。下方填一份公开 M3U 或 TXT 地址即可。");

        ListView lv = new ListView(act);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<String>(
                act, android.R.layout.simple_list_item_1, rows) {
            @Override
            public View getView(int position, View cv, ViewGroup parent) {
                View v = super.getView(position, cv, parent);
                TextView t = v.findViewById(android.R.id.text1);
                if (t != null) {
                    t.setTextColor(position < subs.size() && !subs.get(position).enabled
                            ? LiveTheme.SUB : LiveTheme.TEXT);
                    t.setTextSize(12);
                }
                v.setBackground(LiveMenuSkin.rowBg(act));
                return v;
            }
        };
        lv.setAdapter(adapter);
        lv.setSelector(new ColorDrawable(
                LiveTheme.blend(LiveTheme.CARD, LiveTheme.accent(act), 0.25f)));

        final AlertDialog[] holder = new AlertDialog[1];
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= subs.size()) return;
                if (holder[0] != null) holder[0].dismiss();
                edit(act, pos, onChanged, tracker);
            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> p, View v, final int pos, long id) {
                if (pos >= subs.size()) return true;
                final AlertDialog[] cref = new AlertDialog[1];
                View msg = LiveMenuSkin.tip(act,
                        subs.get(pos).name + "\n" + subs.get(pos).url);
                View btns = LiveMenuSkin.actions(act, cref,
                        new String[]{ "删除", "取消" },
                        new boolean[]{ true, false },
                        new Runnable[]{
                                () -> {
                                    Store.removeLiveSub(act, pos);
                                    if (holder[0] != null) holder[0].dismiss();
                                    changed(act, onChanged);
                                }, null });
                AlertDialog confirm = LiveMenuSkin.show(act, "删除订阅",
                        "删除后该订阅不再拉取，频道缓存会重建", msg, btns);
                cref[0] = confirm;
                track(tracker, confirm);
                return true;
            }
        });
        box.addView(lv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 200)));

        final EditText name = LiveMenuSkin.input(act, "订阅名称（可留空）");
        final EditText url = LiveMenuSkin.input(act, "https://域名/list.m3u / .m3u8 / .txt");
        box.addView(name);
        box.addView(gap(act, 8));
        box.addView(url);

        View footer = LiveMenuSkin.actions(act, holder,
                new String[]{ "添加订阅", "关闭" },
                new boolean[]{ true, false },
                new Runnable[]{
                        () -> {
                            String u = url.getText().toString().trim();
                            if (!u.startsWith("http://") && !u.startsWith("https://")) {
                                Toast.makeText(act, "请填完整 http(s) 地址",
                                        Toast.LENGTH_SHORT).show();
                                return;
                            }
                            String n = name.getText().toString().trim();
                            Store.addLiveSub(act, new Model.LiveSub(
                                    n.isEmpty() ? "订阅" + (subs.size() + 1) : n, u, true));
                            changed(act, onChanged);
                            Toast.makeText(act, "已添加订阅", Toast.LENGTH_SHORT).show();
                        }, null });
        AlertDialog d = LiveMenuSkin.show(act, "直播订阅",
                "共 " + subs.size() + " 份订阅 · 当前主题：" + LiveMenuSkin.themeLabel(act),
                box, footer);
        holder[0] = d;
        track(tracker, d);
    }

    private static void edit(final Activity act, final int pos,
                             final Runnable onChanged, final Tracker tracker) {
        final List<Model.LiveSub> subs = Store.liveSubs(act);
        if (pos < 0 || pos >= subs.size()) return;
        final Model.LiveSub old = subs.get(pos);

        LinearLayout form = Ui.column(act);
        form.setPadding(0, Ui.dp(act, 2), 0, 0);
        final EditText name = LiveMenuSkin.input(act, "订阅名称");
        final EditText url = LiveMenuSkin.input(act, "https://域名/list.m3u / .m3u8 / .txt");
        name.setText(old.name);
        url.setText(old.url);
        name.setSelection(name.getText().length());
        url.setSelection(url.getText().length());
        form.addView(name);
        form.addView(gap(act, 10));
        form.addView(url);

        final CheckBox enabled = new CheckBox(act);
        enabled.setText("启用此订阅（停用后不再拉取）");
        enabled.setTextColor(LiveTheme.TEXT);
        enabled.setTextSize(13);
        enabled.setChecked(old.enabled);
        enabled.setPadding(Ui.dp(act, 4), Ui.dp(act, 10), 0, 0);
        form.addView(enabled);

        final AlertDialog[] eref = new AlertDialog[1];
        View footer = LiveMenuSkin.actions(act, eref,
                new String[]{ "保存", "删除", "取消" },
                new boolean[]{ true, false, false },
                new Runnable[]{
                        () -> {
                            String n = name.getText().toString().trim();
                            String u = url.getText().toString().trim();
                            if (!u.startsWith("http://") && !u.startsWith("https://")) {
                                Toast.makeText(act, "请填完整 http(s) 地址",
                                        Toast.LENGTH_SHORT).show();
                                return;
                            }
                            for (int i = 0; i < subs.size(); i++) {
                                if (i != pos && subs.get(i).url.equals(u)) {
                                    Toast.makeText(act, "这个地址已经在列表里了",
                                            Toast.LENGTH_SHORT).show();
                                    return;
                                }
                            }
                            Store.updateLiveSub(act, pos,
                                    new Model.LiveSub(n.isEmpty() ? "未命名订阅" : n, u,
                                            enabled.isChecked()));
                            changed(act, onChanged);
                            Toast.makeText(act, "已保存", Toast.LENGTH_SHORT).show();
                        },
                        () -> {
                            Store.removeLiveSub(act, pos);
                            changed(act, onChanged);
                        }, null });
        AlertDialog d = LiveMenuSkin.show(act, "编辑订阅",
                "修改名称 / 地址或停用该订阅", form, footer);
        eref[0] = d;
        track(tracker, d);
        name.requestFocus();
    }

    /** 订阅变了就丢弃旧频道缓存，与网页后台保存订阅后的处理保持一致 */
    private static void changed(Activity act, Runnable onChanged) {
        Store.clearLiveCache(act);
        if (onChanged != null) onChanged.run();
    }

    private static void track(Tracker tracker, AlertDialog d) {
        if (tracker != null) tracker.track(d);
    }

    private static View gap(Activity act, int dp) {
        View v = new View(act);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, Ui.dp(act, dp)));
        return v;
    }
}
