package com.ilatv.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * 直播台标库（v78）。
 *
 * 台标库地址完全由用户在设置页填写，工程里不再内置任何默认链接。
 * 未设置地址时：不联网、不预拉取；是否显示台标由设置页总开关统一控制。
 * 数据格式是一份「频道别名 → 台标」映射：
 *   {"epgs":[{"epgid":"CCTV1","logo":"https://.../CCTV1.png","name":"CCTV-1 综合,CCTV1,..."}, ...]}
 * 源里有少数不规范写法（裸 key、字段名 epg），解析时统一容错。
 *
 * 只做「补全」：订阅里已带 tvg-logo 的频道保留原值，只有缺台标的频道按名字匹配补上。
 * 结果按频道名缓存，缓存文件 7 天有效；设置地址后启动会后台静默刷新，设置页可手动「重新读取」。
 */
public final class LogoStore {

    private static final String PREF = "ilatv_logo";
    private static final String CACHE_FILE = "logo_epg_cache.json";
    private static final long TTL = 7L * 24 * 60 * 60 * 1000;
    private static final int MAX_BYTES = 4 * 1024 * 1024;   // 防御异常大文件

    private static final Object LOCK = new Object();
    private static final Map<String, String> EXACT = new HashMap<>();      // 归一别名 → logo
    private static final Map<String, String> RAW = new HashMap<>();        // 原始别名 → logo
    private static final Map<String, String> LOOKUP = new HashMap<>();     // 频道名 → 结果（含空结果）
    private static final List<String> FUZZY = new ArrayList<>();           // 按长度降序的归一别名
    private static final Set<String> PLAIN = new HashSet<>();              // 别名本身不含画质词的归一 key
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ilatv-logo");
        t.setDaemon(true);
        return t;
    });

    private static volatile boolean loaded = false;
    private static volatile boolean loading = false;
    private static volatile boolean enabled = false;   // 默认关闭
    private static volatile String source = "";   // 工程不再内置台标地址
    private static volatile int entryCount = 0;
    private static volatile long updatedAt = 0;
    private static volatile String lastError = "";
    private static volatile boolean prefetchDone = false;

    private LogoStore() {}

    // ------------------------------------------------------------------ 配置

    private static SharedPreferences pref(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** 由 TvServer 在读取 config.json 后调用；config.json 是持久真源，这里只是运行时镜像。 */
    public static void configure(Context c, boolean on, String url) {
        enabled = on;
        source = (url == null) ? "" : url.trim();
        pref(c).edit().putBoolean("enabled", on).putString("source", source).apply();
    }

    public static boolean isEnabled() { return enabled; }
    public static String source(Context c) {
        String s = source;
        if (s == null || s.isEmpty()) s = pref(c).getString("source", "");
        return s;
    }

    /** 启动时调用一次：读本地缓存 + 过期则后台刷新。不阻塞界面。 */
    public static void initAndPrefetch(Context c) {
        if (prefetchDone) return;
        prefetchDone = true;
        Context app = c.getApplicationContext();
        SharedPreferences p = pref(app);
        enabled = p.getBoolean("enabled", false);
        String s = p.getString("source", "");
        if (s == null) s = "";
        source = s;
        ensureLoaded(app);
        if (enabled && !source.isEmpty() && (updatedAt <= 0 || System.currentTimeMillis() - updatedAt > TTL)) {
            refresh(app, false, null);
        }
    }

    public static JSONObject status(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("ok", true);
            o.put("enabled", enabled);
            o.put("source", source(c));
            o.put("builtIn", false);   // 已无内置地址
            o.put("count", entryCount);
            o.put("aliases", EXACT.size());
            o.put("loaded", loaded);
            o.put("loading", loading);
            o.put("updatedAt", updatedAt);
            o.put("error", lastError);
        } catch (Exception ignored) {}
        return o;
    }

    // ------------------------------------------------------------------ 拉取 / 缓存

    private static File cacheFile(Context c) {
        return new File(c.getFilesDir(), CACHE_FILE);
    }

    /** 同步载入磁盘缓存（毫秒级，只在进程首次调用时真正解析）。 */
    public static void ensureLoaded(Context c) {
        synchronized (LOCK) {
            if (loaded) return;
            File f = cacheFile(c.getApplicationContext());
            if (!f.isFile()) return;
            try {
                String text = readFile(f);
                if (!text.isEmpty()) {
                    JSONObject wrap = new JSONObject(text);
                    updatedAt = wrap.optLong("ts", 0);
                    buildIndex(wrap.optString("body", ""));
                    loaded = !EXACT.isEmpty();
                }
            } catch (Exception e) {
                lastError = "本地缓存读取失败";
            }
        }
    }

    /** force=true 忽略 7 天有效期强制重拉；cb 在拉取结束后（主线程外）回调。 */
    public static void refresh(final Context c, final boolean force, final Runnable cb) {
        if (source(c).isEmpty()) { lastError = "未设置台标库地址"; if (cb != null) cb.run(); return; }
        if (loading) { if (cb != null) cb.run(); return; }
        loading = true;
        lastError = "";
        final Context app = c.getApplicationContext();
        final String url = source(app);
        POOL.execute(() -> {
            try {
                String body = fetch(url);
                buildIndex(body);
                JSONObject wrap = new JSONObject();
                wrap.put("ts", System.currentTimeMillis());
                wrap.put("body", body);
                writeFile(cacheFile(app), wrap.toString());
                updatedAt = System.currentTimeMillis();
                loaded = true;
            } catch (Exception e) {
                lastError = shortErr(e);
            } finally {
                loading = false;
                if (cb != null) try { cb.run(); } catch (Exception ignored) {}
            }
        });
    }

    private static String fetch(String url) throws Exception {
        if (!url.startsWith("http://") && !url.startsWith("https://"))
            throw new IllegalArgumentException("台标源地址必须以 http(s):// 开头");
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 iLaTV/2.0");
        conn.setRequestProperty("Accept", "application/json,*/*");
        try {
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new java.io.IOException("HTTP " + code);
            java.io.InputStream in = conn.getInputStream();
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BYTES) throw new java.io.IOException("台标文件过大");
                bos.write(buf, 0, n);
            }
            in.close();
            String s = new String(bos.toByteArray(), Charset.forName("UTF-8"));
            if (s.startsWith("\uFEFF")) s = s.substring(1);
            return s;
        } finally {
            conn.disconnect();
        }
    }

    private static String shortErr(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isEmpty()) m = e.getClass().getSimpleName();
        return m.length() > 90 ? m.substring(0, 90) : m;
    }

    private static String readFile(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } finally { in.close(); }
    }

    private static void writeFile(File f, String s) throws Exception {
        FileOutputStream out = new FileOutputStream(f);
        try { out.write(s.getBytes(Charset.forName("UTF-8"))); } finally { out.close(); }
    }

    // ------------------------------------------------------------------ 解析 / 索引

    /**
     * 源 JSON 并非严格合法：存在裸 key（logo: 而非 "logo":）、个别条目字段名是 epg。
     * 先做最小修补再交给 org.json，比自己拆字符串稳。
     */
    private static String sanitize(String raw) {
        if (raw == null) return "";
        String s = raw;
        // 给行首没加引号的 key 补引号（只补 epgid / epg / logo / name 四个已知字段）
        s = Pattern.compile("(?m)^(\\s*)(epgid|epg|logo|name)(\\s*:)")
                .matcher(s).replaceAll("$1\"$2\"$3");
        // 去掉对象/数组结尾的尾逗号
        s = s.replaceAll(",\\s*}", "}").replaceAll(",\\s*]", "]");
        // 去 // 行注释
        s = Pattern.compile("(?m)^\\s*//.*$").matcher(s).replaceAll("");
        return s;
    }

    private static synchronized void buildIndex(String raw) throws Exception {
        String s = sanitize(raw);
        if (!s.trim().startsWith("{")) throw new IllegalArgumentException("不是有效的台标 JSON");
        JSONObject root = new JSONObject(s);
        JSONArray arr = root.optJSONArray("epgs");
        if (arr == null) throw new IllegalArgumentException("缺少 epgs 数组");

        Map<String, String> exact = new HashMap<>();
        Map<String, String> rawMap = new HashMap<>();
        Set<String> fuzzy = new LinkedHashSet<>();
        Set<String> plain = new HashSet<>();
        int entries = 0;
        // 两遍：先收录 name 里的频道别名。库里同一台有多条（普通 / 4K / HD），
        // epgid 往往是重复的「湖南卫视」，若先按 epgid 建索引会把 4K 台标当成主台标。
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String logo = o.optString("logo", "").trim();
            if (logo.isEmpty()) continue;
            String names = o.optString("name", "");
            entries++;
            for (String a : names.split("[,，;；]")) addAlias(exact, rawMap, fuzzy, plain, a, logo);
        }
        // 第二遍：epgid 只作兜底，绝不覆盖 name 已定下的台标
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String logo = o.optString("logo", "").trim();
            if (logo.isEmpty()) continue;
            String epgid = o.optString("epgid", o.optString("epg", "")).trim();
            if (epgid.isEmpty()) continue;
            if (!rawMap.containsKey(epgid)) rawMap.put(epgid, logo);
            String k = norm(epgid);
            if (k.length() < 2) continue;
            if (!exact.containsKey(k)) exact.put(k, logo);
            fuzzy.add(k);
        }
        if (entries == 0) throw new IllegalArgumentException("台标列表为空");

        List<String> sorted = new ArrayList<>(fuzzy);
        Collections.sort(sorted, (a, b) -> b.length() - a.length());  // 长别名优先

        EXACT.clear(); RAW.clear(); LOOKUP.clear(); FUZZY.clear(); PLAIN.clear();
        EXACT.putAll(exact); RAW.putAll(rawMap); FUZZY.addAll(sorted); PLAIN.addAll(plain);
        entryCount = entries;
    }

    private static void addAlias(Map<String, String> exact, Map<String, String> rawMap,
                                 Set<String> fuzzy, Set<String> plain, String alias, String logo) {
        String a = alias == null ? "" : alias.trim();
        if (a.isEmpty()) return;
        boolean isPlain = !hasQualityWord(a);
        if (!rawMap.containsKey(a)) rawMap.put(a, logo);
        String k = norm(a);
        if (k.length() < 2) return;
        // 同名频道在库里有多条（4K / HD / 普通），优先用「别名本身不带画质词」那条台标
        if (!exact.containsKey(k) || (isPlain && !plain.contains(k))) {
            exact.put(k, logo);
            if (isPlain) plain.add(k);
        }
        fuzzy.add(k);
    }

    private static boolean hasQualityWord(String s) {
        String v = s.toLowerCase(Locale.ROOT);
        String[] w = {"4k", "8k", "hd", "sd", "hdr", "高清", "超清", "标清", "超高清",
                "25p", "50p", "60p", "1080p", "720p", "uhd", "fhd"};
        for (String x : w) if (v.contains(x)) return true;
        return false;
    }

    /** 频道名归一：全角转半角、小写、去括号修饰/空白/连字符、去画质尾缀。 */
    static String norm(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0xFF01 && c <= 0xFF5E) c = (char) (c - 0xFEE0);
            if (c == 0x3000) c = ' ';
            sb.append(c);
        }
        String v = sb.toString().toLowerCase(Locale.ROOT);
        v = v.replaceAll("[\\[【(（].*?[\\]】)）]", "");   // [超清HDR]、(HD) 之类
        v = v.replaceAll("[\\s\\-_·•.、/\\\\]+", "");
        // 尾缀循环剥离：湖南卫视[超清HDR]HD → 湖南卫视；CCTV1综合高清 → CCTV1综合
        String[] tails = {"超高清", "超清", "高清", "标清", "频道", "hd", "sd", "4k", "8k",
                "25p", "50p", "60p", "hdr", "1080p", "720p", "测试", "轮播"};
        boolean again = true;
        int guard = 0;
        while (again && guard++ < 6) {
            again = false;
            for (String t : tails) {
                if (v.length() > t.length() && v.endsWith(t)) {
                    v = v.substring(0, v.length() - t.length());
                    again = true;
                    break;
                }
            }
        }
        return v;
    }

    // ------------------------------------------------------------------ 查询 / 补全

    /** 按频道名找台标；找不到返回 ""。结果带缓存，避免列表滚动时反复扫描。 */
    public static String lookup(String channelName) {
        if (!enabled || channelName == null || channelName.trim().isEmpty()) return "";
        String name = channelName.trim();
        synchronized (LOCK) {
            if (LOOKUP.containsKey(name)) return LOOKUP.get(name);
        }
        // 先查归一精确（纯名优先级已由 buildIndex 定好），RAW 只补大小写/符号差异
        String k = norm(name);
        String hit = EXACT.get(k);
        if (hit == null) hit = RAW.get(name);
        // 再剥一层画质词后精确匹配（如「CCTV5 体育高清」→「CCTV5体育」）
        if (hit == null && !k.isEmpty()) hit = EXACT.get(stripTail(k));
        // 最后兜底：频道名里含某个较长别名（「XX卫视·超清频道」这类变体）。
        // 只做单向包含且要求别名至少占频道名一半，避免「不存在频道XYZ」被短别名误命中。
        if (hit == null && k.length() >= 3) {
            for (String alias : FUZZY) {
                if (alias.length() < 3) break;              // FUZZY 按长度降序
                if (alias.length() > k.length()) continue;
                if (alias.length() * 2 < k.length()) continue;
                if (k.contains(alias)) { hit = EXACT.get(alias); break; }
            }
        }
        String result = hit == null ? "" : hit;
        synchronized (LOCK) {
            if (LOOKUP.size() > 4000) LOOKUP.clear();
            LOOKUP.put(name, result);
        }
        return result;
    }

    private static String stripTail(String k) {
        String[] tails = {"高清", "超清", "标清", "hd", "sd", "4k", "8k", "频道", "台"};
        for (String t : tails) if (k.length() > t.length() && k.endsWith(t))
            return k.substring(0, k.length() - t.length());
        return k;
    }

    /** 补全网页直播页 /api/iptv 返回的频道 JSON（只补缺台标的）。 */
    public static void fill(JSONObject ch) {
        if (ch == null || !enabled) return;
        String cur = ch.optString("logo", "");
        if (!cur.isEmpty()) return;
        String logo = lookup(ch.optString("name", ""));
        if (!logo.isEmpty()) try { ch.put("logo", logo); } catch (Exception ignored) {}
    }

    /** 补全原生选台页 / 抽屉的频道模型（只补缺台标的）。 */
    public static void fill(Model.Channel ch) {
        if (ch == null || !enabled) return;
        if (ch.logo != null && !ch.logo.isEmpty()) return;
        String logo = lookup(ch.name);
        if (!logo.isEmpty()) ch.logo = logo;
    }

    /** 开关切换时清掉查询结果缓存，避免关闭后仍用旧值。 */
    public static void onSettingChanged() {
        synchronized (LOCK) { LOOKUP.clear(); }
    }

    // 桌面单测入口（不依赖 Android）
    public static int testBuild(String raw) throws Exception {
        buildIndex(raw);
        return entryCount;
    }
    public static String testLookup(String name) { return lookup(name); }
    public static String testNorm(String s) { return norm(s); }
}
