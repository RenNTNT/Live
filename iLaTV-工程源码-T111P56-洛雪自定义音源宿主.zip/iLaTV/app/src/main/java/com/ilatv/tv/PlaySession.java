package com.ilatv.tv;

import android.app.Activity;

import java.lang.ref.WeakReference;

/**
 * 播放栈统一（v107）。
 *
 * 症状：手机先推直播、再推点播，遥控器返回要退两次 —— 先回到之前那个直播，
 * 再回主页。根因是两类推送各起各的 Activity：
 *   LivePlayerActivity 用 NEW_TASK|SINGLE_TOP，PlayerActivity 用 NEW_TASK|CLEAR_TOP。
 * CLEAR_TOP 只清「同类」实例，跨类型完全无效，于是栈变成
 *   MainActivity → LivePlayerActivity → PlayerActivity。
 *
 * 这里维护「当前播放页」的进程内弱引用，每次起播前先收掉**不同类型**的旧播放页；
 * 同类型不收，交给 SINGLE_TOP / onNewIntent 复用（直播推送换台必须保留）。
 * 这样任何推送组合下栈里永远只有一层播放页，返回一次就到主页。
 */
public final class PlaySession {

    private PlaySession() {}

    private static volatile WeakReference<Activity> current;

    /** 播放页 onCreate 末尾注册 */
    public static void attach(Activity a) {
        if (a != null) current = new WeakReference<>(a);
    }

    /** 播放页 onDestroy 注销；只清自己，避免把新起的播放页误清 */
    public static void detach(Activity a) {
        WeakReference<Activity> r = current;
        if (r != null && r.get() == a) current = null;
    }

    /**
     * 起播前调用：若当前在播的页与即将起的页不是同一类，先 finish 它。
     * 必须从任意线程安全调用：finish 统一 post 到主线程。
     */
    public static void finishOthers(Class<?> next) {
        final Activity a = current == null ? null : current.get();
        if (a == null || next == null) return;
        if (!shouldFinish(a.getClass().getName(), next.getName(), a.isFinishing())) return;
        a.runOnUiThread(new Runnable() {
            @Override public void run() {
                try { if (!a.isFinishing()) a.finish(); } catch (Exception ignored) {}
            }
        });
    }

    /** 纯决策，便于 JVM 单测：不同类型才收，已在 finishing 的不重复收 */
    public static boolean shouldFinish(String curCls, String nextCls, boolean finishing) {
        if (curCls == null || nextCls == null || finishing) return false;
        return !curCls.equals(nextCls);
    }

    /** 当前播放页类名（诊断用），无则空串 */
    public static String currentName() {
        Activity a = current == null ? null : current.get();
        return a == null ? "" : a.getClass().getSimpleName();
    }
}
