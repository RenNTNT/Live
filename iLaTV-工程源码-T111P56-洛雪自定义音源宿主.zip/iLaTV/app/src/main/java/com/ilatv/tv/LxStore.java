package com.ilatv.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 洛雪自定义音源的本地列表（v111）。
 *
 * <p>刻意用<b>独立的 SharedPreferences</b>（ilatv_lx），不写进 config.json：
 * ① 音源脚本是第三方不可信文本，不和主配置混在一起，T107 那套配置自愈不用为它改口径；
 * ② 同步到电视时不会把几百 KB 脚本塞进 config；③ 坏了直接清空这份 pref，App 其余功能不受影响。
 *
 * <p>手机端 / 电视端是不同 applicationId、各自独立的 pref，和工程既有行为一致。
 */
public final class LxStore {

    private LxStore() {}

    private static final String PREF = "ilatv_lx";
    private static final String KEY = "sources";

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static JSONArray array(Context c) {
        String s = sp(c).getString(KEY, "[]");
        try {
            JSONArray a = new JSONArray(s);
            return a;
        } catch (Exception e) {
            return new JSONArray();   // 坏数据不当配置崩溃，直接当空列表
        }
    }

    private static void save(Context c, JSONArray a) {
        sp(c).edit().putString(KEY, a.toString()).apply();
    }

    /**
     * 导入一份脚本。同名同版本视为重复（不覆盖、不报错，返回 duplicate=true）。
     * 超过 8 个源时拒绝新增，提示先删一个。
     */
    public static JSONObject add(Context c, String script) {
        String reason = LxMeta.rejectReason(script);
        if (reason != null) throw new IllegalArgumentException(reason);
        LxMeta.Info info = LxMeta.parse(script);
        String id = LxMeta.id(info.name, info.version);
        JSONArray a = array(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id", ""))) {
                JSONObject dup = new JSONObject();
                try {
                    dup.put("ok", true).put("duplicate", true)
                            .put("id", id).put("name", info.name).put("version", info.version)
                            .put("count", a.length());
                } catch (Exception ignored) {}
                return dup;
            }
        }
        if (a.length() >= LxMeta.MAX_SOURCES)
            throw new IllegalArgumentException("最多保留 " + LxMeta.MAX_SOURCES + " 个音源，请先删除一个");
        JSONObject o = new JSONObject();
        try {
            o.put("id", id)
                    .put("name", info.name)
                    .put("version", info.version)
                    .put("desc", info.description)
                    .put("author", info.author)
                    .put("homepage", info.homepage)
                    .put("enabled", true)
                    .put("added", System.currentTimeMillis())
                    .put("script", script);
        } catch (Exception e) {
            throw new IllegalArgumentException("音源写入失败：" + e.getMessage());
        }
        a.put(o);
        save(c, a);
        JSONObject res = new JSONObject();
        try {
            res.put("ok", true).put("duplicate", false)
                    .put("id", id).put("name", info.name).put("version", info.version)
                    .put("count", a.length());
        } catch (Exception ignored) {}
        return res;
    }

    /** 从订阅地址导入：拉脚本正文走 Api.get（自带 gzip / 编码智能解码），再交给 add()。 */
    public static JSONObject addFromUrl(Context c, String url) throws Exception {
        String text = Api.get(url);
        if (text == null || text.trim().isEmpty())
            throw new IllegalArgumentException("音源地址返回空内容");
        return add(c, text);
    }

    public static String script(Context c, String id) {
        JSONArray a = array(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id", "")))
                return o.optString("script", "");
        }
        return null;
    }

    /** 第一个启用的源；没有则回落第一个（列表里全是禁用也算空）。 */
    public static JSONObject active(Context c) {
        JSONArray a = array(c);
        JSONObject fallback = null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (o.optBoolean("enabled", true)) return o;
            if (fallback == null) fallback = o;
        }
        return fallback;
    }

    public static boolean remove(Context c, String id) {
        JSONArray a = array(c);
        JSONArray out = new JSONArray();
        boolean hit = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (id.equals(o.optString("id", ""))) { hit = true; continue; }
            out.put(o);
        }
        if (hit) save(c, out);
        return hit;
    }

    public static int count(Context c) { return array(c).length(); }

    /** 给网页音乐面板的列表：<b>不带脚本正文</b>，避免大字符串塞进 JS。 */
    public static String listJson(Context c) {
        JSONArray a = array(c);
        JSONArray out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            JSONObject x = new JSONObject();
            try {
                x.put("id", o.optString("id", ""))
                        .put("name", o.optString("name", ""))
                        .put("version", o.optString("version", ""))
                        .put("desc", o.optString("desc", ""))
                        .put("enabled", o.optBoolean("enabled", true));
            } catch (Exception ignored) {}
            out.put(x);
        }
        JSONObject r = new JSONObject();
        try { r.put("ok", true).put("sources", out).put("count", out.length()); }
        catch (Exception ignored) {}
        return r.toString();
    }
}
