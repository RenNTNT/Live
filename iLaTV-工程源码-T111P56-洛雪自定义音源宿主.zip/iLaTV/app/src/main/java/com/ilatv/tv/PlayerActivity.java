package com.ilatv.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.view.SurfaceView;
import android.widget.TextView;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.video.VideoSize;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * 内置 ExoPlayer 全屏播放器（3.1.0）。
 *
 * 由 WebView 通过 exo.play(json) 调起，播放地址统一走本机 TvServer 的 /hls 代理
 * （防盗链 + Range 转发已在服务端处理）。播放器自带选集、跳过片头片尾、
 * 自动下一集、遥控器方向键操作，退出时把集数/进度回传给 MainActivity。
 *
 * 只使用 exoplayer-core + exoplayer-hls 两个纯 Java 模块，无 native 库、无
 * AndroidX UI 依赖，兼容 Android 5.0 (API 21)。
 */
public class PlayerActivity extends Activity implements Player.Listener {

    private static final int CTL_HIDE_DELAY = 3500;
    private static final long SEEK_STEP_MS = 15000;
    /** 手机端点播触控 OSD 的倍速档位（仅手机 flavor 且非直播时启用） */
    private static final float[] PHONE_SPEEDS = {0.75f, 1f, 1.25f, 1.5f, 2f, 3f};

    private ExoPlayer player;
    /** v110：IJK 解码内核（反射桥接）；未安装运行库时自动回落系统解码 */
    private IjkKernel ijk;
    private boolean ijkActive = false;
    private SurfaceView surface;
    private FrameLayout root;
    private TextView tvTitle, tvTime, tvHint, tvLoading;
    private LinearLayout ctlBar, topBar;
    private ProgressBar progress;
    private FrameLayout epOverlay;
    private GridView epGrid;
    private EpAdapter epAdapter;
    /** 手机端选集抽屉：右侧面板与它的宽度，用于打开时的滑入动画 */
    private LinearLayout phoneDrawer;
    private int phoneDrawerWidth;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            handler.postDelayed(this, 500);
        }
    };
    private final Runnable hideCtl = new Runnable() {
        @Override
        public void run() {
            // 手机端选集抽屉开着时顺延，避免挑集数挑到一半控制栏自己消失
            if (phoneOsd && episodesVisible()) {
                handler.postDelayed(this, 1000);
                return;
            }
            setCtlVisible(false);
        }
    };
    private final Runnable hideHint = new Runnable() {
        @Override
        public void run() {
            tvHint.setVisibility(View.GONE);
        }
    };

    private String[] episodes = new String[0];
    /** 原生直达的点播推送带来的观看记录：退出时由本页自己落盘，不回传网页 */
    private String nativeRec;
    private int currentIndex;
    private String title = "";
    private String sourceName = "";
    private int skipIntro, skipOutro;
    private int port = TvServer.PORT;
    private long pendingSeekMs;
    private boolean introDone;
    private boolean outroDone;
    private boolean liveMode;   // IPTV 直播：强制 HLS 引擎，不显示选集/跳过片段/续播
    private boolean errorOccurred;
    private boolean resultSent;
    /** 播放引擎档位：auto / exo / sysdec / ijk（IJK 为独立 FFmpeg 软解内核） */
    private String decodeMode = "auto";
    /** 系统解码：是否已用「解码器回退」策略重建过播放器（只重试一次，避免死循环） */
    private boolean decoderRetryDone = false;
    /** 模态对话框计数：菜单 / 解码方式期间把按键交还系统，否则遥控器选不了条目 */
    private int modalDialogs = 0;
    /** 已应用到播放器的点播解码档位 / 画面比例，用于检测手机后台的改动 */
    private String appliedVodDecodeMode = "auto";
    private String appliedVodAspect = Store.DEFAULT_ASPECT;
    /** 当前画面比例档位：auto / origin（原始比例，默认） / full */
    private String aspectMode = Store.DEFAULT_ASPECT;
    private String coverUrl = "";
    /** 当前片源标识；切源时同步更新，供 chip 选中态与观看记录识别 */
    private String sourceKey = "", vodId = "";
    /** 起播时定格的「最多 3 个延时最低源」，来自网页竞速 / 推送直达 */
    private SrcOpt[] srcTop = new SrcOpt[0];
    private LinearLayout srcChipRow;
    private TextView epHeadView;
    private volatile boolean switchingSrc;

    /** 一条可切换片源；ms<0 表示该源起播时还没测完速 */
    private static final class SrcOpt {
        String key = "", id = "", name = "片源";
        long ms = -1;
        boolean fastest;
    }

    // ---- 手机端点播触控 OSD（电视版与手机版直播完全走原 buildUi，零改动）----
    private boolean phoneOsd;
    private FrameLayout phoneTouch;
    private TextView tvCur, tvDur, tvCount, tvFav, btnPlayLabel, phoneRetry;
    private SeekBar seekBar;
    private boolean dragging;
    private float phoneSpeed = 1f;
    private int accentColor = AppTheme.DEFAULT_ACCENT;
    /** 底栏 / 顶栏半透明卡片底：与选集抽屉 PANEL 同色系 */
    private static final int VOD_BAR_BG = 0xE6141A25;
    /** 底栏按钮与选集抽屉里的主题色零件：换主题时不重建 view，直接重刷 */
    private TextView bSpeed, bSkip, bRatio, bEp, bDecode;
    private View vodRule;

    /**
     * 电视端菜单与手机后台「点播播放引擎 / 点播画面比例」共用同一份配置。
     * 后台保存时本页仍在前台、不会走 onResume，所以低频比对一次 Store，
     * 发现变了就立即应用；每秒一次 sp 读取，开销可忽略。
     */
    private final Runnable checkVodDecodeMode = new Runnable() {
        @Override public void run() {
            if (isFinishing()) return;
            String m = Store.vodDecodeMode(PlayerActivity.this);
            String a = Store.vodAspect(PlayerActivity.this);
            boolean changed = !m.equals(appliedVodDecodeMode) || !a.equals(appliedVodAspect);
            if (changed) {
                if (modalDialogs > 0) {              // 对话框开着，等下一轮再应用
                    handler.postDelayed(this, 1000);
                    return;
                }
                if (!a.equals(appliedVodAspect)) {
                    appliedVodAspect = a;
                    applyVodAspect(a, "点播画面比例（已同步）");
                }
                if (!m.equals(appliedVodDecodeMode)) {
                    appliedVodDecodeMode = m;
                    applyVodDecodeMode(m, "点播解码（已同步）");
                }
                if (phoneOsd) updatePhoneLabels();
            }
            handler.postDelayed(this, 1000);
        }
    };
    private float pendingRatio = -1f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // v107：登记为当前播放页，跨类型推送时由 PlaySession 先收掉本页
        PlaySession.attach(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        if (!parseIntent()) {
            finish();
            return;
        }
        // 手机端点播走触控 OSD；电视版与手机版直播仍走原来的遥控器 OSD，代码路径不变。
        if (BuildConfig.IS_PHONE && !liveMode) buildPhoneUi();
        else buildUi();
        decodeMode = Store.vodDecodeMode(this);
        appliedVodDecodeMode = decodeMode;
        aspectMode = Store.vodAspect(this);
        appliedVodAspect = aspectMode;
        if (phoneOsd) updatePhoneLabels();   // 状态栏显示实际比例档，而非字段默认值
        // 自动选择 / 内置 ExoPlayer 都先按内置起步；只有「系统解码」档一上来就开回退
        buildPlayer("sysdec".equals(decodeMode));
        playEpisode(currentIndex, pendingSeekMs);
        handler.post(tick);
        handler.postDelayed(checkVodDecodeMode, 1000);
    }

    // ---------------------------------------------------------------- 参数

    private boolean parseIntent() {
        try {
            Intent it = getIntent();
            port = it.getIntExtra("port", TvServer.PORT);
            nativeRec = it.getStringExtra("nativeRec");
            String cfg = it.getStringExtra("cfg");
            if (cfg == null) return false;
            JSONObject o = new JSONObject(cfg);
            JSONArray arr = o.optJSONArray("episodes");
            if (arr == null || arr.length() == 0) return false;
            episodes = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) episodes[i] = arr.optString(i, "");
            currentIndex = o.optInt("index", 0);
            if (currentIndex < 0 || currentIndex >= episodes.length) currentIndex = 0;
            title = o.optString("title", "");
            sourceName = o.optString("sourceName", "");
            sourceKey = o.optString("sourceKey", "");
            vodId = o.optString("vodId", "");
            coverUrl = o.optString("cover", "");
            JSONArray st = o.optJSONArray("srcTop");
            if (st != null) {
                SrcOpt[] tmp = new SrcOpt[st.length()];
                for (int i = 0; i < st.length(); i++) {
                    JSONObject s = st.optJSONObject(i);
                    SrcOpt so = new SrcOpt();
                    if (s != null) {
                        so.key = s.optString("k", "");
                        so.id = s.optString("id", "");
                        so.name = s.optString("name", "片源");
                        so.ms = s.optLong("ms", -1);
                        so.fastest = s.optBoolean("fastest", false);
                    }
                    tmp[i] = so;
                }
                srcTop = tmp;
            }
            skipIntro = Math.max(0, o.optInt("skipIntro", 0));
            skipOutro = Math.max(0, o.optInt("skipOutro", 0));
            pendingSeekMs = o.optLong("resumeMs", 0);
            liveMode = o.optBoolean("live", false);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** 与 JS encodeURIComponent 等价，避免 Java URLEncoder 把空格编成 + 导致代理解析出错 */
    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8").replace("+", "%20").replace("%7E", "~");
        } catch (UnsupportedEncodingException e) {
            return s;
        }
    }

    private String proxyUrl(String raw) {
        // SMB 网盘文件已经由内置服务的 /smb 端点代理成 HTTP 流（自带 Range/206），
        // 再套一层 /hls 只会多一次本机往返，直接播即可。
        if (raw.startsWith("http://127.0.0.1:") && raw.contains("/smb?")) return raw;
        return "http://127.0.0.1:" + port + "/hls?url=" + enc(raw);
    }

    // ---------------------------------------------------------------- 界面

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        surface = new SurfaceView(this);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER);
        root.addView(surface, slp);

        // 顶部标题栏
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.VERTICAL);
        topBar.setBackgroundColor(0xB0000000);
        topBar.setPadding(dp(24), dp(14), dp(24), dp(14));
        tvTitle = new TextView(this);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tvTitle.setSingleLine(true);
        topBar.addView(tvTitle);
        root.addView(topBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP));

        // 底部控制条
        ctlBar = new LinearLayout(this);
        ctlBar.setOrientation(LinearLayout.VERTICAL);
        ctlBar.setBackgroundColor(0xB0000000);
        ctlBar.setPadding(dp(24), dp(12), dp(24), dp(16));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        tvTime = new TextView(this);
        tvTime.setTextColor(Color.WHITE);
        tvTime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        row.addView(tvTime, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        // 右下角按键提示：末尾加「菜单键图标 + 菜单」，与前面几项同一套灰字风格。
        // 图标用自绘三横线（菜单栏图标），不依赖电视字体是否带 ☰ 字形，避免豆腐块。
        LinearLayout tipsRow = new LinearLayout(this);
        tipsRow.setOrientation(LinearLayout.HORIZONTAL);
        tipsRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tips = new TextView(this);
        tips.setText("← → 快退/快进   OK 暂停   ↓ 选集   ");
        tips.setTextColor(0xFF9AA6B8);
        tips.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tipsRow.addView(tips);

        View menuIcon = new View(this) {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            {
                p.setColor(0xFFC7D0DE);
                p.setStrokeWidth(PlayerActivity.this.dp(2));
                p.setStrokeCap(Paint.Cap.ROUND);
            }
            @Override protected void onDraw(Canvas c) {
                super.onDraw(c);
                float w = getWidth(), h = getHeight();
                float pad = h * 0.22f;
                float gap = (h - 2f * pad) / 2f;
                for (int i = 0; i < 3; i++) {
                    float y = pad + gap * i;
                    c.drawLine(PlayerActivity.this.dp(1), y,
                            w - PlayerActivity.this.dp(1), y, p);
                }
            }
        };
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(15), dp(12));
        iconLp.rightMargin = dp(5);
        tipsRow.addView(menuIcon, iconLp);

        TextView menuLabel = new TextView(this);
        menuLabel.setText("菜单   ↩ 退出");
        menuLabel.setTextColor(0xFF9AA6B8);
        menuLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tipsRow.addView(menuLabel);

        row.addView(tipsRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ctlBar.addView(row);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        progress.setProgress(0);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(5));
        plp.topMargin = dp(8);
        ctlBar.addView(progress, plp);
        root.addView(ctlBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        // 居中提示（加载 / 短消息）
        tvLoading = new TextView(this);
        tvLoading.setTextColor(0xFFE6EDF7);
        tvLoading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        tvLoading.setBackgroundColor(0x99000000);
        tvLoading.setPadding(dp(24), dp(12), dp(24), dp(12));
        tvLoading.setVisibility(View.GONE);
        root.addView(tvLoading, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        tvHint = new TextView(this);
        tvHint.setTextColor(Color.WHITE);
        tvHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        tvHint.setBackgroundColor(0xCC11151C);
        tvHint.setPadding(dp(18), dp(9), dp(18), dp(9));
        tvHint.setVisibility(View.GONE);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        hlp.bottomMargin = dp(96);
        root.addView(tvHint, hlp);

        buildEpisodeOverlay();
        updateTitle();
        setCtlVisible(true);
    }

    // ---------------------------------------------------------------- 手机端点播触控 OSD

    /** 主题色统一走 AppTheme；直播 / 点播共用同一张表，换主题两端一起变 */
    private int phoneAccent() {
        return AppTheme.accent(this);
    }

    private TextView phoneText(String s, int sizeSp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        t.setSingleLine(true);
        return t;
    }

    /**
     * 底栏按钮：与选集抽屉 / 直播功能菜单同一套 LiveTheme 三档态
     * （聚焦主题实心+白描边、选中主题暗底+主题描边、常态 ROW_SOFT+低对比描边）。
     * 选中态用来表达「当前档位非默认」，和选集里高亮当前集是同一种视觉语言。
     */
    private TextView phoneButton(String s) {
        TextView t = phoneText(s, 15, LiveTheme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setMinimumWidth(dp(80));   // 统一宽度下限，整排按钮看起来齐整
        t.setPadding(dp(12), dp(11), dp(12), dp(11));
        t.setClickable(true);
        // 手机是触屏：不设 focusable，避免点完按钮残留焦点被画成「主题实心+白描边」误以为开启。
        // 仍复用 LiveMenuSkin.rowBg 的同一套三档函数，实际只会落到 selected / 常态两档。
        t.setBackground(LiveMenuSkin.rowBg(this));
        t.setTextColor(new ColorStateList(
                new int[][]{ new int[]{ android.R.attr.state_selected }, new int[]{} },
                new int[]{ Color.WHITE, LiveTheme.TEXT }));
        return t;
    }

    /** 主操作（暂停）：主题色实心 + 白字，和选集「当前集 / 当前片源」同一语言 */
    private StateListDrawable vodPrimaryBg() {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{ android.R.attr.state_focused },
                LiveTheme.stroke(this, accentColor, LiveTheme.R_ROW, 2, Color.WHITE));
        bg.addState(new int[]{},
                LiveTheme.card(this, accentColor, LiveTheme.R_ROW));
        return bg;
    }

    private LinearLayout.LayoutParams phoneBtnLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(5);       // 左右对称，居中后不会偏
        lp.rightMargin = dp(5);
        return lp;
    }

    /**
     * 手机版影视点播 OSD：顶栏返回+片名+集数进度、可拖进度条、一排触控按钮、
     * 底部片源信息与倍速/比例状态。轻触画面显隐，视频区始终纯黑底。
     */
    private void buildPhoneUi() {
        phoneOsd = true;
        accentColor = phoneAccent();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        surface = new SurfaceView(this);
        root.addView(surface, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER));

        // 轻触层：视频区任意位置点一下显/隐 OSD；按钮和进度条是子 view，点击不冒泡
        phoneTouch = new FrameLayout(this);
        phoneTouch.setClickable(true);
        phoneTouch.setOnClickListener(v -> togglePhoneCtl());
        root.addView(phoneTouch, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶栏：‹ 返回 + 片名·集数·源 + 集数进度
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(VOD_BAR_BG);
        topBar.setPadding(dp(16), dp(12), dp(16), dp(12));
        topBar.setClickable(true);
        TextView back = phoneText("‹", 28, Color.WHITE);
        back.setPadding(dp(4), 0, dp(18), 0);
        back.setOnClickListener(v -> finishWith(false, false));
        topBar.addView(back);
        tvTitle = phoneText("", 17, Color.WHITE);
        topBar.addView(tvTitle, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tvCount = phoneText("", 15, 0xFFC7D0DE);
        topBar.addView(tvCount);
        phoneTouch.addView(topBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP));

        // 底栏：时间 + 可拖进度条 + 按钮行（底部两侧提示文字已按需求去掉）
        ctlBar = new LinearLayout(this);
        ctlBar.setOrientation(LinearLayout.VERTICAL);
        ctlBar.setBackgroundColor(VOD_BAR_BG);
        ctlBar.setPadding(dp(18), dp(10), dp(18), dp(14));
        ctlBar.setClickable(true);

        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        timeRow.setGravity(Gravity.CENTER_VERTICAL);
        // 两侧时间固定同宽 + 等宽数字（tnum），各自贴着进度条，左右完全对称
        tvCur = phoneText("00:00", 13, 0xFFE6EDF7);
        tvCur.setFontFeatureSettings("tnum");
        tvCur.setGravity(Gravity.END);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                dp(50), ViewGroup.LayoutParams.WRAP_CONTENT);
        timeRow.addView(tvCur, clp);
        seekBar = new SeekBar(this);
        seekBar.setMax(1000);
        seekBar.setProgressTintList(ColorStateList.valueOf(accentColor));
        seekBar.setThumbTintList(ColorStateList.valueOf(accentColor));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        slp.leftMargin = dp(12);
        slp.rightMargin = dp(12);
        timeRow.addView(seekBar, slp);
        tvDur = phoneText("--:--", 13, 0xFFE6EDF7);
        tvDur.setFontFeatureSettings("tnum");
        tvDur.setGravity(Gravity.START);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                dp(50), ViewGroup.LayoutParams.WRAP_CONTENT);
        timeRow.addView(tvDur, dlp);
        ctlBar.addView(timeRow);
        progress = seekBar;   // 复用原字段，tick 里照常 setProgress
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar s) {
                dragging = true;
                handler.removeCallbacks(hideCtl);
            }
            @Override public void onStopTrackingTouch(SeekBar s) {
                dragging = false;
                if (kernelReady()) {
                    long d = kDur();
                    if (d > 0 && d != C.TIME_UNSET) kSeek(d * s.getProgress() / 1000L);
                }
                setCtlVisible(true);
            }
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && tvCur != null && kernelReady()) {
                    long d = kDur();
                    if (d > 0 && d != C.TIME_UNSET) tvCur.setText(fmt(d * p / 1000L));
                }
            }
        });

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setFillViewport(true);        // 内容不足一屏时撑满，让按钮整排居中
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);
        btnPlayLabel = phoneButton("暂停");
        btnPlayLabel.setTextColor(Color.WHITE);
        btnPlayLabel.setBackground(vodPrimaryBg());
        btnPlayLabel.setOnClickListener(v -> togglePlay());
        btnRow.addView(btnPlayLabel, phoneBtnLp());
        bSpeed = phoneButton("倍速");
        bSpeed.setOnClickListener(v -> cyclePhoneSpeed());
        btnRow.addView(bSpeed, phoneBtnLp());
        bSkip = phoneButton("跳过");
        bSkip.setOnClickListener(v -> skipSegments());
        btnRow.addView(bSkip, phoneBtnLp());
        bRatio = phoneButton("比例");
        bRatio.setOnClickListener(v -> cyclePhoneAspect());
        btnRow.addView(bRatio, phoneBtnLp());
        bEp = phoneButton("选集");
        bEp.setOnClickListener(v -> openEpisodes());
        btnRow.addView(bEp, phoneBtnLp());
        // 「解码」紧挨收藏左侧：点一下循环切换解码方式并立即生效
        bDecode = phoneButton("解码");
        bDecode.setOnClickListener(v -> cyclePhoneDecode());
        btnRow.addView(bDecode, phoneBtnLp());
        tvFav = phoneButton("☆ 收藏");
        tvFav.setOnClickListener(v -> togglePhoneFav());
        btnRow.addView(tvFav, phoneBtnLp());
        hs.addView(btnRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // 主题色短线：与直播功能菜单卡片顶部、首页页脚同一个视觉锚点
        vodRule = new View(this);
        vodRule.setBackgroundColor(accentColor);
        LinearLayout.LayoutParams ruleLp = new LinearLayout.LayoutParams(dp(28), dp(3));
        ruleLp.gravity = Gravity.CENTER;
        ruleLp.topMargin = dp(8);
        ctlBar.addView(vodRule, ruleLp);
        LinearLayout.LayoutParams hslp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hslp.topMargin = dp(10);
        ctlBar.addView(hs, hslp);

        // 底部两侧提示文字（左下片源信息 / 右下倍速·比例胶囊）已去掉，
        // 底栏只保留时间行与按钮行；倍速/比例/解码切换仍用居中 hint 反馈当前档位。
        phoneTouch.addView(ctlBar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        // 居中缓冲 / 错误提示 + 重试
        tvLoading = new TextView(this);
        tvLoading.setTextColor(0xFFE6EDF7);
        tvLoading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvLoading.setGravity(Gravity.CENTER);
        tvLoading.setBackgroundColor(0x99000000);
        tvLoading.setPadding(dp(24), dp(12), dp(24), dp(12));
        tvLoading.setVisibility(View.GONE);
        phoneTouch.addView(tvLoading, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        phoneRetry = phoneButton("重试播放");
        phoneRetry.setVisibility(View.GONE);
        phoneRetry.setOnClickListener(v -> {
            phoneRetry.setVisibility(View.GONE);
            errorOccurred = false;
            decoderRetryDone = false;
            long pos = 0;
            try { if (kernelReady()) pos = kPos(); } catch (Exception ignored) {}
            playEpisode(currentIndex, pos);
        });
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        rlp.topMargin = dp(72);
        phoneTouch.addView(phoneRetry, rlp);

        tvHint = new TextView(this);
        tvHint.setTextColor(Color.WHITE);
        tvHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvHint.setBackgroundColor(0xCC11151C);
        tvHint.setPadding(dp(18), dp(9), dp(18), dp(9));
        tvHint.setVisibility(View.GONE);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        hlp.bottomMargin = dp(110);
        phoneTouch.addView(tvHint, hlp);

        buildEpisodeOverlay();
        updateTitle();
        updatePhoneLabels();
        setCtlVisible(true);
    }

    private void togglePhoneCtl() {
        if (!phoneOsd) return;
        setCtlVisible(ctlBar.getVisibility() != View.VISIBLE);
    }

    private void updatePhoneLabels() {
        if (!phoneOsd) return;
        if (tvCount != null) tvCount.setText((currentIndex + 1) + "/" + episodes.length);
        boolean fav = Store.isVodFav(this, title);
        if (tvFav != null) {
            tvFav.setText(fav ? "★ 已收藏" : "☆ 收藏");
            tvFav.setSelected(fav);
        }
        // 非默认档位 / 已收藏 → 主题色高亮，和选集「当前集」同一套三档态
        if (bSpeed != null) bSpeed.setSelected(Math.abs(phoneSpeed - 1f) > 0.01f);
        if (bRatio != null) bRatio.setSelected(!Store.DEFAULT_ASPECT.equals(aspectMode));
        if (bDecode != null) bDecode.setSelected(!"auto".equals(Store.vodDecodeMode(this)));
    }

    /**
     * 后台换主题后回到播放页：不重建 view（不打断播放），只重刷所有主题色零件。
     * 直播侧的功能菜单 / 节目表弹窗每次 show 都会重读 AppTheme，天然即时生效。
     */
    private void refreshVodAccent() {
        if (!phoneOsd) return;
        int now = AppTheme.accent(this);
        if (now == accentColor) return;
        accentColor = now;
        if (seekBar != null) {
            seekBar.setProgressTintList(ColorStateList.valueOf(accentColor));
            seekBar.setThumbTintList(ColorStateList.valueOf(accentColor));
        }
        if (btnPlayLabel != null) btnPlayLabel.setBackground(vodPrimaryBg());
        TextView[] btns = { bSpeed, bSkip, bRatio, bEp, bDecode, tvFav };
        for (TextView b : btns) if (b != null) b.setBackground(LiveMenuSkin.rowBg(this));
        if (vodRule != null) vodRule.setBackgroundColor(accentColor);
        renderSrcChips();   // chip 选中态用主题色实心，换主题要一起刷
        if (epAdapter != null) epAdapter.notifyDataSetChanged();
    }

    private void cyclePhoneSpeed() {
        int next = 1;
        for (int k = 0; k < PHONE_SPEEDS.length; k++) {
            if (Math.abs(PHONE_SPEEDS[k] - phoneSpeed) < 0.01f) {
                next = (k + 1) % PHONE_SPEEDS.length;
                break;
            }
        }
        phoneSpeed = PHONE_SPEEDS[next];
        kParams(phoneSpeed);
        hint("倍速 " + (phoneSpeed == 1f ? "1.0x" : (Math.round(phoneSpeed * 100) / 100f) + "x"));
        updatePhoneLabels();
        setCtlVisible(true);
    }

    private void cyclePhoneAspect() {
        String[] v = Store.VOD_ASPECT_VALUES;
        int next = 0;
        for (int k = 0; k < v.length; k++) {
            if (v[k].equals(aspectMode)) { next = (k + 1) % v.length; break; }
        }
        appliedVodAspect = v[next];
        applyVodAspect(v[next], null);
        updatePhoneLabels();
        setCtlVisible(true);
    }

    /**
     * 手机端「解码」按钮：和「比例」一样点一下就切到下一档并立即生效，不弹选择框。
     * 自动选择 → 内置 ExoPlayer → 系统解码 → IJK 解码 → 自动选择，循环。
     */
    private void cyclePhoneDecode() {
        final String[] values = IjkDecode.VALUES;
        String cur = Store.vodDecodeMode(this);
        int next = 0;
        for (int k = 0; k < values.length; k++) {
            if (values[k].equals(cur)) { next = (k + 1) % values.length; break; }
        }
        appliedVodDecodeMode = values[next];   // 已即时应用，轮询别再重复重建
        applyVodDecodeMode(values[next], null);
        setCtlVisible(true);
    }

    /** 「跳过」：片头区间内跳到片头后；其余跳到片尾起点，不强制切集 */
    private void skipSegments() {
        if (!kernelReady()) return;
        long d = kDur();
        long p = kPos();
        if (d <= 0 || d == C.TIME_UNSET) { hint("尚未获取到时长"); return; }
        long intro = (long) skipIntro * 1000L;
        long outro = Math.min((long) skipOutro * 1000L, d / 2);
        if (intro > 0 && p < intro + 5000L) {
            kSeek(intro);
            hint("已跳过片头 " + skipIntro + " 秒");
        } else if (outro > 0) {
            kSeek(Math.max(0, d - outro - 500L));
            hint("已跳到片尾");
        } else {
            hint("后台未设置跳过片头/片尾");
        }
        setCtlVisible(true);
    }

    private void togglePhoneFav() {
        if (title == null || title.isEmpty()) { hint("片名为空，无法收藏"); return; }
        Model.History h = new Model.History();
        h.videoName = title;
        h.episodeName = "第 " + (currentIndex + 1) + " 集";
        h.sourceName = sourceName == null ? "" : sourceName;
        h.playUrl = episodes.length > 0 ? episodes[currentIndex] : "";
        h.positionMs = kPos();
        h.updatedAt = System.currentTimeMillis();
        boolean now = Store.toggleVodFav(this, h);
        hint(now ? "已加入收藏" : "已取消收藏");
        updatePhoneLabels();
        setCtlVisible(true);
    }

    private void buildEpisodeOverlay() {
        // 电视版（含手机版直播）保持历版全屏选集；只有手机端点播走右侧抽屉
        if (phoneOsd) buildPhoneEpisodeDrawer();
        else buildTvEpisodeOverlay();
    }

    /** 电视版选集浮层：全屏 8 列网格，与历版逐字一致 */
    private void buildTvEpisodeOverlay() {
        epOverlay = new FrameLayout(this);
        epOverlay.setBackgroundColor(0xEE05070B);
        epOverlay.setVisibility(View.GONE);
        epOverlay.setClickable(true);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(36), dp(24), dp(36), dp(24));
        epHeadView = new TextView(this);
        epHeadView.setText("选集（共 " + episodes.length + " 集）   ·   按返回键关闭");
        epHeadView.setTextColor(Color.WHITE);
        epHeadView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        box.addView(epHeadView);
        // 与手机抽屉同一套片源 chip：电视遥控器可聚焦切换（直播没有候选源时不插这一行）
        if (!liveMode && srcTop.length > 0) box.addView(buildSrcChipRow());

        epGrid = new GridView(this);
        epGrid.setNumColumns(8);
        epGrid.setVerticalSpacing(dp(10));
        epGrid.setHorizontalSpacing(dp(10));
        epGrid.setSelector(new ColorDrawable(0x66FF5A3C));
        epGrid.setDrawSelectorOnTop(true);
        epGrid.setFocusable(true);
        epAdapter = new EpAdapter();
        epGrid.setAdapter(epAdapter);
        epGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                closeEpisodes();
                playEpisode(position, 0);
            }
        });
        box.addView(epGrid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        epOverlay.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(epOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        renderSrcChips();
    }

    private TextView phoneNavButton(String s) {
        // 与底栏按钮、直播功能菜单条目同一套三档态
        return phoneButton(s);
    }

    /** 手机端点播选集：从右侧滑出的抽屉，左侧画面保持可见 */
    private void buildPhoneEpisodeDrawer() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        phoneDrawerWidth = Math.max(dp(320), Math.round(dm.widthPixels * 0.42f));

        epOverlay = new FrameLayout(this);
        epOverlay.setVisibility(View.GONE);
        epOverlay.setClickable(true);

        // 左侧半透明遮罩：点一下收起抽屉，视频仍看得见
        View mask = new View(this);
        mask.setBackgroundColor(0x66000000);
        mask.setOnClickListener(v -> closeEpisodes());
        epOverlay.addView(mask, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        phoneDrawer = new LinearLayout(this);
        phoneDrawer.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(LiveTheme.PANEL);
        float r = dp(16);
        panelBg.setCornerRadii(new float[]{r, r, 0, 0, 0, 0, r, r});
        phoneDrawer.setBackground(panelBg);
        phoneDrawer.setPadding(dp(18), dp(14), dp(18), dp(14));
        phoneDrawer.setClickable(true);   // 挡住点击，不穿透到遮罩

        // 标题行：选集 · N 集            ✕
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        epHeadView = phoneText("选集 · " + episodes.length + " 集", 20, LiveTheme.TEXT);
        TextView hd = epHeadView;
        head.addView(hd, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = phoneText("✕", 24, LiveTheme.SUB);
        close.setPadding(dp(12), dp(2), dp(4), dp(2));
        close.setOnClickListener(v -> closeEpisodes());
        head.addView(close);
        phoneDrawer.addView(head);

        TextView tip = phoneText("点集数立即切换（自动保存进度）", 13, LiveTheme.SUB);
        tip.setSingleLine(false);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(6);
        phoneDrawer.addView(tip, tlp);

        // 上一集 / 下一集
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        TextView prev = phoneNavButton("‹ 上一集");
        prev.setOnClickListener(v -> stepEpisode(-1));
        TextView next = phoneNavButton("下一集 ›");
        next.setOnClickListener(v -> stepEpisode(1));
        nav.addView(prev, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nlp.leftMargin = dp(10);
        nav.addView(next, nlp);
        LinearLayout.LayoutParams navlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        navlp.topMargin = dp(14);
        phoneDrawer.addView(nav, navlp);

        // 片源行：最多 3 个「延时最低」的源，点一下就切（沿用网页竞速结果排序）
        LinearLayout.LayoutParams srlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        srlp.topMargin = dp(16);
        phoneDrawer.addView(buildSrcChipRow(), srlp);
        TextView srcTip = phoneText("片源 · 点击切换（保留当前进度）", 11, LiveTheme.FOOT);
        srcTip.setSingleLine(false);
        LinearLayout.LayoutParams stlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stlp.topMargin = dp(6);
        phoneDrawer.addView(srcTip, stlp);

        epGrid = new GridView(this);
        epGrid.setNumColumns(5);
        epGrid.setVerticalSpacing(dp(10));
        epGrid.setHorizontalSpacing(dp(10));
        epGrid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        epGrid.setFocusable(false);
        epAdapter = new EpAdapter();
        epGrid.setAdapter(epAdapter);
        epGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                closeEpisodes();
                playEpisode(position, 0);
            }
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        glp.topMargin = dp(14);
        phoneDrawer.addView(epGrid, glp);

        epOverlay.addView(phoneDrawer, new FrameLayout.LayoutParams(
                phoneDrawerWidth, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.RIGHT));
        root.addView(epOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        renderSrcChips();
    }

    // ---------------------------------------------------------------- 片源切换（3 个最低延时源）

    /** 造一行可横滑的片源 chip，手机抽屉与电视全屏选集页共用 */
    private View buildSrcChipRow() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setFillViewport(true);
        srcChipRow = new LinearLayout(this);
        srcChipRow.setOrientation(LinearLayout.HORIZONTAL);
        srcChipRow.setGravity(Gravity.CENTER_VERTICAL);
        hs.addView(srcChipRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(16);
        hs.setLayoutParams(lp);
        return hs;
    }

    /** 当前正在播的源：优先用 key|id 精确匹配，老配置没带这两个字段时退回源名 */
    private boolean sameSrc(SrcOpt o) {
        if (o == null) return false;
        if (sourceKey != null && !sourceKey.isEmpty() && o.key != null && !o.key.isEmpty())
            return sourceKey.equals(o.key) && String.valueOf(vodId).equals(String.valueOf(o.id));
        return (sourceName == null ? "" : sourceName).equals(o.name);
    }

    private void renderSrcChips() {
        if (srcChipRow == null) return;
        srcChipRow.removeAllViews();
        if (srcTop.length == 0) {
            // 没有候选源（单源片 / SMB / 直播）：仍显示一个当前源 chip，不造假 3 个
            SrcOpt cur = new SrcOpt();
            cur.name = (sourceName == null || sourceName.isEmpty()) ? "当前片源" : sourceName;
            cur.key = sourceKey; cur.id = vodId;
            addSrcChip(cur, true, false);   // 单源 / SMB / 直播：只作展示，不给无效点击
            return;
        }
        for (SrcOpt o : srcTop) addSrcChip(o, sameSrc(o), true);
    }

    private void addSrcChip(final SrcOpt o, boolean selected, boolean clickable) {
        String sub = o.ms < 0 ? "测速中" : (o.fastest ? "最快 " + o.ms + " ms" : o.ms + " ms");
        TextView chip = phoneText(o.name + "\n" + sub, 13, selected ? Color.WHITE : LiveTheme.TEXT);
        chip.setSingleLine(false);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(15), dp(9), dp(15), dp(9));
        chip.setBackground(selected
                ? LiveTheme.card(this, accentColor, LiveTheme.R_ROW)
                : LiveTheme.stroke(this, LiveTheme.ROW, LiveTheme.R_ROW, 1, LiveTheme.LINE));
        chip.setClickable(clickable);
        chip.setFocusable(clickable);   // 电视遥控器可聚焦；背景不是 StateList，手机触屏不会残留高亮
        if (clickable) chip.setOnClickListener(v -> switchVodSource(o));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(10);
        srcChipRow.addView(chip, lp);
    }

    /**
     * 点 chip 换源：复用内置服务 /api/detail（与网页切源、点播推送直达同一套源站解析），
     * 后台线程拿新源剧集，成功后替换选集并保留当前播放进度续播，不打断界面、不重建播放器。
     */
    private void switchVodSource(final SrcOpt o) {
        if (o == null || switchingSrc || liveMode) return;
        if (sameSrc(o)) { hint("已经在 " + o.name); return; }
        if (o.key == null || o.key.isEmpty() || o.id == null || o.id.isEmpty()) {
            hint("这个片源缺少定位信息，无法切换");
            return;
        }
        switchingSrc = true;
        hint("正在切换到 " + o.name + "…");
        long pos = 0;
        try { if (kernelReady()) pos = kPos(); } catch (Exception ignored) {}
        final long resume = pos;
        new Thread(new Runnable() {
            @Override public void run() {
                String[] newEps = null;
                String err = null;
                try {
                    String url = "http://127.0.0.1:" + port
                            + "/api/detail?k=" + enc(o.key) + "&id=" + enc(o.id);
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(12000);
                    c.setRequestMethod("GET");
                    int code = c.getResponseCode();
                    InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                    String body = readAll(in);
                    c.disconnect();
                    JSONObject d = new JSONObject(body);
                    if (d.has("error")) err = d.optString("error", "源站无响应");
                    else {
                        JSONArray a = d.optJSONArray("episodes");
                        if (a != null && a.length() > 0) {
                            newEps = new String[a.length()];
                            for (int i = 0; i < a.length(); i++) newEps[i] = a.optString(i, "");
                        } else err = "该片源没有剧集";
                    }
                } catch (Exception e) {
                    err = e.getMessage() == null ? "取源失败" : e.getMessage();
                }
                final String[] eps = newEps;
                final String why = err;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        switchingSrc = false;
                        if (eps == null) {
                            hint("切换失败：" + (why == null ? "源站无响应" : why));
                            return;   // 保持原源、原 chip，不半途换掉
                        }
                        episodes = eps;
                        sourceName = o.name;
                        sourceKey = o.key;
                        vodId = o.id;
                        if (currentIndex >= episodes.length) currentIndex = 0;
                        renderSrcChips();
                        if (epHeadView != null) epHeadView.setText(phoneOsd
                                ? "选集 · " + episodes.length + " 集"
                                : "选集（共 " + episodes.length + " 集）   ·   按返回键关闭");
                        updateTitle();
                        if (epAdapter != null) epAdapter.notifyDataSetChanged();
                        if (epGrid != null) epGrid.setSelection(currentIndex);
                        playEpisode(currentIndex, resume);
                        hint("已切换到 " + o.name + " · " + episodes.length + " 集");
                    }
                });
            }
        }, "vod-src-switch").start();
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), "UTF-8");
    }

    /** 抽屉里的上一集 / 下一集，到头给提示不越界 */
    private void stepEpisode(int delta) {
        int t = currentIndex + delta;
        if (t < 0 || t >= episodes.length) {
            hint(delta > 0 ? "已经是最后一集" : "已经是第一集");
            return;
        }
        closeEpisodes();
        playEpisode(t, 0);
    }

    private class EpAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return episodes.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (!phoneOsd) {
                // 电视版：历版原样
                TextView v = new TextView(PlayerActivity.this);
                v.setText("第 " + (position + 1) + " 集");
                v.setTextColor(position == currentIndex ? 0xFFFFC4B5 : 0xFFCFD8E6);
                v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                v.setGravity(Gravity.CENTER);
                v.setPadding(dp(4), dp(13), dp(4), dp(13));
                v.setBackgroundColor(position == currentIndex ? 0xFF5A2318 : 0xFF1A2130);
                v.setFocusable(false); // 由 GridView 统一处理焦点
                return v;
            }
            // 手机版：按总集数补零（第023集），圆角卡片，当前集用主题色
            // v109：标签收口到 EpLabel，只用「集」，与顶栏 / 电视版 / 网页端一致
            String label = EpLabel.grid(position, episodes.length);

            boolean cur = position == currentIndex;
            TextView v = new TextView(PlayerActivity.this);
            v.setText(label);
            v.setTextColor(cur ? Color.WHITE : LiveTheme.TEXT);
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            v.setGravity(Gravity.CENTER);
            v.setPadding(dp(4), dp(12), dp(4), dp(12));
            // 与底栏按钮 / 直播功能菜单共用色板：当前集主题实心，未选 ROW + LINE 描边
            GradientDrawable g = cur
                    ? LiveTheme.card(PlayerActivity.this, accentColor, LiveTheme.R_ROW)
                    : LiveTheme.stroke(PlayerActivity.this, LiveTheme.ROW,
                            LiveTheme.R_ROW, 1, LiveTheme.LINE);
            v.setBackground(g);
            v.setFocusable(false);
            return v;
        }
    }

    private void updateTitle() {
        String s = title;
        if (s == null) s = "";
        if (!s.isEmpty()) s += "  ·  ";
        s += "第 " + (currentIndex + 1) + " 集";
        if (sourceName != null && !sourceName.isEmpty()) s += "  ·  " + sourceName;
        tvTitle.setText(s);
        if (epAdapter != null) epAdapter.notifyDataSetChanged();
        if (phoneOsd) updatePhoneLabels();
    }

    private void setCtlVisible(boolean yes) {
        int v = yes ? View.VISIBLE : View.GONE;
        ctlBar.setVisibility(v);
        topBar.setVisibility(v);
        if (yes) {
            handler.removeCallbacks(hideCtl);
            handler.postDelayed(hideCtl, phoneOsd ? 5000 : CTL_HIDE_DELAY);
        }
    }

    private void hint(String msg) {
        tvHint.setText(msg);
        tvHint.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideHint);
        handler.postDelayed(hideHint, 1600);
    }

    private void showLoading(boolean yes, String msg) {
        tvLoading.setText(msg);
        tvLoading.setVisibility(yes ? View.VISIBLE : View.GONE);
    }

    // ---------------------------------------------------------------- ExoPlayer

    // ---------- v110：IJK / ExoPlayer 统一控制层 ----------
    private boolean kernelReady() { return ijkActive ? ijk != null : player != null; }

    private long kPos() {
        if (ijkActive) return ijk == null ? 0L : ijk.position();
        return player == null ? 0L : player.getCurrentPosition();
    }

    private long kDur() {
        if (ijkActive) return ijk == null ? 0L : ijk.duration();
        return player == null ? 0L : player.getDuration();
    }

    private void kSeek(long ms) {
        if (ijkActive) { if (ijk != null) ijk.seekTo(ms); }
        else if (player != null) player.seekTo(Math.max(0L, ms));
    }

    private void kPlay(boolean on) {
        if (ijkActive) { if (ijk != null) { if (on) ijk.play(); else ijk.pause(); } }
        else if (player != null) player.setPlayWhenReady(on);
    }

    private boolean kPlayWhenReady() {
        return ijkActive ? (ijk != null && ijk.playWhenReady())
                : (player != null && player.getPlayWhenReady());
    }

    private void kParams(float sp) {
        if (ijkActive) { if (ijk != null) ijk.setSpeed(sp); }
        else if (player != null) player.setPlaybackParameters(new PlaybackParameters(sp));
    }

    /** IJK 不暴露缓冲进度，用当前位置代替，进度条不至于倒退 */
    private long kBuffered() {
        return ijkActive ? kPos() : (player == null ? 0L : player.getBufferedPosition());
    }

    /** 切到 IJK 时只释放 ExoPlayer，保留 surface（切回来还要用） */
    private void releaseExoPlayer() {
        if (player == null) return;
        try { player.removeListener(this); } catch (Exception ignored) {}
        try { player.release(); } catch (Exception ignored) {}
        player = null;
    }

    /**
     * 建播放器。
     * sysdec（网页后台「系统解码」）或解码失败重试时 decoderFallback=true：
     * 显式使用系统 MediaCodec 渲染器，硬解初始化失败自动回退到设备可用的其它解码器
     * （通常是软解），而不是直接报错退出。
     */
    private void buildPlayer(boolean decoderFallback) {
        if (IjkDecode.isIjk(decodeMode)) {
            IjkKernel k = IjkKernel.create(this, surface, new IjkKernel.Callback() {
                @Override public void onReady() {
                    handler.post(new Runnable() { @Override public void run() {
                        showLoading(false, "");
                        if (phoneOsd && phoneRetry != null) phoneRetry.setVisibility(View.GONE);
                        onKernelState(Player.STATE_READY);
                    }});
                }
                @Override public void onError(final String message) {
                    handler.post(new Runnable() { @Override public void run() {
                        errorOccurred = true;
                        showLoading(true, "IJK 解码失败\n" + message
                                + "\n返回换片源或在后台切换播放引擎");
                        hint("IJK 解码失败，请换一个片源或切换播放引擎");
                        if (phoneOsd && phoneRetry != null) phoneRetry.setVisibility(View.VISIBLE);
                    }});
                }
                @Override public void onVideoSize(final int w, final int h, final float pr) {
                    handler.post(new Runnable() { @Override public void run() {
                        onKernelVideoSize(w, h, pr);
                    }});
                }
                @Override public void onEnded() {
                    handler.post(new Runnable() { @Override public void run() {
                        onKernelState(Player.STATE_ENDED);
                    }});
                }
            });
            if (k != null) {
                releaseExoPlayer();
                ijk = k;
                ijkActive = true;
                if (phoneOsd && phoneSpeed != 1f) ijk.setSpeed(phoneSpeed);
                return;                 // IJK 是独立内核，不建 ExoPlayer
            }
            // 设备里没有 ijkplayer 运行库：回落到系统解码，给一次可读提示，不让用户黑屏
            decodeMode = IjkDecode.effective(decodeMode, false);
            String n = IjkDecode.notice(IjkDecode.IJK, false);
            if (n != null) hint(n);
        }
        if (ijkActive) {               // 从 IJK 切回其它档：先释放独立内核
            try { ijk.release(); } catch (Throwable ignored) {}
            ijk = null;
            ijkActive = false;
        }
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent("LibreTV-TV/3.1.0 (Android; ExoPlayer)")
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000)
                .setAllowCrossProtocolRedirects(true);
        DataSource.Factory ds = new DefaultDataSource.Factory(this, http);

        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
                .setEnableDecoderFallback(decoderFallback);

        player = new ExoPlayer.Builder(this)
                .setRenderersFactory(renderers)
                .build();
        player.setVideoSurfaceView(surface);
        // 「全屏显示」起步就裁剪铺满；自适应先按不裁剪兜底，拿到片源尺寸后立即重判
        player.setVideoScalingMode("full".equals(aspectMode)
                ? C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                : C.VIDEO_SCALING_MODE_SCALE_TO_FIT);
        player.addListener(this);
        dataSourceFactory = ds;
        // 切换解码档位会重建播放器，手机端已选倍速要接着生效
        if (phoneOsd && phoneSpeed != 1f) {
            kParams(phoneSpeed);
        }
    }

    private DataSource.Factory dataSourceFactory;

    private void playEpisode(int index, long resumeMs) {
        if (!kernelReady() || episodes.length == 0) return;
        if (index < 0 || index >= episodes.length) return;
        currentIndex = index;
        pendingSeekMs = resumeMs;
        introDone = false;
        outroDone = false;
        showLoading(true, "加载中…");
        updateTitle();

        String raw = episodes[index];
        String url = proxyUrl(raw);
        if (ijkActive && ijk != null) {
            // IJK 自己解封装：HLS / MP4 / FLV 都交给 FFmpeg，不走 MediaSource
            java.util.Map<String, String> h = new java.util.LinkedHashMap<>();
            h.put("User-Agent", "LibreTV-TV/3.1.0 (Android; IJK)");
            ijk.open(url, resumeMs, h);
            setCtlVisible(true);
            return;
        }
        MediaItem item = new MediaItem.Builder().setUri(url).build();
        MediaSource ms;
        if (liveMode || raw.toLowerCase().contains(".m3u8")) {
            // 直播流虽常不带 .m3u8 后缀（如 live.php?id=xxx），实际是 HLS，必须走 HLS 引擎
            ms = new HlsMediaSource.Factory(dataSourceFactory).createMediaSource(item);
        } else {
            ms = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(item);
        }
        player.setMediaSource(ms);
        player.prepare();
        kPlay(true);
        setCtlVisible(true);
    }

    @Override
    public void onPlaybackStateChanged(int state) {
        if (ijkActive) return;          // IJK 走自己的回调，不经过 ExoPlayer Listener
        onKernelState(state);
    }

    /** ExoPlayer 与 IJK 共用的状态机：续播 / 片头 / 缓冲 / 播完自动下一集 */
    private void onKernelState(int state) {
        if (!kernelReady()) return;
        if (state == Player.STATE_READY) {
            showLoading(false, "");
            if (phoneOsd && phoneRetry != null) phoneRetry.setVisibility(View.GONE);
            if (!introDone) {
                introDone = true;
                long d = kDur();
                long seek = 0;
                if (pendingSeekMs > 5000) {
                    seek = pendingSeekMs;
                } else if (skipIntro > 0 && d != C.TIME_UNSET && d > (skipIntro + 15) * 1000L) {
                    seek = skipIntro * 1000L;
                }
                if (seek > 0 && d != C.TIME_UNSET && seek < d - 1000) {
                    kSeek(seek);
                    hint(pendingSeekMs > 5000 ? "已续播上次进度" : "已跳过片头 " + skipIntro + " 秒");
                }
                pendingSeekMs = 0;
            }
        } else if (state == Player.STATE_BUFFERING) {
            showLoading(true, "缓冲中…");
        } else if (state == Player.STATE_ENDED) {
            if (currentIndex < episodes.length - 1) {
                hint("播放结束，自动下一集");
                playEpisode(currentIndex + 1, 0);
            } else {
                showLoading(true, "全剧播放完毕，按返回键退出");
            }
        }
    }

    @Override
    public void onPlayerError(PlaybackException error) {
        if (ijkActive) return;          // IJK 错误走 IjkKernel.Callback.onError
        int code = error.errorCode;
        // 4001 解码器初始化失败 / 4003 解码中失败 / 4004 超出设备能力 / 4005 格式不支持
        boolean decoderIssue = code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
                || code == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED
                || code == PlaybackException.ERROR_CODE_DECODING_FAILED
                || code == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
                || code == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED;

        // 「自动选择」的核心：解码类错误自动切到系统解码重建播放器重试一次，
        // 从刚才的位置续播；全程不跳出应用、不丢进度。
        // 「内置 ExoPlayer」档严格按用户选择，不自动切换。
        // 「系统解码」档本身已开回退，仍允许再兜底重建一次。
        if (decoderIssue && !decoderRetryDone && !"exo".equals(decodeMode)
                && !isFinishing()) {
            decoderRetryDone = true;
            long pos = 0;
            try {
                if (kernelReady()) pos = kPos();
            } catch (Exception ignored) {
            }
            final long resume = pos;
            boolean autoSwitch = !"sysdec".equals(decodeMode);
            showLoading(true, autoSwitch
                    ? "解码失败，自动选择正在切换系统解码…"
                    : "解码失败，正在用系统解码器重试…");
            hint(autoSwitch ? "自动选择：已切换到系统解码" : "系统解码重试中");
            handler.postDelayed(new Runnable() {
                @Override public void run() { rebuildWithSystemDecoder(resume); }
            }, 400);
            return;
        }

        errorOccurred = true;
        String name = error.getErrorCodeName();
        if (phoneOsd) {
            if (phoneRetry != null) phoneRetry.setVisibility(View.VISIBLE);
            showLoading(true, "无法播放（" + name + "）\n点下方「重试播放」或返回换片源");
            hint("播放失败，请换一个片源或在后台切换播放引擎");
            return;   // 手机端不自动退出，留给用户触屏选择
        }
        showLoading(true, "无法播放（" + name + "）\n即将返回选集");
        hint("播放失败，请换一个片源或在后台切换播放引擎");
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finishWith(true, false);
            }
        }, 1800);
    }

    /** 释放旧播放器，按「系统解码 + 解码器回退」重建，并从指定进度续播 */
    private void rebuildWithSystemDecoder(long resumeMs) {
        if (isFinishing()) return;
        if (ijk != null) {
            try { ijk.release(); } catch (Throwable ignored) {}
            ijk = null;
        }
        ijkActive = false;
        try { releaseExoPlayer(); } catch (Exception ignored) {}
        buildPlayer(true);
        errorOccurred = false;          // 重试成功中，避免退出时误报失败
        hint("sysdec".equals(decodeMode) ? "系统解码已重建" : "自动选择：已切换到系统解码");
        playEpisode(currentIndex, resumeMs);
    }

    @Override
    public void onVideoSizeChanged(VideoSize videoSize) {
        if (videoSize.width <= 0 || videoSize.height <= 0) return;
        onKernelVideoSize(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio);
    }

    /** IJK 回调给的是 w/h/sar，换算成与 ExoPlayer 一致的宽高比 */
    private void onKernelVideoSize(int w, int h, float pixelRatio) {
        if (w <= 0 || h <= 0) return;
        float ratio = (float) w / h * (pixelRatio > 0 ? pixelRatio : 1f);
        if (ratio <= 0) return;
        pendingRatio = ratio;
        applyVideoRatio(ratio);
    }

    /**
     * 按当前画面比例档位摆放 SurfaceView。
     *
     * 说明：SurfaceView 不支持非等比拉伸（MediaCodec 只有「适配」和「裁剪铺满」两种缩放）。
     * 三档：自适应（片源比例接近屏幕时铺满，差得多则完整显示留黑边）、
     * 原始比例（恒按片源比例完整显示）、全屏显示（恒保持比例裁剪铺满）。画面始终不变形。
     */
    private void applyVideoRatio(float ratio) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int W = dm.widthPixels, H = dm.heightPixels;
        if (W <= 0 || H <= 0) return;

        float screenRatio = (float) W / H;
        boolean cropping = Ui.aspectCrop(aspectMode, ratio, screenRatio);
        float frameRatio = cropping ? screenRatio : ratio;

        int vw, vh;
        if (screenRatio > frameRatio) {
            vh = H;
            vw = Math.round(H * frameRatio);
        } else {
            vw = W;
            vh = Math.round(W / frameRatio);
        }

        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) surface.getLayoutParams();
        lp.width = Math.max(1, vw);
        lp.height = Math.max(1, vh);
        lp.gravity = Gravity.CENTER;
        surface.setLayoutParams(lp);
        if (ijkActive && ijk != null) {
            ijk.setScaling(cropping);
        } else if (player != null) {
            player.setVideoScalingMode(cropping
                    ? C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    : C.VIDEO_SCALING_MODE_SCALE_TO_FIT);
        }
    }

    private static String aspectName(String mode) {
        if ("origin".equals(mode)) return "原始比例";
        if ("full".equals(mode)) return "全屏显示";
        return "自适应";
    }

    /** 切换画面比例：立即重排 SurfaceView，不重建播放器、不丢进度 */
    private void applyVodAspect(String mode, String notePrefix) {
        Store.setVodAspect(this, mode);
        aspectMode = mode;
        if (pendingRatio > 0) {
            applyVideoRatio(pendingRatio);
        } else if (ijkActive && ijk != null) {
            ijk.setScaling("full".equals(mode));
        } else if (player != null) {
            player.setVideoScalingMode("full".equals(mode)
                    ? C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    : C.VIDEO_SCALING_MODE_SCALE_TO_FIT);
        }
        hint(notePrefix == null ? "画面比例：" + aspectName(mode)
                : notePrefix + "：" + aspectName(mode));
    }

    // ---------------------------------------------------------------- 进度 / 片尾

    private void updateProgress() {
        if (!kernelReady()) return;
        long d = kDur();
        long p = kPos();
        if (d > 0 && d != C.TIME_UNSET && p >= 0) {
            if (!dragging) progress.setProgress((int) (p * 1000L / d));
            if (phoneOsd) {
                if (!dragging && tvCur != null) tvCur.setText(fmt(p));
                if (tvDur != null) tvDur.setText(fmt(d));
                if (!dragging && seekBar != null) {
                    long buf = kBuffered();
                    if (buf > 0) seekBar.setSecondaryProgress((int) (buf * 1000L / d));
                }
                if (btnPlayLabel != null) {
                    String s = kPlayWhenReady() ? "暂停" : "播放";
                    if (!s.contentEquals(btnPlayLabel.getText())) btnPlayLabel.setText(s);
                }
            } else {
                tvTime.setText(fmt(p) + " / " + fmt(d));
            }

            long outroMs = Math.min((long) skipOutro * 1000L, d / 2);
            if (outroMs > 0 && !outroDone && d - p <= outroMs && d - p > 300) {
                outroDone = true;
                if (currentIndex < episodes.length - 1) {
                    hint("已跳过片尾，继续下一集");
                    playEpisode(currentIndex + 1, 0);
                }
            }
        } else {
            if (phoneOsd) {
                if (tvCur != null) tvCur.setText(fmt(Math.max(0, p)));
                if (tvDur != null) tvDur.setText("--:--");
            } else {
                tvTime.setText(fmt(Math.max(0, p)) + " / --:--");
            }
        }
    }

    private static String fmt(long ms) {
        long s = ms / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }

    // ---------------------------------------------------------------- 选集浮层

    private boolean episodesVisible() {
        return epOverlay != null && epOverlay.getVisibility() == View.VISIBLE;
    }

    private void openEpisodes() {
        renderSrcChips();
        epOverlay.setVisibility(View.VISIBLE);
        epGrid.setSelection(currentIndex);
        epAdapter.notifyDataSetChanged();
        if (phoneOsd && phoneDrawer != null) {
            setCtlVisible(true);
            phoneDrawer.setTranslationX(phoneDrawerWidth);
            phoneDrawer.animate().translationX(0f).setDuration(220).start();
            return;   // 触屏不需要遥控器焦点
        }
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (episodesVisible()) epGrid.requestFocus();
            }
        }, 60);
    }

    private void closeEpisodes() {
        epOverlay.setVisibility(View.GONE);
        setCtlVisible(true);
    }

    // ---------------------------------------------------------------- 菜单 / 画面比例 / 解码方式

    /**
     * 播放菜单（画面比例 / 解码方式），v99：手机端与电视端统一走 LiveMenuSkin，
     * 和直播功能菜单、节目表弹窗同一套 LiveTheme 卡片 + 主题色。
     * 两条入口仍按 phoneOsd 分流保留，但视觉与可聚焦行为完全一致。
     */
    private void showVodMenu() {
        setCtlVisible(true);
        final AlertDialog[] ref = new AlertDialog[1];
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(2), 0, 0);

        final String[] labels = { "画面比例", "解码方式" };
        View first = null;
        for (int i = 0; i < labels.length; i++) {
            final int which = i;
            TextView item = new TextView(this);
            item.setText(labels[i]);
            item.setTextColor(LiveTheme.TEXT);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            item.setPadding(dp(14), dp(12), dp(14), dp(12));
            item.setFocusable(true);
            item.setClickable(true);
            item.setBackground(LiveMenuSkin.rowBg(this));
            item.setOnClickListener(v -> {
                if (ref[0] != null) ref[0].dismiss();
                if (which == 0) showAspectDialog();
                else showDecodeDialog();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(6);
            box.addView(item, lp);
            if (first == null) first = item;
        }

        View footer = LiveMenuSkin.actions(this, ref,
                new String[]{ "关闭" }, new boolean[]{ false },
                new Runnable[]{ null });
        AlertDialog d = LiveMenuSkin.show(this, "播放菜单",
                "共 2 项 · 当前主题：" + LiveMenuSkin.themeLabel(this), box, footer);
        ref[0] = d;
        trackDialog(d);
        if (first != null) first.requestFocus();
    }

    /** 手机端「菜单」按钮 / 菜单键：与电视端同一套卡片皮肤 */
    private void openPhoneMenu() {
        showVodMenu();
    }

    /** 菜单键唤出播放菜单；按返回或「关闭 ×」退出 */
    private void openMenu() {
        showVodMenu();
    }

    /** 登记模态对话框：期间把方向键 / OK / 返回交还系统，让遥控器能操作列表 */
    private void trackDialog(AlertDialog d) {
        modalDialogs++;
        d.setOnDismissListener(dlg -> {
            if (modalDialogs > 0) modalDialogs--;
            setCtlVisible(true);
        });
    }

    private interface ChoicePick {
        void pick(String value);
    }

    /**
     * 通用自绘选择对话框（画面比例 / 解码方式共用）。
     * 不用 setSingleChoiceItems —— 部分电视 ROM 在同时设置 setMessage 时会吞掉单选列表，
     * 只剩一段提示和「关闭」；这里自绘可聚焦条目：● 标当前值、蓝底高亮，OK 即确认。
     */
    private void showChoiceDialog(String title, String tipText,
                                  final String[] labels, final String[] values,
                                  String current, final ChoicePick onPick) {
        final AlertDialog[] ref = new AlertDialog[1];
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(2), 0, 0);
        box.addView(LiveMenuSkin.tip(this, tipText));

        View first = null, focus = null;
        for (int i = 0; i < labels.length; i++) {
            View item = choiceItem(labels[i], values[i].equals(current), values[i], ref, onPick);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(6);
            box.addView(item, lp);
            if (first == null) first = item;
            if (values[i].equals(current)) focus = item;
        }

        AlertDialog d = LiveMenuSkin.show(this, title,
                "● 为当前生效项 · 方向键切换，OK 确认", box, null);
        ref[0] = d;
        trackDialog(d);
        // 焦点直接落在当前生效项，OK 即确认，↑↓ 可切到别的档
        (focus != null ? focus : first).requestFocus();
    }

    /** 一条可聚焦的设置项：● 表示当前生效，方向键移焦点时蓝底高亮 */
    private View choiceItem(String label, boolean selected, final String value,
                            final AlertDialog[] ref, final ChoicePick onPick) {
        TextView t = new TextView(this);
        t.setText((selected ? "●  " : "○  ") + label);
        t.setTextSize(16);
        t.setTextColor(LiveTheme.TEXT);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setFocusable(true);
        t.setClickable(true);
        // 与直播功能菜单 / 选台抽屉同一套三档态（聚焦主题实心 + 白描边）
        t.setBackground(LiveMenuSkin.rowBg(this));
        t.setOnClickListener(v -> {
            onPick.pick(value);
            if (ref[0] != null) ref[0].dismiss();
        });
        return t;
    }

    /** 画面比例：三档（自适应排第一），与手机后台「点播画面比例」共用同一份 Store 配置 */
    private void showAspectDialog() {
        final String[] labels = {
                "自适应", "原始比例", "全屏显示"
        };
        showChoiceDialog("画面比例",
                "只影响影视点播，与 IPTV 直播分开记忆。\n"
                        + "自适应：片源比例接近屏幕时自动铺满，差得多则完整显示留黑边；\n"
                        + "原始比例：恒按片源比例完整显示（默认）；全屏显示：恒保持比例裁剪铺满。\n"
                        + "画面始终不变形；手机后台「点播画面比例」是同一份设置，两边实时同步。",
                labels, Store.VOD_ASPECT_VALUES, Store.vodAspect(this),
                value -> {
                    appliedVodAspect = value;   // 菜单已即时应用，轮询别再重复提示
                    applyVodAspect(value, null);
                });
    }

    /** 点播解码方式：与手机后台「点播播放引擎」共用同一份 Store 配置 */
    private void showDecodeDialog() {
        final String[] labels = IjkDecode.VOD_LABELS;
        final String[] values = IjkDecode.VALUES;
        showChoiceDialog("解码方式",
                "只影响影视点播，与 IPTV 直播解码分开记忆。\n"
                        + "前三档走 ExoPlayer；IJK 解码走独立 FFmpeg 软解内核，"
                        + "适合编码冷门 / 硬解花屏的片源。\n"
                        + "手机后台「点播播放引擎」是同一份设置，两边实时同步。",
                labels, values, Store.vodDecodeMode(this),
                value -> {
                    appliedVodDecodeMode = value;   // 菜单已即时应用，轮询别再重复重建
                    applyVodDecodeMode(value, null);
                });
    }

    /** 切换点播解码档位：保存配置、重建播放器、从当前进度续播（不退出、不丢进度） */
    private void applyVodDecodeMode(String mode, String notePrefix) {
        Store.setVodDecodeMode(this, mode);
        decodeMode = mode;
        decoderRetryDone = false;
        long pos = 0;
        try { if (kernelReady()) pos = kPos(); } catch (Exception ignored) {}
        if (ijk != null) {
            try { ijk.release(); } catch (Throwable ignored) {}
            ijk = null;
        }
        ijkActive = false;
        try { releaseExoPlayer(); } catch (Exception ignored) {}
        buildPlayer("sysdec".equals(mode));
        errorOccurred = false;
        String name = IjkDecode.label(mode, true);
        hint(notePrefix == null ? "解码方式：" + name : notePrefix + "：" + name);
        playEpisode(currentIndex, pos);
    }

    // ---------------------------------------------------------------- 按键

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // 菜单 / 解码方式对话框期间按键交还系统：否则方向键、OK、返回都被本页吞掉，
        // 遥控器根本选不了条目，也关不掉对话框。
        if (modalDialogs > 0) return super.onKeyDown(keyCode, event);
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
                if (episodesVisible()) {
                    closeEpisodes();
                } else {
                    finishWith(false, false);
                }
                return true;

            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (!episodesVisible()) {
                    openEpisodes();
                    return true;
                }
                return super.onKeyDown(keyCode, event); // 浮层内交给 GridView

            case KeyEvent.KEYCODE_DPAD_UP:
                if (episodesVisible()) return super.onKeyDown(keyCode, event);
                setCtlVisible(true);
                return true;

            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (episodesVisible()) return super.onKeyDown(keyCode, event);
                seekBy(-SEEK_STEP_MS);
                return true;

            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (episodesVisible()) return super.onKeyDown(keyCode, event);
                seekBy(SEEK_STEP_MS);
                return true;

            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (episodesVisible()) return super.onKeyDown(keyCode, event);
                togglePlay();
                return true;

            case KeyEvent.KEYCODE_MEDIA_REWIND:
                seekBy(-SEEK_STEP_MS);
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                seekBy(SEEK_STEP_MS);
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_PAGE_DOWN:
                if (currentIndex < episodes.length - 1) playEpisode(currentIndex + 1, 0);
                else hint("已经是最后一集");
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
            case KeyEvent.KEYCODE_PAGE_UP:
                if (currentIndex > 0) playEpisode(currentIndex - 1, 0);
                else hint("已经是第一集");
                return true;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_SETTINGS:
                if (phoneOsd) openPhoneMenu();
                else openMenu();
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    private void seekBy(long delta) {
        if (!kernelReady()) return;
        long d = kDur();
        long p = Math.max(0, kPos() + delta);
        if (d != C.TIME_UNSET && d > 0) p = Math.min(p, d - 500);
        kSeek(p);
        hint(delta > 0 ? "+15 秒" : "-15 秒");
        setCtlVisible(true);
    }

    private void togglePlay() {
        if (!kernelReady()) return;
        boolean now = !kPlayWhenReady();
        kPlay(now);
        hint(now ? "播放" : "暂停");
        setCtlVisible(true);
    }

    // ---------------------------------------------------------------- 生命周期 / 回传

    private void finishWith(boolean failed, boolean ended) {
        if (resultSent) return;
        resultSent = true;
        long pos = 0;
        try {
            if (kernelReady()) pos = kPos();
        } catch (Exception ignored) {
        }
        Intent data = new Intent();
        data.putExtra("index", currentIndex);
        data.putExtra("positionMs", pos);
        data.putExtra("failed", failed || errorOccurred);
        data.putExtra("ended", ended);
        if (nativeRec != null) {
            // 不依赖首页 WebView / forResult 接收方，自己把进度写进共享观看记录
            TvServer.savePushedProgress(getApplicationContext(), nativeRec, currentIndex, pos);
            data.putExtra("native", true);
        }
        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshVodAccent();
        if (pendingRatio > 0) applyVideoRatio(pendingRatio);
        if (!errorOccurred) kPlay(true);
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        kPlay(false);
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onDestroy() {
        PlaySession.detach(this);
        handler.removeCallbacksAndMessages(null);
        if (!resultSent && kernelReady()) {
            // 被系统回收时也要回传，避免前端一直等结果
            Intent data = new Intent();
            data.putExtra("index", currentIndex);
            data.putExtra("positionMs", 0L);
            data.putExtra("failed", errorOccurred);
            data.putExtra("ended", false);
            if (nativeRec != null) {
                TvServer.savePushedProgress(getApplicationContext(), nativeRec, currentIndex, 0L);
                data.putExtra("native", true);
            }
            setResult(RESULT_OK, data);
            resultSent = true;
        }
        if (ijk != null) {
            try { ijk.release(); } catch (Throwable ignored) {}
            ijk = null;
        }
        ijkActive = false;
        if (player != null) {
            player.removeListener(this);
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
