package com.ilatv.tv;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

/**
 * 直播界面统一视觉（v96）：选台抽屉、菜单键节目表弹窗、OSD / 加载提示共用这一套色板，
 * 保证「抽屉里按菜单键弹出节目表」时两者像同一个界面，而不是两代皮肤拼在一起。
 *
 * <p>色值来自已确认过的节目表预览图：深蓝灰卡片底、低对比描边、主题色只用于
 * 选中态 / 当前态 / 进度，文字三级（主 / 次 / 脚注）。5 套主题色与网页后台
 * config.json 的 theme 字段一一对应，切主题两端同时变色。
 *
 * <p>v100：色板改为直播 + 点播共用，主题色统一由 {@link AppTheme} 提供；
 * 点播 OSD / 选集抽屉也引用这里的 CARD / ROW / LINE / TEXT，换主题两端一起变。
 */
public final class LiveTheme {

    private LiveTheme() {}

    // ---- 基础色板（与 EpgPanel 完全一致）----
    public static final int CARD = 0xFF141A25;        // 卡片 / 面板底
    public static final int ROW = 0xFF1A2130;         // 列表行 / 未选中按钮
    public static final int LINE = 0xFF2A3448;        // 分隔线 / 描边
    public static final int TEXT = 0xFFE8ECF4;
    public static final int SUB = 0xFF8B96A9;
    public static final int FOOT = 0xFF6B7688;

    /** 抽屉底：比弹窗略透，右侧还能看到视频 */
    public static final int PANEL = 0xF2141A25;
    /** 弹窗遮罩 */
    public static final int SHADE = 0xB3060A12;
    /** 抽屉内行的半透明底，避免整块死黑 */
    public static final int ROW_SOFT = 0xB31A2130;

    public static final int STAR_ON = 0xFFFFD54F;
    public static final int STAR_OFF = 0xFF6B7688;

    // ---- 圆角（dp）----
    public static final int R_CARD = 14;
    public static final int R_ROW = 10;
    public static final int R_PILL = 999;

    /** 主题色统一走 AppTheme，直播 / 点播不再各存一份 if-else */
    public static int accent(Context c) {
        return AppTheme.accent(c);
    }

    /** base 上叠一层 over，用于「选中但列未聚焦」的暗底、当前节目的高亮底 */
    public static int blend(int base, int over, float f) {
        int r = (int) (Color.red(base) * (1 - f) + Color.red(over) * f);
        int g = (int) (Color.green(base) * (1 - f) + Color.green(over) * f);
        int b = (int) (Color.blue(base) * (1 - f) + Color.blue(over) * f);
        return Color.rgb(r, g, b);
    }

    public static GradientDrawable card(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable stroke(Context c, int color, int radiusDp,
                                          int strokeDp, int strokeColor) {
        GradientDrawable g = card(c, color, radiusDp);
        g.setStroke(Math.max(1, Ui.dp(c, strokeDp)), strokeColor);
        return g;
    }

    /**
     * 列表行 / 按钮的选中态三档：
     * ① 选中且本列聚焦 → 主题色实心 + 白描边（和节目表「今天」按钮一致）
     * ② 选中但焦点在另一列 → 主题色暗混底 + 主题色描边（仍能看见）
     * ③ 未选中 → 行底色 + 低对比描边
     */
    public static GradientDrawable rowBg(Context c, int accent,
                                         boolean selected, boolean focused) {
        if (selected && focused) return stroke(c, accent, R_ROW, 2, 0xFFFFFFFF);
        if (selected) return stroke(c, blend(ROW, accent, 0.20f), R_ROW, 1,
                blend(LINE, accent, 0.55f));
        return stroke(c, ROW_SOFT, R_ROW, 1, 0x332A3448);
    }
}
