package com.ilatv.tv;

/**
 * 选台抽屉「按台名实际长度拉长」的纯计算，不依赖 Android，便于 JVM 单测。
 *
 * 旧实现把抽屉写死在约 42% 屏宽，频道行的台名用 weight=1 吃满剩余空间，
 * 于是稍长的台名一律被 ellipsize 截成「CGT…」「发现…」。
 * 这版用与台名同字号的 Paint 量出当前分组内最长名字，加回行内固定件，
 * 在 [原宽度, 上限] 内把面板拉长；上限保证右侧始终留得出视频画面。
 */
public final class LivePanelWidth {

    private LivePanelWidth() {}

    /**
     * 频道行 + 列表 + 面板的固定占位（dp，未乘 density / 缩放）：
     * 竖条 3、编号 38、编号右距 6、台标 38、台标右距 6、
     * 台名左 9 右 4、收藏 30、行左右各 6、
     * 频道列左 6 右 26（右侧让给「节目单」竖排入口）、分隔 1、
     * 面板左右各 12，再加 8 呼吸余量。
     */
    public static final int FIXED_DP =
            3 + 38 + 6 + 38 + 6 + 9 + 4 + 30 + 6 + 6 + 6 + 26 + 1 + 12 + 12 + 8;

    /** 右侧最少保留画面（dp，会随界面缩放） */
    public static final int MIN_SIDE_DP = 64;

    /** 抽屉最大占屏比：超过它不再拉长，留给视频画面 */
    public static final float MAX_RATIO = 0.62f;

    /**
     * @param maxNamePx 当前分组最长台名的测量宽度（px，已含实际字号）
     * @param groupW    一级目录实际宽度（px，adjustGroupWidth 算好的值）
     * @param baseW     原 panelW，作为拉长下限（px）
     * @param screenW   屏宽（px）
     * @param density   DisplayMetrics.density
     * @param scale     界面缩放系数 s（Store.liveUiScale / 100）
     */
    public static int compute(float maxNamePx, int groupW, int baseW, int screenW,
                              float density, float scale) {
        return compute(maxNamePx, groupW, baseW, screenW, density, scale,
                MIN_SIDE_DP, MAX_RATIO);
    }

    public static int compute(float maxNamePx, int groupW, int baseW, int screenW,
                              float density, float scale, int minSideDp, float maxRatio) {
        if (baseW <= 0 || screenW <= 0) return Math.max(1, baseW);
        float fixed = FIXED_DP * density * scale;
        // 向上取整：保证「算出的宽度 ≥ 实际所需」，否则 0.x px 的截断余量会让
        // willEllipsize 把刚好放得下的台名误判成需要省略。
        int needed = (int) Math.ceil(fixed + Math.max(0, maxNamePx) + Math.max(0, groupW));
        int minSide = Math.max(1, (int) (minSideDp * density * scale + 0.5f));
        int maxPanel = Math.max(baseW,
                Math.min(screenW - minSide, (int) (screenW * maxRatio)));
        // 只拉长、不缩窄：短台名分组仍保持原来的 42% 屏宽，不会忽宽忽窄
        return Math.max(baseW, Math.min(maxPanel, needed));
    }

    /** 抽屉已到上限仍放不下时，台名才会走 ellipsize 兜底 */
    public static boolean willEllipsize(int panelW, float maxNamePx, int groupW,
                                        float density, float scale) {
        float fixed = FIXED_DP * density * scale;
        return fixed + Math.max(0, maxNamePx) + Math.max(0, groupW) > panelW + 0.5f;
    }
}
