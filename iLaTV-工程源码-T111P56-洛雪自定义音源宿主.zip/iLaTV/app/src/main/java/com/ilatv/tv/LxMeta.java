package com.ilatv.tv;

/**
 * 洛雪（LX Music）自定义源脚本的头部元数据解析与合法性校验（v111）。
 *
 * <p>刻意写成<b>纯 Java、零 Android / 零 org.json 依赖</b>，这样同一份逻辑可以直接
 * 跑桌面 JVM 单测，不需要 android.jar 的 stub。持久化 / 事件桥由 LxStore、
 * LxSourceHost 负责，这里只做「这段文本像不像一个自定义音源」的判断。
 *
 * <p>官方脚本头部形如：
 * <pre>
 * /&#42;!
 *  * @name        六音音源
 *  * @version     1.0.7
 *  * @description 支持酷我/酷狗/QQ/网易云
 *  * @author      xxx
 *  * @homepage    https://xxx
 *  *&#47;
 * </pre>
 * 之后通过 globalThis.lx 的 on / send / request 与宿主通信。
 */
public final class LxMeta {

    private LxMeta() {}

    /** 单个脚本上限 256 KB：音源脚本是文本，超大半是误粘贴了列表或二进制 */
    public static final int MAX_SCRIPT_BYTES = 256 * 1024;
    /** 最多同时保留 8 个源，防止 SharedPreferences 被脚本撑大 */
    public static final int MAX_SOURCES = 8;

    public static final class Info {
        public final String name;
        public final String version;
        public final String description;
        public final String author;
        public final String homepage;

        Info(String name, String version, String description, String author, String homepage) {
            this.name = name;
            this.version = version;
            this.description = description;
            this.author = author;
            this.homepage = homepage;
        }
    }

    /**
     * 解析脚本头。取不到 @name 时回落到「未命名音源」，不因此判为非法——
     * 不少社区源把名字写在注释正文里。真正决定可用的是 looksLikeSource()。
     */
    public static Info parse(String script) {
        String head = head(script);
        return new Info(
                field(head, "name", "未命名音源"),
                field(head, "version", "1.0.0"),
                field(head, "description", ""),
                field(head, "author", ""),
                field(head, "homepage", ""));
    }

    private static String head(String script) {
        if (script == null) return "";
        int end = script.indexOf("*/");
        String h = end > 0 ? script.substring(0, end) : script;
        if (h.length() > 4096) h = h.substring(0, 4096);
        return h;
    }

    /** 匹配 @key 后面同一行的内容，自动裁掉行首 * 和尾部的注释符号/空白。 */
    private static String field(String head, String key, String def) {
        if (head == null || head.isEmpty()) return def;
        String low = head.toLowerCase();
        String tag = "@" + key;
        int p = low.indexOf(tag);
        if (p < 0) return def;
        int lineEnd = head.indexOf('\n', p);
        if (lineEnd < 0) lineEnd = head.length();
        String v = head.substring(p + tag.length(), lineEnd).trim();
        // 单行头注释里可能紧跟下一个 @tag，先截断
        int at = v.indexOf('@');
        if (at >= 0) v = v.substring(0, at).trim();
        // 只裁两端残留的注释符号：不能全局替换 "/"，否则 @homepage 的 URL 会被打散
        while (v.startsWith("*")) v = v.substring(1).trim();
        if (v.endsWith("*/")) v = v.substring(0, v.length() - 2).trim();
        v = v.trim();
        if (v.isEmpty()) return def;
        if (v.length() > 120) v = v.substring(0, 120);
        return v;
    }

    /**
     * 是否像一份洛雪自定义源脚本。至少出现一种 lx 运行时用法，
     * 否则把 m3u / 普通 JSON / 误粘贴的网页当音源存进去，后面只会得到一个空宿主。
     */
    public static boolean looksLikeSource(String script) {
        if (script == null) return false;
        String s = script;
        return s.contains("globalThis.lx") || s.contains("window.lx")
                || s.contains("EVENT_NAMES") || s.contains("lx.send")
                || s.contains("lx.on(") || s.contains("lx.request");
    }

    /**
     * UTF-8 字节数估算（不依赖平台默认编码，纯 Java，桌面 JVM 单测可直接跑）。
     * 中文音源一个 char 占 3 字节，只按 script.length() 判断会把实际 700 KB+
     * 的脚本放进 SharedPreferences，所以这里按真实编码宽度算。
     */
    public static int utf8Bytes(String s) {
        if (s == null) return 0;
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 0x80) n += 1;
            else if (c < 0x800) n += 2;
            else if (Character.isHighSurrogate(c) && i + 1 < s.length()
                    && Character.isLowSurrogate(s.charAt(i + 1))) {
                n += 4;
                i++;
            } else n += 3;
        }
        return n;
    }

    /** 校验失败时给用户的可读原因；通过返回 null。 */
    public static String rejectReason(String script) {
        if (script == null || script.trim().isEmpty()) return "脚本内容为空";
        if (utf8Bytes(script) > MAX_SCRIPT_BYTES)
            return "脚本超过 256 KB，可能不是音源代码";
        if (!looksLikeSource(script))
            return "没检测到 globalThis.lx / EVENT_NAMES / lx.on 等音源接口，不是洛雪自定义源脚本";
        return null;
    }

    /**
     * 稳定 id：name + version 的 32 位 FNV-1a，转 8 位十六进制。
     * 同名同版本重复导入会命中同一 id（去重）；改版本号即视为新源，不覆盖旧的。
     */
    public static String id(String name, String version) {
        String s = (name == null ? "" : name) + "|" + (version == null ? "" : version);
        long h = 0x811c9dc5L;
        for (int i = 0; i < s.length(); i++) {
            h ^= s.charAt(i) & 0xFF;
            h *= 0x01000193L;
        }
        String hex = Long.toHexString(h & 0xFFFFFFFFL);
        while (hex.length() < 8) hex = "0" + hex;
        return "lx_" + hex;
    }
}
