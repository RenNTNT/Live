package com.ilatv.tv;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 直播「直连」链路的请求特征决策（纯逻辑，无 Android 依赖，便于 JVM 单测）。
 *
 * 背景：带策略的 CDN 会按请求特征放行。对照可正常播放的 AutoIPTV 工程，它用
 * DefaultHttpDataSource.Factory 且【不调用 setUserAgent、不伪造 Referer】，
 * 只有订阅显式写了 #EXTVLCOPT 请求头时才 setDefaultRequestProperties。
 * 我们旧版直连固定带 "...Chrome/120 Mobile ... LibreTV-Java/1.0"，属于额外特征，
 * 命中不了白名单就会拿到 403 拦截页，被播放器误报「不支持的媒体格式」。
 *
 * 三条边界：
 * 1) 频道没写自定义头 → 返回空 Map，播放器保持原生默认特征，绝不追加 LibreTV 字样；
 * 2) 频道写了 http-user-agent / http-referrer → 精确透传，清单与分片请求都带；
 * 3) 走 /hls 代理链路 → 返回空 Map。ua / ref 已作为 URL 参数由本机服务转发上游，
 *    直连 DataSource 不再叠加请求头，避免重复或干扰本机服务。
 */
public final class DirectProfile {

    private DirectProfile() {}

    /** 干净模式：不设置任何自定义 UA / Referer */
    public static boolean isClean(Map<String, String> headers) {
        return headers == null || headers.isEmpty();
    }

    /**
     * 直连起播时的请求头。空 Map 表示「用播放器原生默认特征」。
     * 注意 User-Agent 也走 setDefaultRequestProperties，而不是 setUserAgent：
     * 两者在 media3 / ExoPlayer 中效果一致，但前者能和 Referer 一起统一管理。
     */
    public static Map<String, String> forDirect(String ua, String referer) {
        LinkedHashMap<String, String> h = new LinkedHashMap<>();
        String u = trim(ua);
        String r = trim(referer);
        if (!u.isEmpty()) h.put("User-Agent", u);
        if (!r.isEmpty()) h.put("Referer", r);
        return h;
    }

    /** /hls 代理链路：请求头由本机服务按 URL 参数转发，DataSource 保持干净 */
    public static Map<String, String> forProxy() {
        return Collections.emptyMap();
    }

    /** 给诊断 / 单测用的可读描述，不参与实际请求 */
    public static String describe(Map<String, String> headers) {
        if (isClean(headers)) return "clean（播放器原生默认特征，无自定义 UA / Referer）";
        StringBuilder b = new StringBuilder();
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (b.length() > 0) b.append(" · ");
            b.append(e.getKey()).append('=').append(e.getValue());
        }
        return b.toString();
    }

    /** 回归断言用：任何链路都不应再出现旧版自定义 UA 后缀 */
    public static boolean hasLegacyMark(Map<String, String> headers) {
        if (headers == null) return false;
        for (Map.Entry<String, String> e : headers.entrySet()) {
            String v = e.getValue();
            if (v != null && (v.contains("LibreTV-Java") || v.contains("LibreTV-TV"))) return true;
        }
        return false;
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
