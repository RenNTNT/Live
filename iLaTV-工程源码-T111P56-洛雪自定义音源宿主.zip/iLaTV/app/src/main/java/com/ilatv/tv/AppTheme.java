package com.ilatv.tv;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;

/**
 * 全局主题唯一入口（v100）：直播界面与点播界面共用同一张色表。
 *
 * <p>此前 LiveTheme.accent()、LiveMenuSkin.themeLabel()、PlayerActivity.phoneAccent()
 * 各存了一份 5 套主题的 if-else，新增主题要改三处、容易漏掉某一端。
 * 现在 Java 侧全部收敛到这里：换主题时直播抽屉 / 节目表弹窗 / 功能菜单 /
 * 点播 OSD / 选集抽屉 / 播放菜单一起变色，都读网页后台 config.json 的 theme 字段。
 *
 * <p><b>以后新增一套主题只需三处</b>：
 * ① 在下面 THEMES 加一行（key / 中文名 / ARGB 主色）；
 * ② 网页 index.html / m.html / admin.html 的 html[data-theme="key"] CSS 规则；
 * ③ 设置页主题下拉选项。Java 侧仅此一处，不再有第二份色表。
 *
 * <p>accent() 每次调用都重新读配置、不缓存，所以每次新建的弹窗天然即时生效；
 * 常驻界面（选台抽屉 / 点播 OSD）由各自 onResume 比对后重刷，不重建 view。
 */
public final class AppTheme {

    private AppTheme() {}

    public static final String DEFAULT_KEY = "ember";
    /** 默认主题主色，供字段初值使用；新增主题不必动它 */
    public static final int DEFAULT_ACCENT = 0xFFFF5A3C;

    /** key, 中文名, 主色 ARGB（与网页 --ac 变量一一对应） */
    private static final String[][] THEMES = {
            { "ember",  "暖橙",   "FFFF5A3C" },
            { "ocean",  "海蓝",   "FF2F7DFF" },
            { "mint",   "薄荷绿", "FF0D9668" },
            { "violet", "紫罗兰", "FF7C5CFF" },
            { "rose",   "玫瑰红", "FFF0437B" },
    };

    /** 读网页后台保存的全局主题 key；文件不存在或字段异常时回落默认主题。 */
    public static String key(Context c) {
        String th = DEFAULT_KEY;
        try {
            File f = new File(c.getFilesDir(), "config.json");
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            in.close();
            if (n > 0) th = new JSONObject(new String(buf, 0, n, "UTF-8"))
                    .optString("theme", DEFAULT_KEY);
        } catch (Exception ignored) {
        }
        for (String[] t : THEMES) if (t[0].equals(th)) return th;
        return DEFAULT_KEY;   // 后台写了未知 key 时不炸，回落暖橙
    }

    public static int accent(Context c) {
        String k = key(c);
        for (String[] t : THEMES) if (t[0].equals(k))
            return (int) Long.parseLong(t[2], 16);
        return DEFAULT_ACCENT;
    }

    public static String label(Context c) {
        String k = key(c);
        for (String[] t : THEMES) if (t[0].equals(k)) return t[1];
        return "暖橙";
    }

    /** 供设置页 / 自检使用：新增主题后这里自动多一项，无需改调用方。 */
    public static String[] keys() {
        String[] out = new String[THEMES.length];
        for (int i = 0; i < THEMES.length; i++) out[i] = THEMES[i][0];
        return out;
    }

    public static int count() { return THEMES.length; }
}
