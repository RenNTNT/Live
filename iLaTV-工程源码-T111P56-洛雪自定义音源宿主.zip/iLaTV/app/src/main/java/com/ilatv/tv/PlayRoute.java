package com.ilatv.tv;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 直播起播链路的「进程级账本」——只记结论，不记内容。
 *
 * 背景：带策略的 CDN 对直连（LibreTV-Java UA / 无 Referer）时放时拒，
 * 每次换台回来都要重新「直连失败 → 等 Progressive 回退 → 才换代理」抖一轮。
 * 一旦某台某线路验证过「代理播通了」，本进程内下次起播直接走代理。
 *
 * 三条边界：
 * 1) 纯内存静态表，进程被杀 / 重启 / 重装即清空，不落盘、不写 SharedPreferences；
 * 2) 只写「代理可播」这一种结论；direct 是「无记录」默认值，不单独记账；
 * 3) 代理连续失败 2 次自动销账回落 direct，避免换 WiFi / CDN 策略变化后一直卡在代理。
 *    阈值 2 而非 1，用于滤掉本机服务瞬时抖动；1 次就销会退化成每次重新探测。
 *
 * key 用「频道名 + 线路序号」，不用 URL 文本：带时效签名的源每次刷新 URL 会变，
 * 用文本做 key 会让账立刻失效。
 *
 * 无 Android 依赖，便于 JVM 单测覆盖全部矩阵。
 */
public final class PlayRoute {

    private PlayRoute() {}

    /** 已验证「代理可播」的频道+线路 */
    private static final Set<String> PROXY_OK = ConcurrentHashMap.newKeySet();
    /** 有账之后的连续代理失败次数，达到阈值即销账 */
    private static final Map<String, Integer> PROXY_FAILS = new ConcurrentHashMap<>();
    /** 销账阈值 */
    private static final int FAIL_LIMIT = 2;

    public static String key(String channelName, int lineIndex) {
        return (channelName == null ? "" : channelName) + "\u0000" + lineIndex;
    }

    /** 起播第一步读账：true = 直接走代理，false = 按原方式直连 */
    public static boolean preferProxy(String key) {
        return key != null && PROXY_OK.contains(key);
    }

    /** 起播动作，供决策层复用（语义比布尔更清楚） */
    public static String startMode(String key) {
        return preferProxy(key) ? "proxy" : "direct";
    }

    /**
     * 代理链路真正 STATE_READY 才调用。直连播通不写账 —— 保持默认 direct，
     * 不把「这次恰好直连能播」固化下来。
     */
    public static void markProxyOk(String key) {
        if (key == null) return;
        PROXY_OK.add(key);
        PROXY_FAILS.remove(key);
    }

    /**
     * 代理链路失败时调用。仅当该 key 有账才可能销账；无账（本来就在探测直连）
     * 直接返回 false，不产生任何副作用。
     *
     * @return true 表示这次已销账，调用方下次应从直连重新探测
     */
    public static boolean noteProxyFail(String key) {
        if (key == null || !PROXY_OK.contains(key)) return false;
        int n;
        synchronized (PROXY_FAILS) {
            Integer cur = PROXY_FAILS.get(key);
            n = (cur == null ? 0 : cur) + 1;
            if (n >= FAIL_LIMIT) {
                PROXY_OK.remove(key);
                PROXY_FAILS.remove(key);
                return true;
            }
            PROXY_FAILS.put(key, n);
        }
        return false;
    }

    /** 仅供测试与进程内自检：当前账本大小 */
    public static int size() {
        return PROXY_OK.size();
    }

    /** 仅供测试：清空（生产代码不会调用，进程重启天然清空） */
    public static void clearForTest() {
        PROXY_OK.clear();
        PROXY_FAILS.clear();
    }
}
