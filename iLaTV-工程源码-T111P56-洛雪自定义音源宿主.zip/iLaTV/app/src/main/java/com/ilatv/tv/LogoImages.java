package com.ilatv.tv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.view.View;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 台标图片加载（v78）：列表行 / OSD 共用，带内存缓存、失败名单与列表复用保护。
 * 任一环节失败都只是「不显示台标」，绝不留下破图标或占位空框。
 */
public final class LogoImages {

    private static final int MAX_PX = 128;
    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>(4 * 1024 * 1024) {
                @Override protected int sizeOf(String k, Bitmap v) { return v.getByteCount(); }
            };
    private static final Set<String> FAILED =
            Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "ilatv-logo-img");
        t.setDaemon(true);
        return t;
    });

    private LogoImages() {}

    /** 绑定一个 ImageView；url 为空 / 关闭台标 / 加载失败时自动隐藏。 */
    public static void bind(ImageView v, String url) {
        if (v == null) return;
        final String key = url == null ? "" : url;
        v.setTag(key);
        v.setImageBitmap(null);
        v.setVisibility(View.GONE);
        if (!LogoStore.isEnabled() || key.isEmpty() || FAILED.contains(key)) return;

        Bitmap cached = CACHE.get(key);
        if (cached != null) {
            v.setImageBitmap(cached);
            v.setVisibility(View.VISIBLE);
            return;
        }
        POOL.execute(() -> {
            Bitmap b = load(key);
            if (b != null) CACHE.put(key, b); else FAILED.add(key);
            v.post(() -> {
                // ListView/Adapter 复用：只认最后一次绑定的 url
                if (!key.equals(v.getTag()) || !LogoStore.isEnabled()) return;
                if (b != null) {
                    v.setImageBitmap(b);
                    v.setVisibility(View.VISIBLE);
                } else {
                    v.setImageBitmap(null);
                    v.setVisibility(View.GONE);
                }
            });
        });
    }

    private static Bitmap load(String rawUrl) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(rawUrl);
            // 台标文件名含中文，new URL() 不会编码，五参 URI 会把 path 里的非 ASCII 转成 %XX
            String encoded = new URI(u.getProtocol(), u.getAuthority(),
                    u.getPath(), u.getQuery(), null).toASCIIString();
            conn = (HttpURLConnection) new URL(encoded).openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(8000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 iLaTV/2.0");
            conn.setRequestProperty("Accept", "image/*,*/*");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) return null;
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 1024 * 1024) return null;   // 异常大图直接放弃
                bos.write(buf, 0, n);
            }
            in.close();
            byte[] data = bos.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            int sample = 1;
            while (o.outWidth / sample > MAX_PX || o.outHeight / sample > MAX_PX * 2) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** 台标源换了 / 开关重开时清失败名单，让图片可以重新尝试。 */
    public static void resetFailures() {
        FAILED.clear();
        CACHE.evictAll();
    }
}
