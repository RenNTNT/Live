package com.ilatv.tv;

/**
 * 解码档位表（v110），纯计算、不依赖 Android，便于 JVM 单测。
 *
 * v109 及之前只有三档：auto / exo / sysdec，底层都是 ExoPlayer，
 * 区别只在于「遇到解码错误要不要启用 MediaCodec 解码器回退」。
 * v110 增加第四档 ijk（IJK / FFmpeg 软解内核），由 IjkKernel 反射桥接
 * tv.danmaku.ijk.media.player.IjkMediaPlayer：工程里不 import 任何 IJK 类，
 * 真机放入 ijkplayer-java AAR 与对应 abi 的 .so 后自动生效。
 *
 * 点播与直播共用这一张表，但各自的 Store key 仍然分开记忆（不串档）。
 * 没有 IJK 运行库时不允许「选了却黑屏」：effective() 会回落到 sysdec，
 * 并给出可读提示，用户不换档也能正常播。
 */
public final class IjkDecode {

    private IjkDecode() {}

    public static final String AUTO = "auto";
    public static final String EXO = "exo";
    public static final String SYSDEC = "sysdec";
    public static final String IJK = "ijk";

    /** 下拉与菜单顺序：前三档保持原位，新档追加在最后，老配置不串位 */
    public static final String[] VALUES = { AUTO, EXO, SYSDEC, IJK };

    /** 点播播放引擎下拉标签 */
    public static final String[] VOD_LABELS = {
            "自动选择（推荐）", "内置 ExoPlayer", "系统解码（MediaCodec 兼容优先）",
            "IJK 解码（FFmpeg 软解兼容）"
    };

    /** 直播解码菜单标签 */
    public static final String[] LIVE_LABELS = {
            "自动选择（推荐）", "内置解码", "系统解码（MediaCodec 兼容优先）",
            "IJK 解码（FFmpeg 软解兼容）"
    };

    /** 只接受四档；旧版 system / web / 未知值一律回落 auto */
    public static String normalize(String mode) {
        if (mode == null) return AUTO;
        for (String v : VALUES) if (v.equals(mode)) return v;
        return AUTO;
    }

    public static boolean isIjk(String mode) {
        return IJK.equals(normalize(mode));
    }

    /** 短标签，用于 OSD / Toast / 轮询同步提示 */
    public static String label(String mode, boolean vod) {
        String m = normalize(mode);
        if (EXO.equals(m)) return vod ? "内置 ExoPlayer" : "内置解码";
        if (SYSDEC.equals(m)) return "系统解码";
        if (IJK.equals(m)) return "IJK 解码";
        return "自动选择";
    }

    /**
     * 真正交给播放内核的档位。
     * 选了 IJK 但设备里没有 ijkplayer 运行库 → 回落到 sysdec（MediaCodec + 软解兜底），
     * 保证「选了也能播」，而不是黑屏或报错退出。
     */
    public static String effective(String mode, boolean ijkAvailable) {
        return isIjk(mode) && !ijkAvailable ? SYSDEC : normalize(mode);
    }

    /** 回落时给界面的一行说明；正常情况返回 null（不打扰） */
    public static String notice(String mode, boolean ijkAvailable) {
        return isIjk(mode) && !ijkAvailable
                ? "未检测到 IJK 内核，已回退系统解码" : null;
    }

    /** 网页后台 / 播放器轮询回显：四档都要认，不能把 ijk 冲成 auto */
    public static boolean isKnown(String mode) {
        if (mode == null) return false;
        for (String v : VALUES) if (v.equals(mode)) return true;
        return false;
    }

    /** 配置归一化用的枚举白名单（ConfigGuard / TvServer 共用） */
    public static String[] allowed() {
        return VALUES.clone();
    }
}
