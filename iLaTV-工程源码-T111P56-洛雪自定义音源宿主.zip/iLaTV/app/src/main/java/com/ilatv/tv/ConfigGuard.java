package com.ilatv.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * 配置自愈（v107）：外部写入（手机后台全量保存、备份导入）与启动读取的统一闸门。
 *
 * 背景：手机后台「保存并同步到电视」会 POST 一整份配置，/api/backup 导入更是
 * 把 config 整体替换。任一字段类型/取值异常，都会被写进 config.json 持久化；
 * 下次冷启动 TvServer 构造或首页渲染读到这里就抛异常 → HTTP 服务起不来 →
 * WebView 连不上 127.0.0.1 → 白屏，随后自动启动页/JS 桥再把它带崩 → 闪退，
 * 且因为坏配置还在磁盘上，「每次打开都白屏闪退」。
 *
 * 三道闸：
 *  1) sanitize：所有落盘配置按白名单归一化，非法枚举/超范围数值/畸形数组一律修正
 *  2) load：文件过大或 JSON 解析失败时把坏文件隔离成 config.bad.*.json，用默认配置
 *     重建并立刻回写，不让「每次启动都读同一份坏文件」循环
 *  3) beginBoot / clearBoot：上次启动没走到 onPageFinished+5s 就崩了 → 本次进入
 *     安全模式，跳过自动启动页与节目表/台标预拉取，先让首页能起来
 */
public final class ConfigGuard {

    private ConfigGuard() {}

    /** config.json 超过 2MB 视为异常（正常配置几十 KB） */
    public static final int MAX_CONFIG_BYTES = 2 * 1024 * 1024;
    /** 单个字符串字段上限，防止把整个订阅/网页内容塞进配置 */
    public static final int MAX_TEXT = 8 * 1024;
    public static final int MAX_ARRAY_ITEMS = 512;

    private static final String PREF = "libretv_java";
    private static final String KEY_BOOT = "boot_in_progress_v107";
    private static final String KEY_SAFE = "safe_boot_v107";

    // ---------------------------------------------------------------- 纯函数（JVM 可测）

    /** 枚举白名单归一化：非法值回退默认 */
    public static String normEnum(String v, String[] allowed, String def) {
        if (v == null || allowed == null) return def;
        for (String a : allowed) if (a.equals(v)) return v;
        return def;
    }

    public static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /** 超长文本截断，null 按空串 */
    public static String safeText(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }

    /** 地址字段：只接受 http(s)，其它一律清空 */
    public static String safeUrl(String s) {
        String t = safeText(s, MAX_TEXT).trim();
        return (t.startsWith("http://") || t.startsWith("https://")) ? t : "";
    }

    /** 上次 boot 标记还在 → 说明上次没走完，本次安全模式 */
    public static boolean safeBootFromFlag(boolean bootInProgress) {
        return bootInProgress;
    }

    /** 安全模式下跳过后台预拉取（只保留必须的运行时镜像配置） */
    public static boolean skipPrefetch(boolean safeBoot) {
        return safeBoot;
    }

    /** 安全模式下跳过冷启动自动进直播/分类 */
    public static boolean skipAutoStartup(boolean safeBoot) {
        return safeBoot;
    }

    // ---------------------------------------------------------------- 启动标记

    /**
     * onCreate 开头调用：写入「启动进行中」标记，并返回上次是否没走完。
     * @return true = 上次崩在页面就绪前，本次进入安全模式
     */
    public static boolean beginBoot(Context c) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            boolean last = sp.getBoolean(KEY_BOOT, false);
            sp.edit().putBoolean(KEY_BOOT, true)
                     .putBoolean(KEY_SAFE, last).apply();
            return last;
        } catch (Exception e) {
            return false;
        }
    }

    /** 首页已就绪（onPageFinished 后延时）调用：启动完成，清标记 */
    public static void clearBoot(Context c) {
        try {
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putBoolean(KEY_BOOT, false)
                    .putBoolean(KEY_SAFE, false).apply();
        } catch (Exception ignored) {}
    }

    /** TvServer 构造时读取：本次是否安全模式 */
    public static boolean isSafeBoot(Context c) {
        try {
            return c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getBoolean(KEY_SAFE, false);
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------------------------------------------------------- 归一化

    /** org.json 的 put 声明了 checked JSONException；这里统一吞掉，归一化绝不因脏数据抛异常 */
    private static void put(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception ignored) {}
    }

    /**
     * 把一份外部配置归一化成「一定不会让启动链路抛异常」的配置。
     * 未知字段原样保留（超长字符串截断），已知字段逐项修正。
     */
    public static JSONObject sanitize(JSONObject in, String[] themes, String[] modes,
                                      String defTheme, String defMode) {
        JSONObject o = new JSONObject();
        if (in == null) return o;
        java.util.Iterator<String> it = in.keys();
        while (it.hasNext()) {
            String k = it.next();
            Object v = in.opt(k);
            if (v instanceof String) put(o, k, safeText((String) v, MAX_TEXT));
            else if (v instanceof Integer || v instanceof Long || v instanceof Double
                    || v instanceof Boolean) put(o, k, v);
            else if (v instanceof JSONArray) put(o, k, v);
            else if (v instanceof JSONObject) put(o, k, v);
            // JSONObject.NULL / 其它类型直接丢弃
        }
        // 只在字段确实存在时修正，不往配置里塞新字段，避免与 SharedPreferences 真源打架
        normIfPresent(o, "theme", themes, defTheme);
        normIfPresent(o, "mode", modes, defMode);
        normIfPresent(o, "playEngine", new String[]{"auto", "exo", "sysdec", "ijk"}, "auto");
        normIfPresent(o, "startupPage", new String[]{"home", "iptv", "category"}, "home");
        normIfPresent(o, "launcherMode", new String[]{"normal", "home"}, "normal");
        normIfPresent(o, "liveDecodeMode", new String[]{"auto", "exo", "sysdec", "ijk"}, "auto");
        normIfPresent(o, "vodDecodeMode", new String[]{"auto", "exo", "sysdec", "ijk"}, "auto");
        normIfPresent(o, "vodAspect", new String[]{"auto", "origin", "full"}, "origin");
        normIfPresent(o, "liveAspect", new String[]{"auto", "origin", "full"}, "origin");
        clampIfPresent(o, "skipIntro", 0, 3600, 0);
        clampIfPresent(o, "skipOutro", 0, 3600, 0);
        clampIfPresent(o, "liveUiScale", Store.SCALE_MIN, Store.SCALE_MAX, Store.SCALE_DEF);
        clampIfPresent(o, "epgFontScale", Store.SCALE_MIN, Store.SCALE_MAX, Store.SCALE_DEF);
        boolIfPresent(o, "filterAdult", true);
        boolIfPresent(o, "logoEnabled", false);
        boolIfPresent(o, "epgEnabled", false);
        boolIfPresent(o, "autoBoot", false);
        boolIfPresent(o, "channelReverse", false);
        urlIfPresent(o, "logoSource");
        urlIfPresent(o, "iptvUrl");
        if (o.has("sources")) put(o, "sources", sanitizeSources(o.optJSONArray("sources")));
        if (o.has("epgSources")) put(o, "epgSources", sanitizeSources(o.optJSONArray("epgSources")));
        return o;
    }

    private static void normIfPresent(JSONObject o, String k, String[] allowed, String def) {
        if (o.has(k)) put(o, k, normEnum(o.optString(k, ""), allowed, def));
    }

    private static void clampIfPresent(JSONObject o, String k, int lo, int hi, int def) {
        if (o.has(k)) put(o, k, clamp(o.optInt(k, def), lo, hi));
    }

    private static void boolIfPresent(JSONObject o, String k, boolean def) {
        if (o.has(k)) put(o, k, o.optBoolean(k, def));
    }

    private static void urlIfPresent(JSONObject o, String k) {
        if (o.has(k)) put(o, k, safeUrl(o.optString(k, "")));
    }

    /** 数组只保留结构合法的对象项；非对象项直接丢弃，绝不让 getJSONObject 抛异常 */
    public static JSONArray sanitizeSources(JSONArray arr) {
        JSONArray out = new JSONArray();
        if (arr == null) return out;
        for (int i = 0; i < arr.length() && out.length() < MAX_ARRAY_ITEMS; i++) {
            JSONObject s = arr.optJSONObject(i);
            if (s == null) continue;   // 非对象项直接丢弃，杜绝 getJSONObject 抛异常
            String url = safeText(s.optString("url", ""), MAX_TEXT).trim();
            if (s.has("url") && !url.startsWith("http://") && !url.startsWith("https://"))
                continue;              // 地址明显非法，整项丢弃
            // 原样复制所有字段（含未来新增字段），只修正 url / name 两个脏点
            JSONObject x = new JSONObject();
            java.util.Iterator<String> it = s.keys();
            while (it.hasNext()) {
                String k = it.next();
                Object v = s.opt(k);
                if (v instanceof String) put(x, k, safeText((String) v, MAX_TEXT));
                else if (v instanceof Integer || v instanceof Long || v instanceof Double
                        || v instanceof Boolean || v instanceof JSONArray || v instanceof JSONObject)
                    put(x, k, v);
            }
            if (s.has("url")) put(x, "url", safeUrl(url));
            if (s.has("name")) put(x, "name", safeText(s.optString("name", ""), 256).trim());
            out.put(x);
        }
        return out;
    }

    // ---------------------------------------------------------------- 坏文件隔离

    /**
     * 读配置：文件异常 → 隔离成 .bad 文件并返回空对象，由调用方补默认值。
     * 返回 null 表示「文件正常但解析失败已隔离」，非空为解析成功的原始对象。
     */
    public static JSONObject loadRaw(File f) {
        if (f == null || !f.exists()) return null;
        try {
            if (f.length() > MAX_CONFIG_BYTES) {
                quarantine(f);
                return null;
            }
            byte[] buf = readAll(f);
            return new JSONObject(new String(buf, "UTF-8"));
        } catch (Exception e) {
            quarantine(f);
            return null;
        }
    }

    /** 保留现场后删除原文件，避免每次启动重复读同一份坏数据 */
    public static boolean quarantine(File f) {
        try {
            File bad = new File(f.getParentFile(),
                    f.getName() + ".bad." + System.currentTimeMillis() + ".json");
            renameOrCopy(f, bad);
            return true;
        } catch (Exception e) {
            try { return f.delete(); } catch (Exception ignored) { return false; }
        }
    }

    private static void renameOrCopy(File src, File dst) throws Exception {
        if (src.renameTo(dst)) return;
        FileInputStream in = new FileInputStream(src);
        FileOutputStream out = new FileOutputStream(dst);
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
        in.close();
        out.close();
        src.delete();
    }

    private static byte[] readAll(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bos.write(b, 0, n);
        in.close();
        return bos.toByteArray();
    }
}
