package com.ilatv.tv;

/**
 * 换台 OSD 胶囊的三段内容（v106），纯计算、不依赖 Android，便于 JVM 单测。
 *
 * v105 之前：osdText 一整段 = "12  河南都市 · 线路 1/1"，台标 ImageView
 * 加在文字前面 → 视觉是「[台标] 12 河南都市」。
 * v106：编号单独成段，台标夹在编号与台名之间 → 「12 [台标] 河南都市 · 线路 1/1」，
 * 与选台抽屉「编号 → 台标 → 台名」同构。
 *
 * 纯文本提示（数字键 / 错误 / 设置）仍是一段文字：no 与 logo 均为 null，
 * 播放页据此把编号段和台标都 GONE，胶囊不会留空框或残留上一个台的图。
 */
public final class OsdParts {

    private OsdParts() {}

    public static final class Parts {
        /** 编号文字；null = 纯文本提示，不显示编号段 */
        public final String no;
        /** 台标 url；null/空 = 不显示台标 */
        public final String logo;
        /** 台名 · 线路 · 备注（或纯文本提示全文） */
        public final String text;

        private Parts(String no, String logo, String text) {
            this.no = no;
            this.logo = logo;
            this.text = text;
        }
    }

    /** 换台 / 播放状态提示：带编号、带台标 */
    public static Parts channel(int index, String name, int lineIndex,
                                int urlCount, String note, String logo) {
        String n = name == null ? "" : name;
        String nt = note == null ? "" : note;
        String text = n
                + "   ·   线路 " + (lineIndex + 1) + "/" + Math.max(1, urlCount)
                + (nt.isEmpty() ? "" : "   ·   " + nt);
        return new Parts(String.valueOf(index + 1), logo, text);
    }

    /** 纯文本提示：不带编号、不带台标 */
    public static Parts plain(String text) {
        return new Parts(null, null, text == null ? "" : text);
    }

    /** 编号段是否可见 */
    public static boolean showNo(Parts p) {
        return p != null && p.no != null && !p.no.isEmpty();
    }

    /** 台标是否尝试绑定（bind 内部仍会因空/关闭/失败自行 GONE） */
    public static String logoOrEmpty(Parts p) {
        return p == null || p.logo == null ? "" : p.logo;
    }
}
