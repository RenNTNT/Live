package com.ilatv.tv;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 直播频道列表的统一加载器（v95）。
 *
 * <p>行为：
 * <ol>
 *  <li>进入直播 / 选台页时，先把<strong>上次成功拉取并缓存的列表</strong>同步交给界面，
 *      立刻能选台、能起播，不出现空白或转圈等网络；</li>
 *  <li>后台并发拉取全部启用订阅（M3U / TXT）+ 合并本机频道；</li>
 *  <li><strong>v95 首屏流式交付</strong>：第一份订阅成功就把累计快照交给界面，
 *      新安装没缓存时也能立刻起播，不用等最慢的那份订阅超时；后续订阅陆续回来再平滑补台；</li>
 *  <li>首装的部分结果也即时写缓存，中途退出 / 被系统回收都不会丢；</li>
 *  <li>下载成功 → 用新列表替换并更新缓存；全部失败 → 沿用上次缓存，不清空；</li>
 *  <li>同一时刻只允许一个下载任务在飞：启动预热、播放页、选台页、推送合并会复用同一个
 *      任务的结果，不重复联网；</li>
 *  <li>结果不完整（有订阅超时被放弃）时给缓存签名加 {@code #partial}，
 *      下次启动仍会重新拉全，不会把残缺列表当成最终成果。</li>
 * </ol>
 */
public final class LiveLoader {

    private LiveLoader() {}

    /** 缓存新鲜度：刚预热完就进直播页，不必再联网刷一遍 */
    private static final long FRESH_CACHE_MS = 120_000L;
    /** 启动预热的有效期：超过 6 小时才在冷启动时重新拉 */
    private static final long WARMUP_TTL_MS = 6 * 3600_000L;
    private static final String PARTIAL_TAG = "#partial";

    public static class Result {
        public List<Model.Channel> channels = new ArrayList<>();
        public boolean fromNetwork;      // 本次下载成功并替换了缓存
        public boolean usedCache;        // 下载失败，结果就是上次缓存
        public boolean noSubs;           // 当前没有启用任何订阅
        public boolean subsChanged;      // 订阅配置与缓存生成时不同
        public boolean truncated;        // 有订阅超时被放弃，列表可能不完整
        public boolean freshCache;       // 刚拉过 / 刚预热完，直接复用缓存未联网
        public int okSubs;
        public int failSubs;
        public long cacheTime;
    }

    public interface Callback {
        /** 主线程同步回调：有缓存就先给界面用 */
        void onCached(List<Model.Channel> cached, long ts);

        /**
         * 流式交付：一份订阅成功就回调一次「累计去重后的完整快照」。
         * <strong>只在首装（缓存为空）时触发</strong>：已有缓存时 onCached 已经给了完整列表，
         * 再喂部分结果反而会把列表变少。默认空实现，旧调用方不用改。
         */
        default void onPartial(List<Model.Channel> snapshot, int okSubs, int failSubs) {}

        /** 主线程回调：后台下载结束后的最终结果 */
        void onResult(Result r);
    }

    // ------------------------------------------------------------------ 飞行任务合并

    private static final Object FLIGHT_LOCK = new Object();
    private static Flight sFlight;

    /** 同一时刻只允许一个下载任务在飞，后来者挂到它的回调列表里共享结果 */
    private static final class Flight {
        final List<Callback> waiters = new ArrayList<>();
        volatile List<Model.Channel> snapshot = new ArrayList<>();
        volatile boolean done;
    }

    // ------------------------------------------------------------------ 对外入口

    /** 缓存优先的异步加载。主线程调用；onCached 同步执行，onPartial / onResult 回主线程。 */
    public static void load(final Context ctx, final Callback cb) {
        load(ctx, cb, false);
    }

    /**
     * @param force 显式刷新（点「刷新频道」/ 订阅刚改过）时传 true，绕过新鲜缓存短路
     */
    public static void load(final Context ctx, final Callback cb, final boolean force) {
        // 缓存里始终保存全量频道（隐藏名单只影响「界面可见性」），
        // 因此过滤必须放在交付给 UI 的最后一刻，取消隐藏即可立刻恢复全部频道。
        final List<Model.Channel> allCached = Store.liveCache(ctx);
        final List<Model.Channel> cached = Store.filterHiddenChannels(ctx, allCached);
        final long ts = Store.liveCacheTime(ctx);
        final boolean cacheEmpty = allCached.isEmpty();
        if (cb != null && !cached.isEmpty()) cb.onCached(cached, ts);

        final String sig = Store.liveSubsSignature(ctx);
        // 刚预热完 / 刚拉过：界面已经有完整缓存，不必再让用户等一轮网络
        if (!force && !cacheEmpty && ts > 0
                && System.currentTimeMillis() - ts < FRESH_CACHE_MS
                && sig.equals(Store.liveCacheSubs(ctx))) {
            Result r = new Result();
            r.channels = cached;
            r.cacheTime = ts;
            r.subsChanged = false;
            r.freshCache = true;
            if (cb != null) cb.onResult(r);
            return;
        }

        final Handler main = new Handler(Looper.getMainLooper());
        synchronized (FLIGHT_LOCK) {
            Flight f = sFlight;
            if (f != null && !f.done) {
                // 预热或另一个页面已经在拉：直接复用，不重复发请求
                if (cb != null) f.waiters.add(cb);
                final List<Model.Channel> snap = Api.copyChannels(f.snapshot);
                if (cb != null && cacheEmpty && !snap.isEmpty()) {
                    final List<Model.Channel> filtered = Store.filterHiddenChannels(ctx, snap);
                    main.post(new Runnable() {
                        @Override public void run() { cb.onPartial(filtered, 0, 0); }
                    });
                }
                return;
            }
            f = new Flight();
            if (cb != null) f.waiters.add(cb);
            sFlight = f;
            final Flight flight = f;
            Thread t = new Thread(new Runnable() {
                @Override public void run() {
                    runFlight(ctx, allCached, sig, cacheEmpty, main, flight);
                }
            }, "ilatv-live-flight");
            t.setDaemon(true);
            t.start();
        }
    }

    /** 下载线程：流式回调 + 最终决策 + 写缓存，最后统一分发给所有等待者 */
    private static void runFlight(final Context ctx, final List<Model.Channel> cachedFull,
                                  final String sig, final boolean cacheEmpty,
                                  final Handler main, final Flight flight) {
        final List<Model.LiveSub> subs = Store.enabledLiveSubs(ctx);
        final List<Model.Channel> manual = Store.manualChannels(ctx);
        final boolean noSubs = subs.isEmpty();

        final Api.LiveLoadResult d = Api.loadAllLiveStatus(subs, manual,
                new Api.Progress() {
                    @Override public void onPartial(final List<Model.Channel> snapshot,
                                                   final int okSubs, final int failSubs) {
                        final List<Model.Channel> full = Api.copyChannels(snapshot);
                        flight.snapshot = full;
                        if (!cacheEmpty || full.isEmpty()) return;   // 有旧缓存时不要用部分结果覆盖 UI
                        // 首装：部分结果即时落盘，进程被杀 / 中途退出也不丢
                        Store.saveLiveCache(ctx, full);
                        final List<Model.Channel> filtered =
                                Store.filterHiddenChannels(ctx, full);
                        main.post(new Runnable() {
                            @Override public void run() {
                                synchronized (FLIGHT_LOCK) {
                                    if (flight.done) return;
                                    for (Callback c : flight.waiters)
                                        if (c != null) c.onPartial(filtered, okSubs, failSubs);
                                }
                            }
                        });
                    }
                });

        Result r = decideSafe(cachedFull, d.channels, d.okSubs, d.failSubs,
                noSubs, d.truncated);
        r.subsChanged = !sig.equals(Store.liveCacheSubs(ctx));
        r.truncated = d.truncated;
        finishCache(ctx, r, sig, d);

        final Result out = r;
        r.channels = Store.filterHiddenChannels(ctx, r.channels);
        main.post(new Runnable() {
            @Override public void run() {
                synchronized (FLIGHT_LOCK) {
                    for (Callback c : flight.waiters)
                        if (c != null) c.onResult(out);
                    flight.done = true;
                    if (sFlight == flight) sFlight = null;
                }
            }
        });
    }

    /** 成功才写缓存；不完整的结果打上 #partial 标记，下次仍会重新拉全 */
    private static void finishCache(Context ctx, Result r, String sig, Api.LiveLoadResult d) {
        if (!r.fromNetwork) {
            r.cacheTime = Store.liveCacheTime(ctx);
            return;
        }
        Store.saveLiveCache(ctx, r.channels);
        boolean complete = (d.failSubs == 0 && !d.truncated && !r.truncated);
        Store.saveLiveCacheSubs(ctx, complete ? sig : sig + PARTIAL_TAG);
        r.cacheTime = System.currentTimeMillis();
    }

    // ------------------------------------------------------------------ 纯决策逻辑

    /**
     * 纯决策逻辑（不依赖 Android / 网络，可单独跑 JVM 单测）：
     * 给定上次缓存与本次下载结果，决定界面最终用哪份列表。
     *
     * 成功条件 = 没有启用订阅（结果就是本机频道，合法）或至少一份订阅拉到了频道。
     * 特别注意：订阅全失败但本机频道非空时，不能把「只有 1 个本机频道」当成成功，
     * 否则会把 335 个台的缓存砍成 1 个 —— 这正是「下载失败沿用缓存」要防的情况。
     */
    public static Result decide(List<Model.Channel> cached, List<Model.Channel> fresh,
                                int okSubs, int failSubs, boolean noSubs) {
        Result r = new Result();
        r.okSubs = okSubs;
        r.failSubs = failSubs;
        r.noSubs = noSubs;
        boolean success = noSubs || okSubs > 0;
        if (success) {
            r.channels = fresh == null ? new ArrayList<>() : fresh;
            r.fromNetwork = true;
        } else if (cached != null && !cached.isEmpty()) {
            r.channels = cached;                   // 下载失败 → 沿用上次缓存
            r.usedCache = true;
        } else {
            // 从未成功下载过、且这次也失败：至少把本机频道给用户
            r.channels = fresh == null ? new ArrayList<>() : fresh;
        }
        return r;
    }

    /**
     * v95 残缺保护：启用短超时后，「只有一份快源成功、其余慢源被放弃」变得常见。
     * 这时 fresh 可能只有几十个台，直接替换就会把几百个台的旧缓存砍掉。
     * 仅当本次有订阅失败 / 被截断、且新列表不到旧缓存一半时，把旧缓存里
     * 这次没拉到的台并回来；仍标记 truncated，写 #partial 让下次继续补。
     *
     * 用户主动删订阅是合法变少：那种情况 failSubs=0 且未截断，走正常替换。
     */
    public static Result decideSafe(List<Model.Channel> cached, List<Model.Channel> fresh,
                                    int okSubs, int failSubs, boolean noSubs,
                                    boolean truncated) {
        Result r = decide(cached, fresh, okSubs, failSubs, noSubs);
        if (!r.fromNetwork || cached == null || cached.isEmpty()
                || fresh == null || fresh.isEmpty()) return r;
        if (!(truncated || failSubs > 0)) return r;
        if (fresh.size() * 2 >= cached.size()) return r;

        Set<String> names = new HashSet<>();
        for (Model.Channel c : fresh) names.add(c.name);
        List<Model.Channel> merged = Api.copyChannels(fresh);
        for (Model.Channel c : cached) {
            if (!names.contains(c.name)) {
                merged.add(c);
                names.add(c.name);
            }
        }
        r.channels = merged;
        r.truncated = true;
        return r;
    }

    /**
     * 同步执行一次「下载 → 成功替换 / 失败沿用缓存」。必须在子线程调用。
     * 供网页后台、推送后的全量合并等非 UI 场景复用（不参与飞行任务合并）。
     */
    public static Result fetch(Context ctx, List<Model.Channel> cached) {
        if (cached == null) cached = new ArrayList<>();

        final List<Model.LiveSub> subs = Store.enabledLiveSubs(ctx);
        final List<Model.Channel> manual = Store.manualChannels(ctx);
        final boolean noSubs = subs.isEmpty();
        final String sig = Store.liveSubsSignature(ctx);

        Api.LiveLoadResult d = Api.loadAllLiveStatus(subs, manual);
        Result r = decideSafe(cached, d.channels, d.okSubs, d.failSubs,
                noSubs, d.truncated);
        r.subsChanged = !sig.equals(Store.liveCacheSubs(ctx));
        r.truncated = d.truncated;
        finishCache(ctx, r, sig, d);
        return r;
    }

    // ------------------------------------------------------------------ 启动预热

    /**
     * 冷启动后台预热频道缓存。新安装第一次进直播之所以慢，就是因为它必须现场等
     * 全部订阅下载完；这里在用户还在首页时就先拉一遍，等点进直播缓存通常已就绪，
     * onCached 同步起播，几乎零等待。
     *
     * <p>条件：缓存为空 / 超过 6 小时 / 订阅签名不一致（含上次只拉到部分结果）。
     * 与页面加载共享同一个飞行任务，不会重复联网；全程后台线程，不阻塞启动。
     */
    public static void warmup(final Context ctx) {
        try {
            List<Model.Channel> cache = Store.liveCache(ctx);
            long ts = Store.liveCacheTime(ctx);
            String sig = Store.liveSubsSignature(ctx);
            if (!cache.isEmpty() && ts > 0
                    && System.currentTimeMillis() - ts < WARMUP_TTL_MS
                    && sig.equals(Store.liveCacheSubs(ctx))) return;
            load(ctx, new Callback() {
                @Override public void onCached(List<Model.Channel> c, long t) {}
                @Override public void onPartial(List<Model.Channel> s, int ok, int fail) {}
                @Override public void onResult(Result r) {}
            }, true);
        } catch (Exception ignored) {
        }
    }

    /** 供 UI 显示缓存时间的短文本 */
    public static String ageText(long ts) {
        if (ts <= 0) return "无缓存";
        long min = (System.currentTimeMillis() - ts) / 60000L;
        if (min < 1) return "刚刚";
        if (min < 60) return min + " 分钟前";
        long h = min / 60;
        if (h < 24) return h + " 小时前";
        return (h / 24) + " 天前";
    }
}
