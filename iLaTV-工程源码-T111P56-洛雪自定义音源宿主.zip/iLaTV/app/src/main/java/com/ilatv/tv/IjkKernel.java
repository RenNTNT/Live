package com.ilatv.tv;

import android.content.Context;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * IJK（ijkplayer / FFmpeg）解码内核的反射桥接层（v110）。
 *
 * 工程里【不 import 任何 ijkplayer 类】：全部通过 Class.forName + 反射 +
 * 动态代理监听器调用。这样源码工程不依赖 AAR 也能编译通过；真机只要把
 * ijkplayer-java 的 AAR 和对应 abi 的 libijkffmpeg/libijkplayer/libijksdl
 * 放进工程，这一档就自动可用。没放运行库时 IjkDecode.effective() 会
 * 回落到「系统解码」，不会黑屏也不会闪退。
 *
 * 与 ExoPlayer 平行的独立播放路径：自己解封装（FFmpeg）、自己解码
 * （默认软解优先，mediacodec=0），SurfaceView 由 SurfaceHolder 直接输出。
 * 点播 PlayerActivity 与直播 PlayerCore 共用这一份实现，行为对齐。
 */
public final class IjkKernel {

    private static final String CLS_PLAYER = "tv.danmaku.ijk.media.player.IjkMediaPlayer";
    private static final String CLS_LOADER = "tv.danmaku.ijk.media.player.IjkLibLoader";
    private static final String IFACE = "tv.danmaku.ijk.media.player.IMediaPlayer$";

    // IjkMediaPlayer.OPT_CATEGORY_* 的数值，避免直接引用第三方常量
    private static final int OPT_FORMAT = 2;
    private static final int OPT_CODEC = 1;
    private static final int OPT_PLAYER = 4;

    public interface Callback {
        void onReady();
        void onError(String message);
        /** pixelRatio = sarNum / sarDen，为 0 时按 1 处理 */
        void onVideoSize(int width, int height, float pixelRatio);
        void onEnded();
    }

    private final Context ctx;
    private SurfaceView surface;
    private final Callback cb;
    private SurfaceHolder holder;
    private Object impl;                 // IjkMediaPlayer 实例
    private boolean released = false;
    private boolean wantPlay = true;
    private long startMs = 0L;
    private float speed = 1.0f;
    private String currentUrl = "";
    private Map<String, String> headers = Collections.emptyMap();
    private boolean surfaceReady = false;
    private SurfaceHolder.Callback holderCb;

    private IjkKernel(Context ctx, SurfaceView surface, Callback cb) {
        this.ctx = ctx;
        this.surface = surface;
        this.cb = cb;
    }

    /** 运行库类是否存在（不加载 .so，快速探测） */
    public static boolean available() {
        try {
            Class.forName(CLS_PLAYER);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** 诊断用：返回 IJK 运行库版本或不可用原因 */
    public static String describe() {
        if (!available()) return "未安装 IJK 运行库（ijkplayer AAR / .so）";
        try {
            Class.forName(CLS_LOADER);   // native 装载器接口也在才算完整集成
            return "IJK 运行库已就绪（ijkplayer-java + .so）";
        } catch (Throwable ignored) {
            return "IJK 类存在，但 native 装载器不完整";
        }
    }

    /**
     * 创建内核。运行库 / native 不可用时返回 null，调用方据此回落现有解码。
     */
    public static IjkKernel create(Context ctx, SurfaceView surface, Callback cb) {
        if (ctx == null || surface == null || cb == null || !available()) return null;
        IjkKernel k = new IjkKernel(ctx, surface, cb);
        try {
            // 加载 native：没放 .so 会抛 UnsatisfiedLinkError，直接判为不可用
            Class<?> c = Class.forName(CLS_PLAYER);
            Class<?> loader = Class.forName(CLS_LOADER);
            c.getMethod("loadLibrariesOnce", loader).invoke(null, new Object[]{null});
            k.holder = surface.getHolder();
            if (k.holder != null) {
                k.surfaceReady = k.holder.getSurface() != null && k.holder.getSurface().isValid();
                k.holderCb = new SurfaceHolder.Callback() {
                    @Override public void surfaceCreated(SurfaceHolder h) {
                        k.surfaceReady = true;
                        k.bindDisplay();
                    }
                    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {}
                    @Override public void surfaceDestroyed(SurfaceHolder h) {
                        k.surfaceReady = false;
                    }
                };
                k.holder.addCallback(k.holderCb);
            }
            return k;
        } catch (Throwable ignored) {
            return null;
        }
    }

    // ---------------------------------------------------------------- 起播

    /** 打开一个地址；startMs 为续播位置，直播传 0。headers 为空时不下发自定义头。 */
    public void open(String url, long startMs, Map<String, String> requestHeaders) {
        if (released) return;
        currentUrl = url == null ? "" : url;
        this.startMs = Math.max(0L, startMs);
        this.headers = (requestHeaders == null || requestHeaders.isEmpty())
                ? Collections.emptyMap() : new LinkedHashMap<>(requestHeaders);
        if (currentUrl.isEmpty()) {
            cb.onError("地址为空");
            return;
        }
        releaseImpl();
        try {
            Class<?> c = Class.forName(CLS_PLAYER);
            impl = c.getConstructor().newInstance();
            setOption(OPT_PLAYER, "mediacodec", 0L);              // FFmpeg 软解优先
            setOption(OPT_PLAYER, "mediacodec-auto-rotate", 0L);
            setOption(OPT_PLAYER, "mediacodec-handle-resolution-change", 0L);
            setOption(OPT_PLAYER, "opensles", 0L);
            setOption(OPT_PLAYER, "framedrop", 1L);                // 弱设备丢帧保音画同步
            setOption(OPT_PLAYER, "start-on-prepared", 1L);
            setOption(OPT_FORMAT, "reconnect", 1L);                // 直播断流自动重连
            setOption(OPT_FORMAT, "timeout", 15000000L);
            setOption(OPT_FORMAT, "http-detect-range-support", 0L);
            setOption(OPT_CODEC, "skip_loop_filter", 48L);

            Method setData = c.getMethod("setDataSource", String.class, Map.class);
            setData.invoke(impl, currentUrl, headers);
            invoke("setScreenOnWhilePlaying", new Class[]{boolean.class}, true);
            bindDisplay();
            bindListeners(c);
            invoke("prepareAsync", null);
        } catch (Throwable t) {
            releaseImpl();
            cb.onError("IJK 内核起播失败：" + shortReason(t));
        }
    }

    private void setOption(int category, String name, long value) {
        if (impl == null) return;
        try {
            impl.getClass().getMethod("setOption", int.class, String.class, long.class)
                    .invoke(impl, category, name, value);
        } catch (Throwable ignored) {
        }
    }

    private void bindDisplay() {
        if (impl == null || holder == null || !surfaceReady) return;
        try {
            impl.getClass().getMethod("setDisplay", SurfaceHolder.class).invoke(impl, holder);
        } catch (Throwable ignored) {
        }
    }

    /** 用动态代理挂 ijkplayer 的监听器接口，不 import 任何第三方接口 */
    private void bindListeners(Class<?> playerCls) {
        setProxy(playerCls, "OnPreparedListener", "setOnPreparedListener", (p, m, a) -> {
            if (!"onPrepared".equals(m.getName())) return null;
            try {
                if (startMs > 0) invoke("seekTo", new Class[]{long.class}, startMs);
                invoke("start", null);
                if (speed != 1f) invoke("setSpeed", new Class[]{float.class}, speed);
                if (!wantPlay) invoke("pause", null);
            } catch (Throwable ignored) {
            }
            cb.onReady();
            return null;
        });
        setProxy(playerCls, "OnVideoSizeChangedListener", "setOnVideoSizeChangedListener",
                (p, m, a) -> {
                    if (!"onVideoSizeChanged".equals(m.getName()) || a == null || a.length < 5) return null;
                    int w = asInt(a[1]), h = asInt(a[2]);
                    int sarNum = asInt(a[3]), sarDen = asInt(a[4]);
                    float ratio = (sarNum > 0 && sarDen > 0) ? (float) sarNum / sarDen : 1f;
                    if (w > 0 && h > 0) cb.onVideoSize(w, h, ratio);
                    return null;
                });
        setProxy(playerCls, "OnCompletionListener", "setOnCompletionListener", (p, m, a) -> {
            if ("onCompletion".equals(m.getName())) cb.onEnded();
            return null;
        });
        setProxy(playerCls, "OnErrorListener", "setOnErrorListener", (p, m, a) -> {
            if ("onError".equals(m.getName())) {
                int what = a != null && a.length > 1 ? asInt(a[1]) : 0;
                int extra = a != null && a.length > 2 ? asInt(a[2]) : 0;
                cb.onError("IJK 解码失败（" + what + "/" + extra + "），换档位或片源试试");
            }
            return true;   // 已消费，不让 ijkplayer 自己弹框
        });
        setProxy(playerCls, "OnInfoListener", "setOnInfoListener", (p, m, a) -> {
            // MEDIA_INFO_BUFFERING_START=701 / END=702 由界面自行显示 loading，
            // 这里不额外打扰；返回 true 表示已消费
            return true;
        });
    }

    private void setProxy(Class<?> playerCls, String ifaceSimple, String setter,
                          InvocationHandler h) {
        if (impl == null) return;
        try {
            Class<?> iface = Class.forName(IFACE + ifaceSimple);
            Object proxy = Proxy.newProxyInstance(iface.getClassLoader(),
                    new Class<?>[]{iface}, h);
            playerCls.getMethod(setter, iface).invoke(impl, proxy);
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- 控制（与 ExoPlayer 同语义）

    public boolean isPlaying() {
        return !released && impl != null && wantPlay && boolOf("isPlaying");
    }

    public long position() {
        return released || impl == null ? 0L : longOf("getCurrentPosition");
    }

    public long duration() {
        if (released || impl == null) return 0L;
        long d = longOf("getDuration");
        return d > 0 ? d : 0L;
    }

    public void seekTo(long ms) {
        if (released || impl == null) return;
        try { invoke("seekTo", new Class[]{long.class}, Math.max(0L, ms)); }
        catch (Throwable ignored) {}
    }

    public void play() { wantPlay = true; if (impl != null) { try { invoke("start", null); } catch (Throwable ignored) {} } }
    public void pause() { wantPlay = false; if (impl != null) { try { invoke("pause", null); } catch (Throwable ignored) {} } }
    public boolean playWhenReady() { return wantPlay; }

    public void setSpeed(float s) {
        speed = Math.max(0.25f, Math.min(s, 3.0f));
        if (impl != null) { try { invoke("setSpeed", new Class[]{float.class}, speed); } catch (Throwable ignored) {} }
    }

    public void setVolume(float v) {
        if (impl != null) {
            try { impl.getClass().getMethod("setVolume", float.class, float.class)
                    .invoke(impl, v, v); } catch (Throwable ignored) {}
        }
    }

    /** IJK 的画面比例由 SurfaceView 的 LayoutParams 控制，这里只记一个缩放意图 */
    public void setScaling(boolean crop) {
        if (impl != null) {
            try { impl.getClass().getMethod("setScreenOnWhilePlaying", boolean.class)
                    .invoke(impl, true); } catch (Throwable ignored) {}
        }
    }

    /** IJK 不暴露 Media3 的 Tracks 结构，如实说明，不伪造轨道数 */
    public String tracksInfo() {
        return released || impl == null ? "播放内核未就绪" : "IJK 解码 · 轨道由 FFmpeg 内部解析";
    }

    public void release() {
        released = true;
        releaseImpl();
        if (holder != null && holderCb != null) {
            try { holder.removeCallback(holderCb); } catch (Throwable ignored) {}
        }
        holder = null;
        holderCb = null;
        surface = null;
    }

    public boolean released() { return released; }

    public String currentUrl() { return currentUrl; }

    // ---------------------------------------------------------------- 反射小工具

    private void releaseImpl() {
        if (impl == null) return;
        try { invoke("setDisplay", new Class[]{SurfaceHolder.class}, new Object[]{null}); } catch (Throwable ignored) {}
        try { invoke("stop", null); } catch (Throwable ignored) {}
        try { invoke("release", null); } catch (Throwable ignored) {}
        impl = null;
    }

    private Object invoke(String name, Class<?>[] sig, Object... args) throws Throwable {
        if (impl == null) return null;
        Method m = sig == null
                ? impl.getClass().getMethod(name)
                : impl.getClass().getMethod(name, sig);
        return args == null || args.length == 0 ? m.invoke(impl) : m.invoke(impl, args);
    }

    private boolean boolOf(String name) {
        try { Object o = invoke(name, null); return o instanceof Boolean && (Boolean) o; }
        catch (Throwable ignored) { return false; }
    }

    private long longOf(String name) {
        try { Object o = invoke(name, null); return o instanceof Number ? ((Number) o).longValue() : 0L; }
        catch (Throwable ignored) { return 0L; }
    }

    private static int asInt(Object o) {
        return o instanceof Number ? ((Number) o).intValue() : 0;
    }

    private static String shortReason(Throwable t) {
        String s = t == null ? "" : String.valueOf(t.getMessage());
        if (s.isEmpty()) s = t == null ? "未知" : t.getClass().getSimpleName();
        return s.length() > 90 ? s.substring(0, 90) : s;
    }
}
