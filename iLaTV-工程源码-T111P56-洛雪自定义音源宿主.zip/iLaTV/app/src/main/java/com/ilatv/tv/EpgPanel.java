package com.ilatv.tv;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;

/**
 * 直播节目单弹窗（v94）：居中卡片，按确认过的预览图制作。
 *
 * <p>样式：标题「节目单 · 频道名」+「匹配: EPG_ID · 共 N 条」+ 右上角「关闭 ×」；
 * 顶部「今天 / 明天 / 后天」三档；列表每条是「起止时间 / 节目名 / 简介」，
 * 正在播出的那条用主题色描边高亮、带播放进度条；底部一行来源说明。
 *
 * <p>数据与网页 /api/epg 同源（EpgStore.programsFor），不联网、不重复解析。
 * 遥控器：←→ 切天、↑↓ 滚列表、返回 / ESC / 点关闭× / 点遮罩 关闭；
 * 弹窗显示期间所有按键都在这里吞掉，绝不会漏给播放页换台或退出。
 *
 * <p>v96：色板 / 主题色抽到 LiveTheme，与选台抽屉、OSD 共用一套，
 * 抽屉里按菜单键弹出本弹窗时两者是同一种视觉语言。
 *
 * <p>纯代码建 UI：工程没有 res/layout，也不依赖 AlertDialog 的主题（各家电视 ROM
 * 对 AlertDialog 的渲染差异很大），避免「预览好看、真机变样」。
 */
public final class EpgPanel {

    public interface Callback {
        /** 关闭后让播放页恢复选台抽屉的自动收起计时 */
        void onClosed();
    }

    // v96：色板统一抽到 LiveTheme，选台抽屉 / OSD 用同一份，避免两套皮肤漂移
    private static final int CARD = LiveTheme.CARD;
    private static final int ROW = LiveTheme.ROW;
    private static final int LINE = LiveTheme.LINE;
    private static final int TEXT = LiveTheme.TEXT;
    private static final int SUB = LiveTheme.SUB;
    private static final int FOOT = LiveTheme.FOOT;

    private static final String[] DAY_LABEL = {"今天", "明天", "后天"};
    private static final String FOOT_TEXT =
            "节目表来源可在设置页「节目表」里管理，内置源支持删除";

    private final Activity act;
    private final FrameLayout host;
    private final Callback cb;
    private final int accent;
    private final float k;          // 字体缩放（设置页「字体大小」）

    private FrameLayout overlay;
    private ScrollView scroll;
    private LinearLayout listBox;
    private TextView titleView, subView;
    private Button closeBtn;
    private final Button[] tabs = new Button[3];

    private String channel = "";
    private JSONArray data = new JSONArray();
    private int day = 0;

    public EpgPanel(Activity act, FrameLayout host, Callback cb) {
        this.act = act;
        this.host = host;
        this.cb = cb;
        this.accent = LiveTheme.accent(act);
        float s = Store.epgFontScale(act) / 100f;
        this.k = Math.max(0.5f, Math.min(2f, s));
    }

    public boolean isShowing() {
        return overlay != null && overlay.getVisibility() == View.VISIBLE;
    }

    /** 打开某个频道的节目单；同一时刻只保留一个弹窗 */
    public void show(String channelName) {
        if (isShowing()) detach();   // 同一时刻只留一个，切换频道不触发关闭回调
        channel = channelName == null ? "" : channelName;
        day = 0;
        data = EpgStore.programsFor(channel);
        build();
        render();
        host.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // 等 attach 完成再要焦点：直接 requestFocus 在部分 ROM 上会落空，
        // 那样遥控器 OK 就没有默认落点（关闭× 拿不到焦点）。
        overlay.post(new Runnable() {
            @Override public void run() { if (closeBtn != null) closeBtn.requestFocus(); }
        });
    }

    public void dismiss() {
        if (overlay == null) return;
        detach();
        if (cb != null) cb.onClosed();
    }

    private void detach() {
        if (overlay == null) return;
        try { host.removeView(overlay); } catch (Exception ignored) {}
        overlay = null;
    }

    /**
     * 弹窗期间的按键：全部自行处理并返回 true，播放页不会再收到换台 / 退出。
     * 返回 / ESC 关闭，← → 切天，↑ ↓ 滚列表，OK 命中关闭按钮或某一天。
     */
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
                dismiss();
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                switchDay(day - 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                switchDay(day + 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (scroll != null) scroll.smoothScrollBy(0, -Ui.dp(act, 96));
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (scroll != null) scroll.smoothScrollBy(0, Ui.dp(act, 96));
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (closeBtn != null && closeBtn.isFocused()) {
                    dismiss();
                } else {
                    for (int i = 0; i < tabs.length; i++) {
                        if (tabs[i] != null && tabs[i].isFocused()) { switchDay(i); break; }
                    }
                }
                return true;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_TV:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_SETTINGS:
                // 弹窗上再按菜单键不叠第二层功能菜单
                return true;
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                // 看节目单时也要能调音量，交回系统处理
                return false;
            default:
                return true;
        }
    }

    private void switchDay(int d) {
        int next = Math.max(0, Math.min(2, d));
        if (next == day) return;
        day = next;
        render();
        if (scroll != null) scroll.scrollTo(0, 0);
    }

    // ------------------------------------------------------------------ 建 UI

    private void build() {
        overlay = new FrameLayout(act);
        overlay.setBackgroundColor(0xB3060A12);
        overlay.setClickable(true);
        // 点卡片外的遮罩也能关，和网页端 epgShade 一致
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dismiss(); }
        });

        LinearLayout card = column();
        GradientDrawable cardBg = rounded(CARD, 14);
        cardBg.setStroke(Math.max(1, Ui.dp(act, 1)), LINE);
        card.setBackground(cardBg);
        int pad = Ui.dp(act, 22);
        card.setPadding(pad, pad, pad, Ui.dp(act, 14));
        card.setClickable(true);   // 吃掉点击，别让卡片内的点击穿透到遮罩

        // 顶部：标题 + 匹配信息 + 右侧「关闭 ×」
        LinearLayout head = row();
        LinearLayout headLeft = column();
        titleView = text("节目单 · " + channel, 22, TEXT, true);
        subView = text(subText(), 13, SUB, false);
        subView.setPadding(0, Ui.dp(act, 4), 0, 0);
        headLeft.addView(titleView);
        headLeft.addView(subView);

        closeBtn = new Button(act);
        closeBtn.setText("关闭 ×");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(sp(16));
        closeBtn.setAllCaps(false);
        closeBtn.setPadding(Ui.dp(act, 18), Ui.dp(act, 8), Ui.dp(act, 18), Ui.dp(act, 8));
        closeBtn.setBackground(closeBg(false));
        closeBtn.setFocusable(true);
        closeBtn.setFocusableInTouchMode(false);
        closeBtn.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) { v.setBackground(closeBg(has)); }
        });
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dismiss(); }
        });

        head.addView(headLeft, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(closeBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(head);

        // 今天 / 明天 / 后天
        LinearLayout tabRow = row();
        tabRow.setPadding(0, Ui.dp(act, 16), 0, Ui.dp(act, 12));
        for (int i = 0; i < 3; i++) {
            final int di = i;
            Button b = new Button(act);
            b.setText(DAY_LABEL[i]);
            b.setAllCaps(false);
            b.setTextSize(sp(14));
            b.setFocusable(true);
            b.setPadding(0, Ui.dp(act, 8), 0, Ui.dp(act, 8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = Ui.dp(act, 8);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { switchDay(di); }
            });
            b.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override public void onFocusChange(View v, boolean has) { paintTabs(); }
            });
            tabs[i] = b;
            tabRow.addView(b, lp);
        }
        card.addView(tabRow);

        // 节目列表
        listBox = column();
        scroll = new ScrollView(act);
        scroll.setFillViewport(true);
        scroll.addView(listBox, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView foot = text(FOOT_TEXT, 11, FOOT, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(act, 10), 0, 0);
        card.addView(foot);

        // 居中卡片：电视约 60% 宽 / 88% 高，手机窄屏放大到 92%
        int w = act.getResources().getDisplayMetrics().widthPixels;
        int h = act.getResources().getDisplayMetrics().heightPixels;
        float wr = w >= 1200 ? 0.60f : 0.92f;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                Math.round(w * wr), Math.round(h * 0.88f), Gravity.CENTER);
        overlay.addView(card, lp);
    }

    private String subText() {
        if (!EpgStore.isSwitchedOn(act)) return "节目表未开启 · 设置页「节目表」里开启";
        String id = EpgStore.match(channel);
        if (id == null || id.isEmpty() || data.length() == 0) return "未匹配 EPG · 共 0 条";
        return "匹配: " + id + " · 共 " + data.length() + " 条";
    }

    // ------------------------------------------------------------------ 渲染列表

    private void render() {
        paintTabs();
        subView.setText(subText());
        listBox.removeAllViews();

        if (!EpgStore.isSwitchedOn(act)) {
            listBox.addView(empty("节目表已在设置里关闭",
                    "请在设置页「节目表」开启后，再看节目单"));
            return;
        }
        if (data.length() == 0) {
            listBox.addView(empty("没有找到这个频道的节目表",
                    "源未加载 / 频道未匹配 / 内置源已在设置里删除"));
            return;
        }

        int count = 0;
        for (int i = 0; i < data.length(); i++) {
            JSONObject o = data.optJSONObject(i);
            if (o == null || o.optInt("day", 0) != day) continue;
            listBox.addView(programRow(o));
            count++;
        }
        if (count == 0) {
            listBox.addView(empty("这一天暂无节目",
                    "可在设置页点「重新读取节目表」刷新"));
        }
    }

    /** 三档按钮：选中用主题色实心，焦点再加一圈白描边，遥控器上一眼看得清 */
    private void paintTabs() {
        for (int i = 0; i < 3; i++) {
            boolean on = i == day;
            GradientDrawable g = rounded(on ? accent : ROW, 9);
            if (!on) g.setStroke(Math.max(1, Ui.dp(act, 1)), LINE);
            if (tabs[i] != null && tabs[i].isFocused())
                g.setStroke(Math.max(2, Ui.dp(act, 2)), 0xFFFFFFFF);
            tabs[i].setBackground(g);
            tabs[i].setTextColor(on ? Color.WHITE : SUB);
            tabs[i].setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    /** 一条节目：左起止时间、右名称 + 简介；当前节目主题色高亮 + 播放进度条 */
    private View programRow(JSONObject o) {
        final boolean now = o.optBoolean("now", false) && day == 0;
        LinearLayout item = row();
        item.setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 12), Ui.dp(act, 10));
        GradientDrawable bg = rounded(now ? blend(ROW, accent, 0.16f) : ROW, 10);
        if (now) bg.setStroke(Math.max(1, Ui.dp(act, 1)), blend(ROW, accent, 0.55f));
        item.setBackground(bg);
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        itemLp.bottomMargin = Ui.dp(act, 8);
        item.setLayoutParams(itemLp);

        if (now) {
            View bar = new View(act);
            bar.setBackgroundColor(accent);
            item.addView(bar, new LinearLayout.LayoutParams(
                    Math.max(2, Ui.dp(act, 3)), ViewGroup.LayoutParams.MATCH_PARENT));
        }

        LinearLayout times = column();
        times.addView(text(o.optString("start", ""), 13, now ? accent : SUB, false));
        TextView stop = text(o.optString("stop", ""), 13, SUB, false);
        stop.setPadding(0, Ui.dp(act, 2), 0, 0);
        times.addView(stop);
        LinearLayout.LayoutParams timeLp = new LinearLayout.LayoutParams(
                Ui.dp(act, 62), ViewGroup.LayoutParams.WRAP_CONTENT);
        timeLp.rightMargin = Ui.dp(act, 12);
        item.addView(times, timeLp);

        LinearLayout right = column();
        TextView name = text((now ? "▶ " : "") + o.optString("title", ""), 16, TEXT, true);
        name.setSingleLine(false);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        right.addView(name);
        String desc = o.optString("desc", "");
        if (!desc.isEmpty()) {
            TextView d = text(desc, 12.5f, SUB, false);
            d.setMaxLines(2);
            d.setEllipsize(android.text.TextUtils.TruncateAt.END);
            d.setPadding(0, Ui.dp(act, 4), 0, 0);
            right.addView(d);
        }
        if (now) {
            int p = Math.max(0, Math.min(100, o.optInt("progress", 0)));
            LinearLayout bar = new LinearLayout(act);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setBackground(rounded(0x33FFFFFF, 2));
            View fill = new View(act);
            fill.setBackgroundColor(accent);
            bar.addView(fill, new LinearLayout.LayoutParams(0, Ui.dp(act, 3), p));
            View rest = new View(act);
            bar.addView(rest, new LinearLayout.LayoutParams(0, Ui.dp(act, 3), 100 - p));
            LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 3));
            barLp.topMargin = Ui.dp(act, 10);
            right.addView(bar, barLp);
        }
        item.addView(right, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return item;
    }

    private View empty(String t1, String t2) {
        TextView t = text(t1 + "\n" + t2, 14, SUB, false);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        t.setPadding(Ui.dp(act, 10), Ui.dp(act, 36), Ui.dp(act, 10), Ui.dp(act, 36));
        return t;
    }

    // ------------------------------------------------------------------ 小工具

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private float sp(float v) { return v * k; }

    private TextView text(String s, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(act);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(sizeSp * k);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(act, radiusDp));
        return g;
    }

    private GradientDrawable closeBg(boolean focused) {
        GradientDrawable g = rounded(focused ? accent : 0xFF232B3A, 9);
        g.setStroke(Math.max(1, Ui.dp(act, focused ? 2 : 1)),
                focused ? 0xFFFFFFFF : LINE);
        return g;
    }

    private static int blend(int base, int over, float f) {
        return LiveTheme.blend(base, over, f);
    }

    /** 主题色由 LiveTheme 统一提供，抽屉与弹窗一定同色 */
    private static int accent(Context c) {
        return LiveTheme.accent(c);
    }

}
