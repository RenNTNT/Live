package com.ilatv.tv;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * 把手机推送过来的 APK 交给系统安装器。
 *
 * <p>修复「解析软件包时出现问题」的两个根因：
 * ① 旧实现把 APK 放在 /data/data/&lt;pkg&gt;/cache（0700 私有目录），API21~23 用
 *    file:// 直接给路径时系统安装器打不开；现在放到应用外部专属目录
 *    （getExternalFilesDir/Download），老电视 file:// 同样可读，API24+ 仍走 content://。
 * ② query() 以前返回 _data 私有绝对路径，不少电视 ROM 会拿它自己 open 而不是走
 *    openFile 的 fd，结果读不到 → 解析失败；现在 _data 一律返回 null，强制走 fd。
 *
 * <p>另外补 openAssetFile 兜底（部分 ROM 走 AssetFileDescriptor 通道），
 * 并提供 systemCanParse() 让系统自己先解析一遍，坏包在推送阶段就被拦下。
 */
public final class ApkProvider extends ContentProvider {

    private static final String FILE = "update.apk";

    /** APK 落盘位置：优先外部专属目录，拿不到才回退到 cache/push */
    public static File apkFile(Context c) {
        File ext = null;
        try { ext = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); } catch (Exception ignored) {}
        if (ext != null) {
            if (!ext.isDirectory()) { try { ext.mkdirs(); } catch (Exception ignored) {} }
            if (ext.isDirectory()) return new File(ext, FILE);
        }
        return new File(new File(c.getCacheDir(), "push"), FILE);
    }

    /** 清理时新旧两处都要顾到（覆盖安装后旧进程可能残留 cache 里的包） */
    public static File[] allApkFiles(Context c) {
        File ext = null;
        try { ext = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); } catch (Exception ignored) {}
        File cache = new File(new File(c.getCacheDir(), "push"), FILE);
        if (ext == null) return new File[]{cache};
        return new File[]{new File(ext, FILE), cache};
    }

    public static Uri uriFor(Context c) {
        return Uri.parse("content://" + c.getPackageName() + ".apkprovider/" + FILE);
    }

    /**
     * 用系统自己的 PackageParser 预解析一遍（公开 API，不验签）。
     * 能抓出「ZIP 完整但 AndroidManifest.xml 二进制损坏 / 根本不是 APK」这类
     * 光靠 isApk() 看 ZIP 目录发现不了的问题，避免把坏包送去安装后弹含糊错误。
     */
    public static PackageInfo parseInfo(Context c, File f) {
        if (f == null || !f.isFile()) return null;
        try {
            return c.getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean systemCanParse(Context c, File f) {
        PackageInfo pi = parseInfo(c, f);
        return pi != null && pi.packageName != null && !pi.packageName.isEmpty();
    }

    @Override
    public boolean onCreate() { return true; }

    private File resolve() throws FileNotFoundException {
        File f = apkFile(getContext());
        if (f.isFile()) return f;
        // 兜底：旧版本可能还留在 cache/push
        File old = new File(new File(getContext().getCacheDir(), "push"), FILE);
        if (old.isFile()) return old;
        throw new FileNotFoundException("no pushed apk");
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (mode != null && mode.indexOf('w') >= 0) throw new FileNotFoundException("read only");
        // 返回可 seek 的只读 fd，安装器通过它读取完整字节，不受目录权限影响
        return ParcelFileDescriptor.open(resolve(), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    /** 部分电视 ROM 的安装器走 AssetFileDescriptor 而不是 openFile */
    @Override
    public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws FileNotFoundException {
        ParcelFileDescriptor pfd = openFile(uri, mode);
        long len = 0;
        try { len = resolve().length(); } catch (Exception ignored) {}
        return new AssetFileDescriptor(pfd, 0, len);
    }

    /**
     * 系统安装器会查 _display_name / _size 再解析包。
     * 关键：_data 必须返回 null——一旦给出私有绝对路径，不少电视 ROM 就直接
     * 拿路径自己 open，而 /data/data 或 /Android/data 对安装器不可读，必然解析失败。
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        File f = null;
        try { f = resolve(); } catch (FileNotFoundException ignored) {}
        String[] cols = projection == null
                ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}
                : projection;
        MatrixCursor c = new MatrixCursor(cols, 1);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            String col = cols[i];
            if (OpenableColumns.DISPLAY_NAME.equals(col)) row[i] = FILE;
            else if (OpenableColumns.SIZE.equals(col)) row[i] = (f != null && f.isFile()) ? f.length() : 0L;
            else row[i] = null;                       // 含 _data：一律不给路径
        }
        c.addRow(row);
        return c;
    }

    @Override public String getType(Uri uri) { return "application/vnd.android.package-archive"; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection,
                                String[] selectionArgs) { return 0; }
}
