package com.ilatv.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * 直播节目表（XMLTV / EPG）库。
 *
 * 内置源 https://gh-proxy.org/https://github.com/sggc/SD-EPG/raw/main/EPG/sggc-desc.xml.gz
 * 是标准 XMLTV：&lt;tv&gt; 下 &lt;channel id&gt; 带多个 &lt;display-name&gt; 别名，
 * &lt;programme start="yyyyMMddHHmmss +0800" stop="..." channel="id"&gt; 带 title / desc。
 * 文件为 .gz（实测 3.5 MB → 解压约 48 MB / 499 频道 / 10 万+ 节目），所以：
 *   - 用 SAX 流式解析，不整份读进内存；
 *   - 只保留「今天 ~ 后天」三天窗口内的节目，desc 截 120 字；
 *   - 结果落一份精简 JSON 缓存，12 小时内不重复联网；
 *   - gh-proxy 被 WAF 拒绝时自动回退同仓库的 jsDelivr 镜像。
 *
 * 源列表持久在 config.json 的 epgSources（TvServer 负责读写）：首次启动写入内置一条，
 * 之后在设置页删掉就不会自动加回来 —— 这是「内置可删除」的关键。
 */
public final class EpgStore {

    public static final String DEFAULT_URL =
            "https://gh-proxy.org/https://github.com/sggc/SD-EPG/raw/main/EPG/sggc-desc.xml.gz";
    /** 仅当内置地址请求失败时使用；内置源被删除后不会走到这里。 */
    public static final String MIRROR_URL =
            "https://cdn.jsdelivr.net/gh/sggc/SD-EPG@main/EPG/sggc-desc.xml.gz";
    public static final String DEFAULT_NAME = "内置节目表（sggc/SD-EPG）";

    private static final String PREF = "ilatv_epg";
    private static final String CACHE_FILE = "epg_cache.json";
    private static final long TTL = 12L * 60 * 60 * 1000;
    private static final int MAX_BYTES = 16 * 1024 * 1024;   // 下载上限，防御异常大文件
    private static final int MAX_DESC = 120;
    private static final int MAX_ALIAS = 12;
    private static final int MAX_PROG_PER_CH = 240;

    private static final Object LOCK = new Object();
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ilatv-epg");
        t.setDaemon(true);
        return t;
    });

    /** 频道数据（解析结果 / 缓存读回后的运行时形态） */
    static final class Ch {
        String id;
        final List<String> names = new ArrayList<>();
        final List<Prog> progs = new ArrayList<>();
    }
    static final class Prog {
        long start, stop;
        String title, desc;
        Prog(long s, long e, String t, String d) { start = s; stop = e; title = t; desc = d; }
    }

    /** 归一别名 → channel id；id → 频道数据；带画质词的别名单独收在 QALIAS */
    private static final Map<String, String> ALIAS = new HashMap<>();
    private static final Map<String, String> QALIAS = new HashMap<>();
    private static final Map<String, Ch> DATA = new LinkedHashMap<>();
    private static final List<String> FUZZY = new ArrayList<>();

    private static volatile boolean loading = false;
    private static volatile boolean loaded = false;
    private static volatile long updatedAt = 0;
    private static volatile String lastError = "";
    private static volatile int channelCount = 0;
    private static volatile int programmeCount = 0;
    private static volatile String sig = "";          // 当前缓存对应的源列表签名
    private static volatile List<Src> sources = new ArrayList<>();
    private static volatile boolean prefetchDone = false;
    /** 设置页总开关：关闭后源列表仍保留，但不联网、不读缓存、所有查询返回空。 */
    private static volatile boolean switchedOn = false;

    static final class Src {
        String name, url;
        boolean builtIn;
        Src(String n, String u, boolean b) { name = n; url = u; builtIn = b; }
    }

    private EpgStore() {}

    // ------------------------------------------------------------------ 内置源

    public static JSONArray defaultSources() {
        JSONArray a = new JSONArray();
        try {
            JSONObject o = new JSONObject();
            o.put("name", DEFAULT_NAME);
            o.put("url", DEFAULT_URL);
            o.put("builtIn", true);
            a.put(o);
        } catch (Exception ignored) {}
        return a;
    }

    private static SharedPreferences pref(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** 总开关（与「删除源」相互独立）：关掉后源列表原样保留，随时能一键开回来。 */
    public static boolean isSwitchedOn() { return switchedOn; }

    /** 原生播放页读持久镜像，避免与 Web 服务不在同一进程时状态不同步。 */
    public static boolean isSwitchedOn(Context c) {
        try { return pref(c).getBoolean("switched_on", false); }
        catch (Exception ignored) { return switchedOn; }
    }

    public static void setSwitchedOn(Context c, boolean on) {
        switchedOn = on;
        try { pref(c).edit().putBoolean("switched_on", on).apply(); } catch (Exception ignored) {}
        if (!on) clearRuntime();          // 立即不显示，也不再联网
    }

    /** 由 TvServer 在读取 config.json 后调用；config.json 是持久真源，这里只是运行时镜像。 */
    public static void configure(Context c, JSONArray arr) {
        List<Src> next = new ArrayList<>();
        JSONArray list = arr == null ? new JSONArray() : arr;
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o == null) continue;
            String u = o.optString("url", "").trim();
            if (u.isEmpty()) continue;
            next.add(new Src(o.optString("name", "节目表源").trim(), u, o.optBoolean("builtIn", false)));
        }
        String s = signature(next);
        boolean changed;
        synchronized (LOCK) {
            changed = !s.equals(sig);
            sources = next;
        }
        try {
            SharedPreferences p = pref(c);
            switchedOn = p.getBoolean("switched_on", false);
            p.edit().putString("sources", list.toString()).apply();
        } catch (Exception ignored) {}
        if (changed) clearRuntime();
    }

    private static String signature(List<Src> list) {
        StringBuilder b = new StringBuilder();
        for (Src s : list) b.append(s.url).append('\n');
        return b.toString();
    }

    private static List<Src> snapshot() {
        synchronized (LOCK) { return new ArrayList<>(sources); }
    }

    private static void clearRuntime() {
        synchronized (LOCK) {
            ALIAS.clear(); QALIAS.clear(); DATA.clear(); FUZZY.clear();
            loaded = false; updatedAt = 0; channelCount = 0; programmeCount = 0; lastError = "";
        }
    }

    /** 配置变化（增删改源）后调用：立即清空并后台重读，删空后不再联网。 */
    public static void onSettingChanged(Context c) {
        clearRuntime();
        refresh(c, true, null);
    }

    public static void initAndPrefetch(Context c) {
        if (prefetchDone) return;
        prefetchDone = true;
        if (!switchedOn) { clearRuntime(); return; }   // 设置里关了：启动就不联网
        POOL.execute(() -> {
            loadCache(c);
            if (!loaded) refresh(c, false, null);
        });
    }

    // ------------------------------------------------------------------ 状态

    public static JSONObject status(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("enabled", !snapshot().isEmpty() && switchedOn);
            o.put("switchedOn", switchedOn);          // 总开关（与「源是否删空」分开）
            o.put("hasSources", !snapshot().isEmpty());
            o.put("loading", loading && switchedOn);
            o.put("count", channelCount);
            o.put("programmes", programmeCount);
            o.put("updated", updatedAt);
            o.put("builtIn", hasBuiltIn());
            o.put("defaultUrl", DEFAULT_URL);
            o.put("error", lastError);
            JSONArray arr = new JSONArray();
            for (Src s : snapshot()) {
                JSONObject x = new JSONObject();
                x.put("name", s.name); x.put("url", s.url); x.put("builtIn", s.builtIn);
                arr.put(x);
            }
            o.put("sources", arr);
        } catch (Exception ignored) {}
        return o;
    }

    private static boolean hasBuiltIn() {
        for (Src s : snapshot()) if (s.builtIn) return true;
        return false;
    }

    // ------------------------------------------------------------------ 刷新

    public static void refresh(final Context c, final boolean force, final Runnable done) {
        POOL.execute(() -> {
            if (!switchedOn) {                    // 设置里关了：源还在，但一律不联网
                clearRuntime();
                if (done != null) done.run();
                return;
            }
            List<Src> list = snapshot();
            if (list.isEmpty()) {                 // 内置源被删光：不联网、不恢复
                clearRuntime();
                if (done != null) done.run();
                return;
            }
            if (!force && loaded && System.currentTimeMillis() - updatedAt < TTL) {
                if (done != null) done.run();
                return;
            }
            loading = true; lastError = "";
            String err = "";
            Map<String, Ch> merged = new LinkedHashMap<>();
            for (Src s : list) {
                InputStream in = null;
                try {
                    in = open(s.url);
                    if (in == null && DEFAULT_URL.equals(s.url)) {
                        in = open(MIRROR_URL);      // 内置源 403 / 超时时走镜像
                    }
                    if (in == null) { err = "下载失败：" + s.name; continue; }
                    Map<String, Ch> part = parse(in, windowLo(), windowHi());
                    for (Map.Entry<String, Ch> e : part.entrySet()) {
                        Ch old = merged.get(e.getKey());
                        if (old == null) merged.put(e.getKey(), e.getValue());
                        else old.progs.addAll(e.getValue().progs);
                    }
                } catch (Exception e) {
                    err = s.name + "：" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                } finally {
                    try { if (in != null) in.close(); } catch (Exception ignored) {}
                }
            }
            if (!merged.isEmpty()) {
                writeCache(c, merged, signature(list));
                loadCache(c);
                err = "";      // 主地址 403 但镜像成功：不算失败
            } else if (err.isEmpty()) {
                err = "未解析到节目数据";
            }
            lastError = err;
            loading = false;
            if (done != null) done.run();
        });
    }

    /** 打开一个 XMLTV 源，自动识别 gzip；403 / 超时 / 断网一律返回 null，由调用方决定是否走镜像。 */
    private static InputStream open(String url) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(35000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "iLaTV/2.0 (EPG)");
            conn.setRequestProperty("Accept-Encoding", "identity");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) { conn.disconnect(); return null; }
            InputStream raw = new BufferedInputStream(conn.getInputStream(), 64 * 1024);
            raw.mark(2);
            byte[] magic = new byte[2];
            int n = raw.read(magic);
            raw.reset();
            if (n == 2 && (magic[0] & 0xff) == 0x1f && (magic[1] & 0xff) == 0x8b) {
                return new BufferedInputStream(new GZIPInputStream(raw, 64 * 1024), 64 * 1024);
            }
            return raw;   // 有些源直接给未压缩 XML
        } catch (Exception e) {
            if (conn != null) conn.disconnect();
            return null;
        }
    }

    private static long windowLo() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis() - 2 * 3600_000L;    // 今天 00:00 往前 2 小时
    }
    private static long windowHi() {
        return windowLo() + 3 * 24 * 3600_000L;          // 今天 / 明天 / 后天
    }

    // ------------------------------------------------------------------ XMLTV 解析（纯 Java，可 JVM 单测）

    /** SAX 流式解析，仅保留 [lo,hi] 窗口内节目；返回 channel id → Ch。 */
    static Map<String, Ch> parse(InputStream in, long lo, long hi) throws Exception {
        SAXParserFactory f = SAXParserFactory.newInstance();
        f.setNamespaceAware(false);
        SAXParser sp = f.newSAXParser();
        Handler h = new Handler(lo, hi);
        sp.parse(in, h);
        return h.result;
    }

    private static final class Handler extends DefaultHandler {
        final long lo, hi;
        final Map<String, Ch> result = new LinkedHashMap<>();
        Ch curCh;
        Prog curProg;
        String curProgId;
        StringBuilder text = new StringBuilder();
        String capturing = null;

        Handler(long lo, long hi) { this.lo = lo; this.hi = hi; }

        @Override public void startElement(String uri, String local, String qName, Attributes a) {
            String tag = qName.contains(":") ? qName.substring(qName.indexOf(':') + 1) : qName;
            if ("channel".equals(tag)) {
                curCh = new Ch(); curCh.id = a.getValue("id");
                if (curCh.id == null) curCh.id = "";
            } else if ("display-name".equals(tag) && curCh != null) {
                capturing = "name"; text.setLength(0);
            } else if ("programme".equals(tag)) {
                long s = parseTime(a.getValue("start"));
                long e = parseTime(a.getValue("stop"));
                curProgId = a.getValue("channel");
                curProg = (s > 0 && e > s && s < hi && e > lo)
                        ? new Prog(s, e, "", "") : null;
            } else if ("title".equals(tag) && curProg != null) {
                capturing = "title"; text.setLength(0);
            } else if ("desc".equals(tag) && curProg != null) {
                capturing = "desc"; text.setLength(0);
            }
        }

        @Override public void characters(char[] ch, int start, int length) {
            if (capturing != null) text.append(ch, start, length);
        }

        private void finishText() {
            String v = text.toString().trim();
            if ("name".equals(capturing) && curCh != null && !v.isEmpty()
                    && curCh.names.size() < MAX_ALIAS) {
                if (!curCh.names.contains(v)) curCh.names.add(v);
            } else if ("title".equals(capturing) && curProg != null) {
                curProg.title = v;
            } else if ("desc".equals(capturing) && curProg != null) {
                curProg.desc = v.length() > MAX_DESC ? v.substring(0, MAX_DESC) + "…" : v;
            }
            capturing = null; text.setLength(0);
        }

        @Override public void endElement(String uri, String local, String qName) {
            String tag = qName.contains(":") ? qName.substring(qName.indexOf(':') + 1) : qName;
            if (capturing != null && ("title".equals(tag) || "desc".equals(tag) || "display-name".equals(tag))) {
                finishText();
            }
            if ("channel".equals(tag) && curCh != null) {
                if (!curCh.id.isEmpty()) {
                    Ch old = result.get(curCh.id);
                    if (old == null) result.put(curCh.id, curCh);
                    else for (String n : curCh.names) if (!old.names.contains(n)) old.names.add(n);
                }
                curCh = null;
            } else if ("programme".equals(tag)) {
                if (curProg != null && curProgId != null && !curProg.title.isEmpty()) {
                    Ch ch = result.get(curProgId);
                    if (ch == null) { ch = new Ch(); ch.id = curProgId; result.put(curProgId, ch); }
                    if (ch.progs.size() < MAX_PROG_PER_CH) ch.progs.add(curProg);
                }
                curProg = null; curProgId = null;
            }
        }
    }

    /** XMLTV 时间： "20261120001000 +0800"，也兼容不带时区 / 带冒号的写法。 */
    static long parseTime(String s) {
        if (s == null || s.isEmpty()) return 0;
        String v = s.trim();
        try {
            return new SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US).parse(v).getTime();
        } catch (Exception ignored) {}
        try {
            return new SimpleDateFormat("yyyyMMddHHmmss", Locale.US).parse(v).getTime();
        } catch (Exception ignored) {}
        try {
            String d = v.length() >= 14 ? v.substring(0, 14) : v;
            return new SimpleDateFormat("yyyyMMddHHmmss", Locale.US).parse(d).getTime();
        } catch (Exception e) { return 0; }
    }

    /** 频道名归一：全角转半角、去空格/连字符、去画质尾缀、CCTV 统一写法。 */
    static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= 0xFF01 && c <= 0xFF5E) c = (char) (c - 0xFEE0);
            if (c == ' ' || c == '\t' || c == '-' || c == '_' || c == '·' || c == '.' || c == '　') continue;
            if (c >= 'A' && c <= 'Z') c = (char) (c + 32);
            b.append(c);
        }
        String v = b.toString();
        String[] tails = {"超高清", "高清", "标清", "4k", "8k", "hd", "fhd", "uhd", "sd", "hdr", "倍速", "测试"};
        boolean cut;
        do {
            cut = false;
            for (String t : tails) {
                if (v.length() > t.length() && v.endsWith(t)) { v = v.substring(0, v.length() - t.length()); cut = true; }
            }
        } while (cut);
        v = v.replace("中央电视台", "cctv").replace("央视", "cctv");
        if (v.startsWith("cctv")) {
            String rest = v.substring(4);
            if (rest.contains("综合")) v = "cctv1";        // CCTV1综合 / CCTV-1 综合 / cctv综合频道
            else if (rest.startsWith("财经")) v = "cctv2";
        }
        return v;
    }

    /** 频道名里的画质版本标记：4K/超高清 → 4k，HD/高清 → hd，普通 → null。 */
    static String qualityTag(String raw) {
        if (raw == null) return null;
        String s = raw.toLowerCase(Locale.US);
        if (s.contains("4k") || s.contains("8k") || s.contains("超高清")) return "4k";
        if (s.contains("fhd") || s.contains("uhd") || s.contains("hd") || s.contains("高清")) return "hd";
        return null;
    }

    /** 把解析结果装进运行时索引（别名 → id、id → 数据）。 */
    static void install(Map<String, Ch> data) {
        synchronized (LOCK) {
            ALIAS.clear(); QALIAS.clear(); DATA.clear(); FUZZY.clear();
            Map<String, Boolean> aliasQuality = new HashMap<>();   // 主表里该 key 当前是否指向画质版
            int total = 0;
            for (Map.Entry<String, Ch> e : data.entrySet()) {
                String id = e.getKey();
                Ch ch = e.getValue();
                Collections.sort(ch.progs, Comparator.comparingLong(p -> p.start));
                DATA.put(id, ch);
                total += ch.progs.size();
                putAlias(id, id, aliasQuality);
                for (String n : ch.names) putAlias(n, id, aliasQuality);
            }
            FUZZY.addAll(ALIAS.keySet());
            FUZZY.sort((a, b) -> Integer.compare(b.length(), a.length()));
            channelCount = DATA.size();
            programmeCount = total;
            loaded = !DATA.isEmpty();
            updatedAt = System.currentTimeMillis();
        }
    }

    private static void putAlias(String raw, String id, Map<String, Boolean> quality) {
        String k = norm(raw);
        if (k.isEmpty()) return;
        String tag = qualityTag(raw);
        boolean isQ = tag != null;
        if (isQ) QALIAS.put(k + "@" + tag, id);       // 4K / HD 版本各归各位
        Boolean old = quality.get(k);
        if (!ALIAS.containsKey(k)) { ALIAS.put(k, id); quality.put(k, isQ); }
        else if (Boolean.TRUE.equals(old) && !isQ) {   // 普通版优先占用无标记 key
            ALIAS.put(k, id); quality.put(k, false);
        }
    }

    /** 频道名 → EPG channel id；先精确、再画质尾缀、最后最长包含匹配。 */
    static String match(String name) {
        String n = norm(name);
        if (n.isEmpty()) return null;
        synchronized (LOCK) {
            String tag = qualityTag(name);
            if (tag != null) {
                String q = QALIAS.get(n + "@" + tag);
                if (q != null) return q;
            }
            String id = ALIAS.get(n);
            if (id != null) return id;
            for (String a : FUZZY) {
                if (a.length() >= 3 && (n.contains(a) || a.contains(n)) && Math.abs(a.length() - n.length()) <= 8) {
                    return ALIAS.get(a);
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ 缓存

    private static File cacheFile(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), CACHE_FILE);
    }

    private static void writeCache(Context c, Map<String, Ch> data, String sg) {
        File tmp = new File(c.getApplicationContext().getFilesDir(), CACHE_FILE + ".tmp");
        BufferedWriter w = null;
        try {
            w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tmp), Charset.forName("UTF-8")));
            w.write("{\"ts\":"); w.write(Long.toString(System.currentTimeMillis()));
            w.write(",\"sig\":"); w.write(JSONObject.quote(sg));
            w.write(",\"chs\":[");
            boolean firstCh = true;
            for (Ch ch : data.values()) {
                if (!firstCh) w.write(',');
                firstCh = false;
                w.write("{\"id\":"); w.write(JSONObject.quote(ch.id));
                w.write(",\"n\":[");
                for (int i = 0; i < ch.names.size(); i++) {
                    if (i > 0) w.write(',');
                    w.write(JSONObject.quote(ch.names.get(i)));
                }
                w.write("],\"p\":[");
                for (int i = 0; i < ch.progs.size(); i++) {
                    if (i > 0) w.write(',');
                    Prog p = ch.progs.get(i);
                    w.write('['); w.write(Long.toString(p.start)); w.write(',');
                    w.write(Long.toString(p.stop)); w.write(',');
                    w.write(JSONObject.quote(p.title)); w.write(',');
                    w.write(JSONObject.quote(p.desc)); w.write(']');
                }
                w.write("]}");
            }
            w.write("]}");
            w.flush(); w.close(); w = null;
            File f = cacheFile(c);
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(f);
            sig = sg;
        } catch (Exception ignored) {
        } finally {
            try { if (w != null) w.close(); } catch (Exception ignored) {}
        }
    }

    private static void loadCache(Context c) {
        if (!switchedOn) return;
        File f = cacheFile(c);
        if (!f.exists() || f.length() > MAX_BYTES * 2) return;
        try {
            byte[] buf = readAll(new FileInputStream(f));
            JSONObject o = new JSONObject(new String(buf, "UTF-8"));
            if (!signature(snapshot()).equals(o.optString("sig", ""))) return;  // 源列表变了，缓存作废
            JSONArray chs = o.optJSONArray("chs");
            if (chs == null) return;
            Map<String, Ch> data = new LinkedHashMap<>();
            for (int i = 0; i < chs.length(); i++) {
                JSONObject jc = chs.getJSONObject(i);
                Ch ch = new Ch(); ch.id = jc.optString("id", "");
                JSONArray ns = jc.optJSONArray("n");
                if (ns != null) for (int k = 0; k < ns.length(); k++) ch.names.add(ns.optString(k, ""));
                JSONArray ps = jc.optJSONArray("p");
                if (ps != null) for (int k = 0; k < ps.length(); k++) {
                    JSONArray p = ps.optJSONArray(k);
                    if (p != null && p.length() >= 4)
                        ch.progs.add(new Prog(p.optLong(0), p.optLong(1), p.optString(2, ""), p.optString(3, "")));
                }
                if (!ch.id.isEmpty()) data.put(ch.id, ch);
            }
            install(data);
            updatedAt = o.optLong("ts", System.currentTimeMillis());
            sig = o.optString("sig", "");
        } catch (Exception ignored) {}
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[16 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
        in.close();
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ 查询

    /** 某频道的节目表（今天~后天）；供网页 /api/epg 与原生播放页共用。 */
    public static JSONArray programsFor(String channelName) {
        JSONArray out = new JSONArray();
        if (!switchedOn) return out;
        String id = match(channelName);
        if (id == null) return out;
        long now = System.currentTimeMillis();
        SimpleDateFormat hm = new SimpleDateFormat("HH:mm", Locale.getDefault());
        SimpleDateFormat md = new SimpleDateFormat("MM-dd", Locale.getDefault());
        long day0 = windowLo() + 2 * 3600_000L;
        synchronized (LOCK) {
            Ch ch = DATA.get(id);
            if (ch == null) return out;
            for (Prog p : ch.progs) {
                if (p.stop < day0) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("start", hm.format(new java.util.Date(p.start)));
                    o.put("stop", hm.format(new java.util.Date(p.stop)));
                    o.put("date", md.format(new java.util.Date(p.start)));
                    o.put("startMs", p.start);
                    o.put("stopMs", p.stop);
                    o.put("title", p.title);
                    o.put("desc", p.desc);
                    int day = (int) ((p.start - day0) / (24 * 3600_000L));
                    o.put("day", Math.max(0, day));
                    o.put("now", p.start <= now && now < p.stop);
                    o.put("progress", p.stop > p.start
                            ? Math.min(100, Math.max(0, (int) ((now - p.start) * 100 / (p.stop - p.start)))) : 0);
                    out.put(o);
                } catch (Exception ignored) {}
            }
        }
        return out;
    }

    /** 原生播放页「节目单」对话框用的纯文本；无数据时返回 null，调用方退回频道信息。 */
    public static String formatForNative(String channelName) {
        JSONArray a = programsFor(channelName);
        if (a.length() == 0) return null;
        String id = match(channelName);
        StringBuilder b = new StringBuilder();
        b.append("EPG 频道：").append(id == null ? channelName : id).append('\n');
        String[] labels = {"今天", "明天", "后天"};
        int lastDay = -1, lines = 0;
        for (int i = 0; i < a.length() && lines < 22; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            int d = o.optInt("day", 0);
            if (d != lastDay) {
                b.append('\n').append("— ").append(d < 3 ? labels[d] : o.optString("date")).append(" —\n");
                lastDay = d;
            }
            b.append(o.optBoolean("now", false) ? "▶ " : "   ");
            b.append(o.optString("start")).append('-').append(o.optString("stop"))
             .append(' ').append(o.optString("title")).append('\n');
            lines++;
        }
        return b.toString();
    }
}
