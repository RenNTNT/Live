package com.ilatv.tv;

import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * 洛雪音源脚本的网络出口（v111）。
 *
 * <p>自定义源脚本运行在隐藏 WebView 里，宿主通过 lx.request / fetch 把请求转到这里。
 * 由 Java 代发有两个好处：① 不受 WebView 的 CORS / 混合内容限制；② 请求特征统一、
 * 明确要 identity 编码，避免拿到 gzip 字节被脚本当 JSON 解析。
 *
 * <p><b>安全边界</b>：禁止脚本访问回环地址（127.0.0.1 / localhost / ::1），
 * 否则第三方音源可以借宿主读本机内置服务的配置接口。这是官方自定义源说明里
 * 「导入恶意脚本可能影响系统」那条提示在本工程里的具体收敛。
 */
public final class LxHttp {

    private LxHttp() {}

    public static final String UA = "iLaTV-LX/1.0 (Android; custom-source host)";
    /** 单个响应上限 4 MB：音源接口只回 JSON / 短文本，不该出现媒体流 */
    public static final int MAX_BODY = 4 * 1024 * 1024;
    private static final int CONNECT_MS = 8000;
    private static final int READ_MS = 12000;

    public static boolean isLoopback(String url) {
        if (url == null) return true;
        String u = url.toLowerCase();
        return u.contains("://127.0.0.1") || u.contains("://localhost")
                || u.contains("://[::1]") || u.contains("://0.0.0.0");
    }

    /**
     * 发一次请求。返回 {ok, status, headers:{}, body(UTF-8 文本), bodyB64, size}；
     * 失败返回 {ok:false, error}，绝不抛到调用方，避免把隐藏 WebView 的线程带崩。
     *
     * @param headersJson 可选：{"Header-Name":"value"}，透传给上游
     */
    public static JSONObject request(String url, String method, String headersJson, String body) {
        JSONObject out = new JSONObject();
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            if (isLoopback(url)) throw new IllegalArgumentException("音源脚本不允许访问本机地址");
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://")))
                throw new IllegalArgumentException("只支持 http(s) 地址");
            String m = (method == null || method.isEmpty()) ? "GET" : method.toUpperCase();
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod(m);
            conn.setConnectTimeout(CONNECT_MS);
            conn.setReadTimeout(READ_MS);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", UA);
            conn.setRequestProperty("Accept", "application/json, text/plain, */*");
            conn.setRequestProperty("Accept-Encoding", "identity");
            if (headersJson != null && !headersJson.isEmpty()) {
                JSONObject h = new JSONObject(headersJson);
                java.util.Iterator<String> it = h.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    String v = h.optString(k, "");
                    // 这两个由宿主统一控制，不让脚本覆盖
                    if (k.equalsIgnoreCase("Accept-Encoding") || k.equalsIgnoreCase("Host")) continue;
                    if (!v.isEmpty()) conn.setRequestProperty(k, v);
                }
            }
            if (!"GET".equals(m) && body != null && !body.isEmpty()) {
                conn.setDoOutput(true);
                byte[] b = body.getBytes("UTF-8");
                OutputStream os = conn.getOutputStream();
                os.write(b);
                os.close();
            }
            int code = conn.getResponseCode();
            in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            byte[] raw = new byte[0];
            if (in != null) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    bos.write(buf, 0, n);
                    if (bos.size() > MAX_BODY) throw new IllegalArgumentException("响应超过 4 MB");
                }
                raw = Api.maybeGunzip(bos.toByteArray(), conn.getHeaderField("Content-Encoding"));
            }
            JSONObject hs = new JSONObject();
            for (int i = 0; ; i++) {
                String k = conn.getHeaderFieldKey(i);
                String v = conn.getHeaderField(i);
                if (k == null && v == null) break;
                if (k != null && v != null) hs.put(k, v);
            }
            out.put("ok", true);
            out.put("status", code);
            out.put("statusCode", code);       // 兼容桌面端脚本读 resp.statusCode
            out.put("headers", hs);
            out.put("body", new String(raw, "UTF-8"));
            out.put("bodyB64", Base64.encodeToString(raw, Base64.NO_WRAP));
            out.put("size", raw.length);
            return out;
        } catch (Exception e) {
            try {
                out.put("ok", false);
                out.put("error", e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
            } catch (Exception ignored) {}
            return out;
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) {}
            if (conn != null) conn.disconnect();
        }
    }

    /** 轻量摘要工具：不少音源要给平台接口算签名，用 JDK 自带 MessageDigest 即可，不引第三方库。 */
    public static String crypto(String algo, String dataB64) {
        JSONObject o = new JSONObject();
        try {
            String a = algo == null ? "md5" : algo.toLowerCase().replace("-", "");
            if (!a.equals("md5") && !a.equals("sha1") && !a.equals("sha256"))
                throw new IllegalArgumentException("只支持 md5 / sha1 / sha256");
            byte[] raw = dataB64 == null ? new byte[0]
                    : Base64.decode(dataB64, Base64.NO_WRAP);
            byte[] dig = MessageDigest.getInstance(
                    a.equals("md5") ? "MD5" : a.equals("sha1") ? "SHA-1" : "SHA-256").digest(raw);
            StringBuilder hex = new StringBuilder();
            for (byte b : dig) hex.append(String.format("%02x", b & 0xFF));
            o.put("ok", true);
            o.put("hex", hex.toString());
            o.put("b64", Base64.encodeToString(dig, Base64.NO_WRAP));
            return o.toString();
        } catch (Exception e) {
            try { o.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) {}
            return o.toString();
        }
    }
}
