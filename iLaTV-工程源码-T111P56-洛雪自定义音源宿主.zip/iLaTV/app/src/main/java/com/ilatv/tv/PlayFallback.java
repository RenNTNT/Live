package com.ilatv.tv;

/**
 * 直播起播失败后的「双链路」决策：
 *
 * 1) 优先用原来的方式直连（不经过本机代理，延迟最低、行为与旧版完全一致）；
 * 2) 直连失败且不是解码能力问题 → 换 /hls 代理重播同一台同一线路。
 *    代理使用与网页直播、点播播放器相同的请求特征（桌面 UA + 同源 Referer），
 *    解决带策略 CDN 返回 403 拦截页、被误报「不支持的媒体格式」的问题；
 * 3) 代理仍失败 → 才按原有逻辑自动切下一线路 / 显示提示。
 *
 * 抽成无 Android 依赖的纯决策类，便于 JVM 单测覆盖各种分支。
 */
public final class PlayFallback {

    private PlayFallback() {}

    public enum Action {
        RETRY_PROXY,   // 换请求特征，重播当前台当前线路
        NEXT_LINE,     // 自动切下一条线路（换台/换线路后重新从直连开始）
        SHOW_ERROR     // 已无路可退，显示提示
    }

    /**
     * @param proxyTried  当前台当前线路是否已经试过代理
     * @param decodeIssue 是否为解码能力问题（换请求特征无意义）
     * @param lineCount   该频道线路总数
     * @param errorTries  已经自动切过几次线路
     */
    public static Action decide(boolean proxyTried, boolean decodeIssue,
                                int lineCount, int errorTries) {
        if (!proxyTried && !decodeIssue) return Action.RETRY_PROXY;
        if (lineCount > 1 && errorTries < lineCount) return Action.NEXT_LINE;
        return Action.SHOW_ERROR;
    }

    /** 解码类错误与请求特征无关，不做代理回退 */
    public static boolean isDecodeIssue(String message) {
        return message != null && message.contains("解码失败");
    }
}
