/* ==========================================================================
 * iLaTV v111 · 洛雪自定义音源运行时桥（lx-bridge.js）
 *
 * 运行在 LxSourceHost 的隐藏 WebView 里。宿主注入 window.LxNative（Java），
 * 这里把它包装成官方自定义源脚本认识的 globalThis.lx：
 *   EVENT_NAMES / on / send / request / utils / env / currentScriptInfo
 *
 * 事件协议（与 lx-music-desktop / mobile 自定义源说明一致）：
 *   脚本  lx.send(EVENT_NAMES.inited, {sources, openDevTools})  → 宿主登记能力
 *   宿主  __lxDispatch(reqId, {action:'musicUrl', source, info}) → 脚本取链
 *   脚本  handler 返回 string 或 Promise<string> → 宿主 onResult 回传
 *   脚本  lx.request(url, options, cb) → Java 代发 HTTP，绕开 WebView CORS
 *
 * 只实现官方自定义源需要的接口：不提供 require / fs / child_process，
 * 导航、弹窗、文件访问由 Java 侧 WebViewClient / WebSettings 全部封死。
 * fetch 做了最小 polyfill（走同一条 Java 代发）；XMLHttpRequest 不模拟。
 * ========================================================================== */
(function (root) {
  'use strict';
  root = root || (typeof window !== 'undefined' ? window : this);
  if (!root.globalThis) root.globalThis = root;

  var EVENT_NAMES = {
    inited: 'inited',
    request: 'request',
    updateAlert: 'updateAlert'
  };
  var handlers = {};
  var httpCbs = {};
  var httpSeq = 1;
  var alertOnce = false;
  var meta = root.__LX_META__ || {};

  function native() { return root.LxNative; }

  function on(name, fn) {
    if (typeof fn !== 'function') return;
    (handlers[name] || (handlers[name] = [])).push(fn);
  }

  function safeJson(v, fallback) {
    try { return JSON.stringify(v); } catch (e) { return fallback; }
  }

  function send(name, data) {
    var N = native();
    if (!N) return;
    if (name === EVENT_NAMES.inited) {
      try { N.onInited(safeJson(data || {}, '{}')); } catch (e) {}
      return;
    }
    if (name === EVENT_NAMES.updateAlert) {
      // 官方限制「每次会话仅允许一次」，这里同样只放行一次，且只记日志不弹 UI
      if (alertOnce) return;
      alertOnce = true;
      try { N.onLog(safeJson(data || {}, '{}')); } catch (e) {}
      return;
    }
    // 其余事件不允许第三方脚本驱动宿主界面
  }

  function request(url, options, cb) {
    var id = 'h' + (httpSeq++);
    httpCbs[id] = typeof cb === 'function' ? cb : function () {};
    var N = native();
    if (!N) {
      var f0 = httpCbs[id]; delete httpCbs[id];
      f0(new Error('宿主网络接口不可用'), null);
      return;
    }
    try {
      N.fetch(String(url), safeJson(options || {}, '{}'), id);
    } catch (e) {
      var f = httpCbs[id]; delete httpCbs[id];
      f(e, null);
    }
  }

  function headerBag(hs) {
    return {
      get: function (k) {
        if (!hs) return null;
        if (hs[k] != null) return hs[k];
        var low = String(k).toLowerCase();
        for (var key in hs) {
          if (Object.prototype.hasOwnProperty.call(hs, key) && key.toLowerCase() === low) return hs[key];
        }
        return null;
      }
    };
  }

  /** Java 代发完成后的回调：cb(err, resp)，resp.body 为 UTF-8 文本 */
  root.__lxHttp = function (id, resJson) {
    var cb = httpCbs[id];
    delete httpCbs[id];
    if (!cb) return;
    var r;
    try { r = JSON.parse(resJson); } catch (e) { r = { ok: false, error: '宿主返回非 JSON' }; }
    if (!r.ok) {
      cb(new Error(r.error || '请求失败'), null);
      return;
    }
    cb(null, {
      statusCode: r.status || 0,
      status: r.status || 0,
      statusMessage: '',
      headers: headerBag(r.headers),
      body: r.body || '',
      bodyB64: r.bodyB64 || '',
      raw: r.body || ''
    });
  };

  /** 宿主发起取链：把结果（字符串 / Promise / 异常）统一回传 */
  root.__lxDispatch = function (reqId, payloadJson) {
    var N = native();
    if (!N) return;
    var done = false;
    function finish(ok, data, err) {
      if (done) return;
      done = true;
      try { N.onResult(reqId, JSON.stringify({ ok: ok, data: data, error: err })); }
      catch (e) {
        try { N.onResult(reqId, '{"ok":false,"error":"结果序列化失败"}'); } catch (e2) {}
      }
    }
    var payload;
    try { payload = JSON.parse(payloadJson); }
    catch (e) { finish(false, null, '宿主请求不是合法 JSON'); return; }
    var hs = handlers[EVENT_NAMES.request] || [];
    if (!hs.length) { finish(false, null, '音源没有注册 request 处理器'); return; }
    var r;
    try { r = hs[0](payload); }
    catch (e) { finish(false, null, String((e && e.message) || e)); return; }
    if (r && typeof r.then === 'function') {
      r.then(function (v) { finish(true, v == null ? null : v, null); },
             function (e) { finish(false, null, String((e && e.message) || e)); });
    } else {
      finish(true, r == null ? null : r, null);
    }
  };

  // ---- lx.utils：移动端轻量引擎常用到的最小集合 ----
  function toB64(s) {
    try { return btoa(unescape(encodeURIComponent(String(s)))); }
    catch (e) { return ''; }
  }
  function fromB64(b) {
    try { return decodeURIComponent(escape(atob(String(b)))); }
    catch (e) { try { return atob(String(b)); } catch (e2) { return ''; } }
  }
  function digest(algo, s) {
    var N = native();
    if (!N) throw new Error('宿主加密接口不可用');
    var r = JSON.parse(N.crypto(algo, toB64(s)));
    if (!r.ok) throw new Error(r.error || '摘要计算失败');
    return r.hex;
  }
  var utils = {
    base64: { encode: toB64, decode: fromB64 },
    str: { toBase64: toB64, fromBase64: fromB64 },
    crypto: {
      md5: function (s) { return digest('md5', s); },
      sha1: function (s) { return digest('sha1', s); },
      sha256: function (s) { return digest('sha256', s); }
    },
    buffer: {
      from: function (s) {
        return { toString: function () { return String(s); }, toBase64: function () { return toB64(s); } };
      }
    }
  };

  var scriptInfo = {
    name: meta.name || '',
    description: meta.description || '',
    version: meta.version || '',
    author: meta.author || '',
    homepage: meta.homepage || '',
    rawScript: ''
  };

  var lx = {
    version: '1.0.0',
    env: 'desktop',
    currentScriptInfo: scriptInfo,
    EVENT_NAMES: EVENT_NAMES,
    on: on,
    send: send,
    request: request,
    utils: utils
  };
  root.lx = lx;
  root.globalThis.lx = lx;

  // 部分社区源直接写 fetch()：统一改走宿主代发，避免 WebView 的 CORS / 混合内容限制
  root.fetch = function (url, opts) {
    opts = opts || {};
    return new Promise(function (resolve, reject) {
      request(url, {
        method: opts.method || 'GET',
        headers: opts.headers || {},
        body: typeof opts.body === 'string' ? opts.body : ''
      }, function (err, resp) {
        if (err) return reject(err);
        resolve({
          ok: resp.statusCode >= 200 && resp.statusCode < 300,
          status: resp.statusCode,
          headers: resp.headers,
          text: function () { return Promise.resolve(resp.body); },
          json: function () { return Promise.resolve(JSON.parse(resp.body)); }
        });
      });
    });
  };
})(typeof window !== 'undefined' ? window
        : (typeof globalThis !== 'undefined' ? globalThis : this));
