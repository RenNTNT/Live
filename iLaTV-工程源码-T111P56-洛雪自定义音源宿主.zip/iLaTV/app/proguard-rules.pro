# ---------------------------------------------------------------------------
# LibreTV-TV R8 / ProGuard 规则
# R8 看不见的入口有两类：WebView 通过 JS 字符串调用的 @JavascriptInterface 方法，
# 以及 IJK 反射桥接里的 Class.forName 目标（后者不 import 第三方类，但按字符串查找）。
# 下面逐项保留，避免 release 包里出现「档位在、内核找不到」。
# ---------------------------------------------------------------------------

# 保留运行时注解：WebView 在 addJavascriptInterface 时靠反射找 @JavascriptInterface
-keepattributes *Annotation*

# 保留所有带 @JavascriptInterface 的方法及其原名（exo.play / liveBridge.play /
# liveBridge.setup / appHost.exit ...）
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# 桥接对象是 MainActivity 的匿名内部类，整体保留，避免被改名或优化掉
-keep class com.ilatv.tv.MainActivity$* { *; }

# v111：隐藏音源沙箱的 LxNative 桥（LxSourceHost 的内部类）同样由 JS 字符串调用
-keep class com.ilatv.tv.LxSourceHost$* { *; }
# IjkKernel / LxSourceHost 都用了运行时反射与 JS 注入，类名不要被裁剪
-keepnames class com.ilatv.tv.IjkKernel { *; }

# Manifest 里声明的四大组件（R8 会依据 Manifest 自动保留，这里仅作防御）
-keep public class * extends android.app.Activity
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Service

# 本应用自身代码不混淆，崩溃日志里还能看到真实类名；第三方库仍可被压缩/混淆
-keepnames class com.ilatv.tv.** { *; }

# ---------------------------------------------------------------------------
# SMB（jcifs-ng / BouncyCastle）
# jcifs 会用 ServiceLoader 与字符串反射加载部分实现，R8 看不见这些入口；
# 保留整个 jcifs 包，其余第三方库继续按可达性裁剪以控制 APK 体积。
# ---------------------------------------------------------------------------
-keep class jcifs.** { *; }
-dontwarn jcifs.**
# BC 只被 NTLM / SMB3 密钥派生静态引用，未用到的 provider 照样让 R8 裁掉
-dontwarn org.bouncycastle.**
-keep class org.bouncycastle.asn1.ASN1ObjectIdentifier { *; }
-keep class org.bouncycastle.asn1.ASN1Primitive { *; }
-keep class org.bouncycastle.util.encoders.** { *; }
-keep class org.bouncycastle.crypto.digests.SHA256Digest { *; }
-keep class org.bouncycastle.crypto.macs.HMac { *; }
-keep class org.slf4j.** { *; }
-dontwarn org.slf4j.**
